const fs=require('fs');
const checks=[];
const env=process.env;
function ok(name,pass,detail){checks.push({name,pass,detail});}
ok('Node version',Number(process.versions.node.split('.')[0])>=18,process.version);
ok('Production mode',env.NODE_ENV==='production','NODE_ENV='+String(env.NODE_ENV||''));
ok('Development-open disabled',env.ST_MARYS_DEV_OPEN_ACCESS==='false','ST_MARYS_DEV_OPEN_ACCESS='+String(env.ST_MARYS_DEV_OPEN_ACCESS||''));
ok('PostgreSQL selected',String(env.ST_MARYS_DB_PROVIDER||'').toLowerCase()==='postgres','ST_MARYS_DB_PROVIDER='+String(env.ST_MARYS_DB_PROVIDER||''));
ok('DATABASE_URL present',!!env.DATABASE_URL,'DATABASE_URL is '+(env.DATABASE_URL?'set':'missing'));
ok('SESSION_SECRET strong',typeof env.SESSION_SECRET==='string'&&env.SESSION_SECRET.length>=32,'length='+(env.SESSION_SECRET||'').length);
ok('Admin API token present',!!env.ST_MARYS_ADMIN_API_TOKEN,'token '+(env.ST_MARYS_ADMIN_API_TOKEN?'set':'missing'));
const failed=checks.filter(x=>!x.pass);
console.log(JSON.stringify({ok:failed.length===0,checks,failed:failed.length},null,2));
process.exit(failed.length?1:0);
