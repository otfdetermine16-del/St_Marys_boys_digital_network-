const fs=require('fs'),path=require('path');
const ROOT=path.resolve(__dirname,'..');
const ignoredNames=new Set(['node_modules','.git','.DS_Store','Thumbs.db']);
const textExt=/\.(js|html|css|json|md|txt|sql|yml|yaml|sh)$/i;
const findings=[];
function walk(dir){
 for(const name of fs.readdirSync(dir)){if(ignoredNames.has(name))continue; const full=path.join(dir,name); const st=fs.statSync(full); if(st.isDirectory()){walk(full);continue} if(!textExt.test(name)||st.size>2_000_000)continue; const rel=path.relative(ROOT,full).replaceAll('\\','/'); const text=fs.readFileSync(full,'utf8');
  if(/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/.test(text)) findings.push(`${rel}: private key marker`);
  if(/AKIA[0-9A-Z]{16}/.test(text)) findings.push(`${rel}: AWS access-key pattern`);
  if(/(?:password|passwd|secret|token)\s*[:=]\s*['"][^'"\n]{24,}['"]/i.test(text) && !/example|replace-with|placeholder|dummy|test/i.test(text)) findings.push(`${rel}: possible hard-coded secret`);
  if(/postgres(?:ql)?:\/\/[^\s'"`]+:[^\s'"`]+@/i.test(text)) findings.push(`${rel}: database credential URL`);
 }
}
walk(ROOT);
const required=['.gitignore','.env.example','GITHUB_SETUP.md','GITHUB_SECURITY.md','README.md'];
const missing=required.filter(x=>!fs.existsSync(path.join(ROOT,x)));
if(missing.length){console.error('Missing GitHub-prep files:',missing.join(', '));process.exit(1)}
if(findings.length){console.error('Potential secret findings:'); findings.forEach(x=>console.error(' - '+x)); process.exit(1)}
console.log('GitHub preflight: PASS');
console.log('Checked source files for common credential/private-key patterns.');
console.log('Confirmed .gitignore, environment template and GitHub security documentation.');
