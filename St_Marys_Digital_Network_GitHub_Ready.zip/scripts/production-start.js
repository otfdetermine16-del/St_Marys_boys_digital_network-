const {spawnSync}=require('child_process');
const r=spawnSync(process.execPath,['scripts/deploy-preflight.js'],{stdio:'inherit',env:process.env});
if(r.status!==0) process.exit(r.status||1);
const db=require('../db');
(async()=>{try{await db.migrate(); console.log('Production database migrations applied.'); require('../server');}catch(e){console.error('Production startup blocked:',e.message);process.exit(1)}})();
