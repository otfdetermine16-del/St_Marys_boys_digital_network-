# V74.1 — Site Cleanup & Media Update

- Removed the legacy site-wide Settings/Help/Website Information overlay from all HTML pages.
- Removed its obsolete settings.js and dedicated CSS.
- Added the supplied Young Aviators aircraft-landing video to the Young Aviators Club page.
- Added the three supplied school images to MARISCAN ARTISTRY as a featured school collection.
- Kept the existing dynamic admin-managed media system intact.
