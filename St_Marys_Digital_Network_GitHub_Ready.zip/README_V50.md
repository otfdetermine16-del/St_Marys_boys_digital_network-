# St. Mary's Digital Network — V50

Internet Deployment Foundation. See `DEPLOYMENT.md` and `PRODUCTION_READINESS.md`.
