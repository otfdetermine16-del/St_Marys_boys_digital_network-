const list=document.getElementById('notificationList');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
let current='all';
async function api(url,opts){const r=await fetch(url,{credentials:'include',...opts});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Request failed');return d}
function draw(items,unread){
 list.innerHTML=`<div class="notif-toolbar"><div><strong>${unread||0}</strong> unread</div><div class="notif-filters"><button data-filter="all">All</button><button data-filter="unread">Unread</button><button data-filter="high">High priority</button><button id="readAll">Mark all read</button></div></div>`+
 (items.length?items.map(n=>`<article class="notification-item ${(!n.read&&!n.readBy?.length)?'unread':''} priority-${esc(n.priority||'normal')}" data-id="${esc(n.id)}"><div><span class="notif-badge">${esc(n.priority||'normal')}</span><strong>${esc(n.title)}</strong><p>${esc(n.body)}</p><small>${new Date(n.createdAt).toLocaleString()}${n.scheduledAt?' · scheduled':''}</small></div>${(!n.read&&!n.readBy?.length)?'<button class="read-btn">Mark read</button>':''}</article>`).join(''):'<div class="empty-state">No notifications for this filter.</div>');
 document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{current=b.dataset.filter;load()});
 document.getElementById('readAll')?.addEventListener('click',async()=>{await api('/api/notifications/read-all',{method:'POST'});load()});
 document.querySelectorAll('.read-btn').forEach(b=>b.onclick=async()=>{await api('/api/notifications/'+b.closest('.notification-item').dataset.id+'/read',{method:'POST'});load()});
}
async function load(){try{const d=await api('/api/notifications');let items=d.notifications||[];if(current==='unread')items=items.filter(n=>!n.read&&!n.readBy?.length);if(current==='high')items=items.filter(n=>['high','urgent'].includes(n.priority));draw(items,d.unreadCount||0)}catch(e){list.innerHTML='<div class="empty-state">Sign in to view notifications.</div>'}}
load();

async function loadWebNews(){const box=document.getElementById('webNewsList');if(!box)return;box.innerHTML='Loading web news…';try{const d=await api('/api/notifications/web-news');box.innerHTML=d.items.map(x=>`<div class="notification-item"><a href="${esc(x.link)}" target="_blank" rel="noopener"><strong>${esc(x.title)}</strong></a></div>`).join('')||'<p>No web news available.</p>'}catch(e){box.textContent=e.message}}document.getElementById('webNews')?.addEventListener('click',loadWebNews);loadWebNews();
