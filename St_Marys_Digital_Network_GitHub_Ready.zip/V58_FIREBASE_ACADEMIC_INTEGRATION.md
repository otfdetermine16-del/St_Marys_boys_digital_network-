# V58 — Firebase Authentication + Academic Records Integration

## Included
- Firebase Email/Password authentication bridge using the supplied St. Mary's Firebase project configuration.
- Development-only `/api/auth/firebase-sync` bridge that links the Firebase identity to the Network's school account database.
- Existing school database remains the source of truth for academic records, clubs, houses and school content.
- Academic Records page connected to the existing academic record/transcript APIs.
- Teacher/administrator result-entry workflow remains server-side and persists to the database.
- Transcript summary can be printed/saved as PDF from the browser.
- Eight house slots remain editable from Control Centre and are persisted by `/api/admin/houses/bulk`.
- Four approved clubs remain provisioned and editable through the Control Centre and dedicated club pages.
- PostgreSQL migration `003_v58_firebase_identity.sql` prepares the relational accounts table for Firebase UID storage.

## Important testing note
The Firebase sync bridge intentionally accepts the browser-supplied Firebase identity only while the site is in development-open mode. Before public deployment, replace this bridge with server-side Firebase ID-token verification (Firebase Admin SDK or equivalent). The production startup gate remains in place.
