window.SM_DEV_OPEN_ACCESS=true;
/* V30 authentication client bridge.
   The browser stores only a non-sensitive display session; authorization is enforced by server.js. */
const AUTH_KEY='sm_auth_session_v14';
function localSession(){try{return JSON.parse(localStorage.getItem(AUTH_KEY)||'null')}catch{return null}}
function saveSession(user){localStorage.setItem(AUTH_KEY,JSON.stringify({...user,signedInAt:new Date().toISOString()}))}
function getSession(){return localSession()}
async function serverMe(){try{const r=await fetch('/api/me',{credentials:'same-origin'});if(!r.ok)return null;const j=await r.json();if(j.ok){saveSession(j.user);return j.user}}catch{}return null}
async function logout(){try{await fetch('/api/logout',{method:'POST',credentials:'same-origin'})}catch{}localStorage.removeItem(AUTH_KEY);location.href='login.html'}
async function requireRole(roles){
  // Development-open mode: protected pages do not require a sign-in while the site is being built.
  // Production keeps the normal server-authoritative role gate.
  if(window.SM_DEV_OPEN_ACCESS===true){
    const s=await serverMe();
    if(s){saveSession(s);return s;}
    return {id:'SHAIBU-SMB-DEMO-001',name:'Shaibu — Master Account',role:'super_admin',status:'active',systemAccount:true};
  }
  const cached=localSession();if(!cached){location.href='login.html';return null}const s=await serverMe();if(!s){localStorage.removeItem(AUTH_KEY);location.href='login.html';return null}if(roles&&!roles.includes(s.role)&&!(s.role==='super_admin'&&roles.includes('admin'))){location.href='login.html?denied=1';return null}return s}
window.SMAuth={getSession,serverMe,logout,requireRole,saveSession};
document.addEventListener('DOMContentLoaded',()=>{const slot=document.querySelector('[data-auth-user]');const s=localSession();if(slot)slot.textContent=s?s.name:'Guest';});

/* Founder shortcut UI — development only. The server refuses this shortcut in production. */
function installMasterShortcut(){
  const page=(location.pathname.split('/').pop()||'index.html').toLowerCase();
  if(!['login.html','sat.html','sat-practice.html'].includes(page)) return;
  if(document.getElementById('masterShortcut')) return;
  const btn=document.createElement('button');btn.id='masterShortcut';btn.type='button';btn.setAttribute('aria-label','Master access');btn.textContent='+';
  Object.assign(btn.style,{position:'fixed',top:'16px',right:'16px',width:'42px',height:'42px',borderRadius:'50%',border:'1px solid #d0d7e2',background:'#fff',color:'#09245f',fontSize:'25px',fontWeight:'800',lineHeight:'1',cursor:'pointer',zIndex:'99999',boxShadow:'0 8px 24px #0002'});
  document.body.appendChild(btn);
  btn.onclick=()=>{if(document.getElementById('masterOverlay'))return;const o=document.createElement('div');o.id='masterOverlay';Object.assign(o.style,{position:'fixed',inset:'0',background:'#071b49cc',display:'grid',placeItems:'center',zIndex:'100000',padding:'20px'});o.innerHTML='<section style="width:min(390px,100%);background:#fff;border-radius:20px;padding:24px;box-shadow:0 20px 60px #0005;font-family:inherit"><div style="font-size:12px;font-weight:800;letter-spacing:.12em;opacity:.65">FOUNDER ACCESS</div><h2 style="margin:8px 0">Master access</h2><p style="color:#667085">Enter the founder verification name.</p><input id="masterName" autocomplete="off" placeholder="Enter name" style="width:100%;box-sizing:border-box;padding:13px;border:1px solid #ccd3df;border-radius:12px;font-size:16px"><div id="masterMsg" style="min-height:22px;color:#b42318;margin-top:10px"></div><div style="display:flex;gap:10px"><button id="masterCancel" style="flex:1;padding:12px;border:1px solid #ccd3df;border-radius:12px;background:#fff">Cancel</button><button id="masterGo" style="flex:1;padding:12px;border:0;border-radius:12px;background:#09245f;color:#fff;font-weight:800">Enter</button></div><small style="display:block;margin-top:14px;color:#667085">Development shortcut. It is disabled automatically in production.</small></section>';document.body.appendChild(o);const close=()=>o.remove();o.querySelector('#masterCancel').onclick=close;o.querySelector('#masterName').focus();o.querySelector('#masterGo').onclick=async()=>{const msg=o.querySelector('#masterMsg');msg.style.color='#b42318';msg.textContent='Verifying…';try{const r=await fetch('/api/master-access',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:o.querySelector('#masterName').value})});const j=await r.json();if(!r.ok||!j.ok)throw new Error(j.error||'Master access denied.');SMAuth.saveSession(j.user);location.href=(page==='sat.html'||page==='sat-practice.html')?location.href:'admin-studio.html'}catch(e){msg.textContent=e.message||'Master access failed.'}}};
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installMasterShortcut);else installMasterShortcut();
