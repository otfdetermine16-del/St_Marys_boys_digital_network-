# St. Mary's Digital Network V74.3 — Connected Experience Update

V74.3 is a focused upgrade on top of V74.2. Existing school platform files, backend routes, Firebase integration, SAT, academics, clubs, houses, heritage, alumni and MARISCAN ARTISTRY are retained.

## Index / first surface
- The supplied St. Mary's Boys' School entrance photograph is now the dedicated background of `index.html`.
- The photograph is stored as `assets/welcome-campus.jpg` and is used only by the welcome surface.
- The crest, welcome message and entry action remain visible above the image.

## St. Mary's Connect
- Reworked as a real school social/community interface rather than a static Facebook-style mockup.
- Existing server-backed friend requests and private chat retained.
- Directory now returns available profile photographs and class/department information.
- Feed now exposes per-user like state, toggleable Like/Unlike, comments and share tracking.
- Share uses the device share sheet where supported, with link-copy fallback.
- Feed and chat refresh automatically while Connect is open.
- Community posts and attachments remain server-backed and moderation-aware.

## Classes
- Rebuilt the class directory presentation to closely match the supplied reference video: blue school header, light background, department sections, level panels and compact three-column class cards.
- Preserves backend class spaces, join-code flow and protected class pages.
- Department order is Science, General Arts, Visual Arts, Agriculture and Business.
- Existing dynamic class records are not replaced by hard-coded fake classes.

## Deployment
Run `node build-public.js` before Firebase Hosting deployment so the public tree contains the updated browser files without backend/secrets.
