// V44 database adapter. PostgreSQL is the production target; JSON remains the development fallback.
const fs=require('fs'),path=require('path');
const provider=String(process.env.ST_MARYS_DB_PROVIDER||'json').toLowerCase();
let pool=null;
let stateCache=null;
let writeChain=Promise.resolve();
async function getPool(){
  if(provider!=='postgres') return null;
  if(pool) return pool;
  let pg;
  try{pg=require('pg');}catch(e){throw new Error('PostgreSQL provider selected but the pg package is not installed. Run npm install.');}
  const connectionString=process.env.DATABASE_URL;
  if(!connectionString) throw new Error('ST_MARYS_DB_PROVIDER=postgres requires DATABASE_URL.');
  pool=new pg.Pool({connectionString,max:Number(process.env.DB_POOL_MAX||20),idleTimeoutMillis:Number(process.env.DB_IDLE_TIMEOUT_MS||30000),connectionTimeoutMillis:Number(process.env.DB_CONNECT_TIMEOUT_MS||10000),statement_timeout:Number(process.env.DB_STATEMENT_TIMEOUT_MS||15000),ssl:(process.env.DB_SSL||process.env.ST_MARYS_DB_SSL)==='false'?false:{rejectUnauthorized:false}});
  return pool;
}
async function query(text,params=[]){const p=await getPool();if(!p)throw new Error('PostgreSQL provider is not enabled.');return p.query(text,params)}
async function loadState(){
  if(provider!=='postgres') return null;
  const r=await query('SELECT state FROM application_state WHERE id=1');
  if(!r.rows.length) return null;
  stateCache=r.rows[0].state;
  return stateCache;
}
async function saveState(state){
  if(provider!=='postgres') return {provider:'json-development',persisted:false};
  stateCache=state;
  writeChain=writeChain.then(()=>query(`INSERT INTO application_state(id,state,updated_at) VALUES(1,$1,now()) ON CONFLICT(id) DO UPDATE SET state=EXCLUDED.state, updated_at=now()`,[state]));
  await writeChain;
  return {provider:'postgres',persisted:true};
}
async function health(){
  if(provider==='postgres'){const p=await getPool();const r=await p.query('SELECT current_database() database, now() server_time');return {provider:'postgres',ok:true,database:r.rows[0].database,serverTime:r.rows[0].server_time};}
  return {provider:'json-development',ok:true,database:'server-data.json',note:'Use PostgreSQL in production.'};
}
async function close(){if(pool){await pool.end();pool=null}}
function migrationFiles(){return fs.readdirSync(path.join(__dirname,'database','migrations')).filter(f=>f.endsWith('.sql')).sort();}
async function migrate(){
  const p=await getPool(); if(!p) return {provider:'json-development',applied:[],note:'Migrations are prepared for PostgreSQL production mode.'};
  await p.query('CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())');
  const applied=(await p.query('SELECT version FROM schema_migrations')).rows.map(r=>r.version);
  const done=[];
  for(const file of migrationFiles()) if(!applied.includes(file)){
    const sql=fs.readFileSync(path.join(__dirname,'database','migrations',file),'utf8');
    const client=await p.connect(); try{await client.query('BEGIN');await client.query(sql);await client.query('INSERT INTO schema_migrations(version) VALUES($1)',[file]);await client.query('COMMIT');done.push(file)}catch(e){await client.query('ROLLBACK');throw e}finally{client.release();}
  }
  return {provider:'postgres',applied:done};
}
module.exports={provider,query,health,migrate,loadState,saveState,close};
