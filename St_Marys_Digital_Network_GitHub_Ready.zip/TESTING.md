# V46 — Testing Laboratory

V46 adds an isolated, repeatable test laboratory for the St. Mary's Digital Network.

## Run

```bash
npm test
```

Smoke-only checks:

```bash
npm run test:smoke
```

The test runner starts a temporary local server in development-open mode and uses `ST_MARYS_DATA_FILE` so it does **not** modify the normal `server-data.json`. The temporary file is removed after the run.

## Coverage

- V46 health/readiness/infrastructure endpoints
- Development identity and account boundaries
- 63-class catalogue
- Approved club catalogue
- Activities, houses, heritage, media
- Notifications and search
- MARISCAN AI status/query
- Academic records/transcript endpoints
- St. Mary's Connect publishing, moderation, unique likes, repeated comments and takedown
- Admin summary/database health
- Bearer admin endpoint in development mode
- Required application artifacts
- Static local HTML references
- Production security gate recognition

## Important

The test laboratory intentionally uses development-open mode. This is **not** a production security test configuration. Before V49 internet deployment, production must run with `NODE_ENV=production`, `ST_MARYS_DEV_OPEN_ACCESS=false`, real secrets, production authentication, HTTPS and the production security framework enabled.
