/* V74.3 — classes directory rebuilt to match the supplied mobile reference while preserving backend access. */
(async function(){
 'use strict';
 const root=document.getElementById('classDirectory'),msg=document.getElementById('joinMessage');
 const order=['Science','General Arts','Visual Arts','Agriculture','Business'];
 const info={
  'Science':{code:'SCI',count:6,desc:'Physics, Biology, Chemistry, Computer Science and Elective Mathematics.'},
  'General Arts':{code:'ART',count:6,desc:'Humanities, social sciences, languages, communication and critical thinking.'},
  'Visual Arts':{code:'VAT',count:5,desc:'Art, design, creative practice, performing arts and ICT.'},
  'Agriculture':{code:'AGR',count:2,desc:'Agriculture, animal and crop husbandry, science and applied learning.'},
  'Business':{code:'BUS',count:2,desc:'Accounting, business management, economics, ICT and entrepreneurship.'}
 };
 const levels=['SHS 1','SHS 2','SHS 3'];
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
 async function me(){const r=await fetch('/api/me',{credentials:'same-origin'});if(!r.ok){location.href='login.html';return null}return (await r.json()).user}
 async function load(){const u=await me();if(!u)return;const r=await fetch('/api/classes',{credentials:'same-origin'});const j=await r.json();if(!r.ok){root.innerHTML='<div class="card">Unable to load classes.</div>';return}render(j.classes||[])}
 function render(classes){
   const groups={}; for(const c of classes){const dep=c.department||'Other';(groups[dep]??=[]).push(c)}
   const deps=[...order,...Object.keys(groups).filter(x=>!order.includes(x))];
   root.innerHTML=deps.filter(dep=>groups[dep]?.length).map(dep=>{
    const meta=info[dep]||{code:dep.slice(0,3).toUpperCase(),count:0,desc:'Protected class spaces for the school community.'};
    const rows=groups[dep];
    return `<section class="department-class-block"><div class="class-dept-head"><div><span class="eyebrow">${esc(meta.code)}</span><h2>${esc(dep)} Department</h2><p>${esc(meta.desc)}</p></div><span class="badge">${meta.count||rows.length} classes / level</span></div>${levels.map(level=>{const rs=rows.filter(c=>c.year===level);if(!rs.length)return '';return `<div class="class-level"><h3>${esc(level)}</h3><div class="class-cards">${rs.map(c=>`<a class="class-card" href="class.html?id=${encodeURIComponent(c.id)}"><div><span>${esc(c.code)}</span><h4>${esc(c.name)}</h4><p>${c.teacherIds?.length||0} teacher(s) · Private class space</p></div><b>Open →</b></a>`).join('')}</div></div>`}).join('')}</section>`;
   }).join('')||'<div class="card"><h2>No class spaces available</h2><p class="muted">Ask an authorized teacher or administrator to assign your class.</p></div>';
 }
 document.getElementById('joinClass').onclick=async()=>{const code=document.getElementById('classCode').value.trim();if(!code){msg.textContent='Enter a class join code.';msg.style.display='block';return}const r=await fetch('/api/classes',{credentials:'same-origin'});const j=await r.json();if(!r.ok){msg.textContent='Please sign in first.';msg.style.display='block';return}let joined=null;for(const c of (j.classes||[])){const x=await fetch(`/api/classes/${encodeURIComponent(c.id)}/join`,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({joinCode:code})});if(x.ok){joined=(await x.json()).class;break}}if(joined){msg.textContent=`Access granted: ${joined.name}.`;msg.style.display='block';setTimeout(()=>location.href='class.html?id='+encodeURIComponent(joined.id),450);return}msg.textContent='That join code is invalid, expired, or not active.';msg.style.display='block'};
 load();
})();
