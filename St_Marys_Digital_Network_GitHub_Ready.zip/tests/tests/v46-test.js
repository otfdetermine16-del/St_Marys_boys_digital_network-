#!/usr/bin/env node
/* St. Mary's Digital Network — V50 Internet Deployment Foundation Verification
 * Uses an isolated temporary JSON data file so tests never modify the working database.
 */
const fs=require('fs'), path=require('path'), http=require('http'), {spawn}=require('child_process');
const ROOT=path.resolve(__dirname,'..');
const PORT=39846; const tempData=path.join(ROOT,'.v46-test-server-data.json');
const smokeOnly=process.argv.includes('--smoke-only');
let child; let passed=0, failed=0;
function log(ok,name,detail=''){if(ok){passed++;console.log(`✓ ${name}${detail?` — ${detail}`:''}`)}else{failed++;console.error(`✗ ${name}${detail?` — ${detail}`:''}`)}}
function request(method,p,data,headers={}){return new Promise((resolve,reject)=>{const body=data===undefined?null:JSON.stringify(data);const req=http.request({hostname:'127.0.0.1',port:PORT,path:p,method,headers:{...(body?{'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)}:{}),...headers}},res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{let json;try{json=JSON.parse(d)}catch{}resolve({status:res.statusCode,headers:res.headers,body:d,json})})});req.on('error',reject);if(body)req.write(body);req.end()})}
async function waitForServer(){for(let i=0;i<60;i++){try{const r=await request('GET','/api/health');if(r.status===200)return true}catch{}await new Promise(r=>setTimeout(r,100));}return false}
function assert(name,condition,detail){log(!!condition,name,detail);}
async function run(){
  try{
    if(fs.existsSync(tempData))fs.unlinkSync(tempData);
    child=spawn(process.execPath,['server.js'],{cwd:ROOT,env:{...process.env,PORT:String(PORT),NODE_ENV:'development',ST_MARYS_DEV_OPEN_ACCESS:'true',ST_MARYS_DATA_FILE:tempData},stdio:['ignore','pipe','pipe']});
    child.stdout.on('data',d=>process.stdout.write(`[server] ${d}`)); child.stderr.on('data',d=>process.stderr.write(`[server:err] ${d}`));
    assert('Server starts',await waitForServer());

    let r=await request('GET','/api/health'); assert('Health endpoint',r.status===200&&r.json?.version==='V50',JSON.stringify(r.json));
    r=await request('GET','/api/ready'); assert('Readiness endpoint',r.status===200&&r.json?.ready===true&&r.json?.version==='V50');
    r=await request('GET','/api/infra/health'); assert('Infrastructure health',r.status===200&&r.json?.ok===true&&r.json?.scaling?.loadBalancerReady===true);
    r=await request('GET','/api/infra/metrics'); assert('Infrastructure metrics',r.status===200&&r.json?.version==='V50');
    r=await request('GET','/api/me'); assert('Development identity',r.status===200&&r.json?.user?.role==='super_admin');
    r=await request('GET','/api/site-config'); assert('Public site config',r.status===200&&!!r.json);
    r=await request('GET','/api/classes'); assert('Class catalogue',r.status===200&&Array.isArray(r.json?.classes)&&r.json.classes.length===63,`classes=${r.json?.classes?.length}`);
    r=await request('GET','/api/clubs'); assert('Club catalogue',r.status===200&&Array.isArray(r.json?.clubs)&&r.json.clubs.some(c=>c.name==='CADET CORP AND REGIMENTAL BAND')&&!r.json.clubs.some(c=>c.name==='Geography Club'));
    r=await request('GET','/api/activities'); assert('Activities endpoint',r.status===200&&Array.isArray(r.json?.activities));
    r=await request('GET','/api/houses'); assert('Houses endpoint',r.status===200&&Array.isArray(r.json?.houses));
    r=await request('GET','/api/heritage'); assert('Heritage endpoint',r.status===200);
    r=await request('GET','/api/media'); assert('Media endpoint',r.status===200&&Array.isArray(r.json?.media));
    r=await request('GET','/api/notifications'); assert('Notifications endpoint',r.status===200);
    r=await request('GET','/api/notifications/unread-count'); assert('Notification unread count',r.status===200&&typeof r.json?.count==='number');
    r=await request('GET','/api/search?q=school'); assert('Universal search',r.status===200&&Array.isArray(r.json?.results));
    r=await request('GET','/api/search/suggestions?q=sch'); assert('Search suggestions',r.status===200&&Array.isArray(r.json?.suggestions));
    r=await request('GET','/api/ai/status'); assert('MARISCAN AI status',r.status===200&&r.json?.ok===true);
    r=await request('POST','/api/ai/query',{question:'What is the school motto?'}); assert('MARISCAN AI query',r.status===200&&/Disce Ut Doceas/i.test(r.json?.assistant?.answer||''));
    r=await request('GET','/api/account/profile'); assert('Account profile',r.status===200&&r.json?.profile);
    r=await request('GET','/api/account/academic'); assert('Academic records privacy boundary',r.status===200&&Array.isArray(r.json?.records));
    r=await request('GET','/api/account/transcript'); assert('Transcript endpoint',r.status===200);
    r=await request('GET','/api/connect/posts'); assert('Connect feed',r.status===200&&Array.isArray(r.json?.posts));
    const post=await request('POST','/api/connect/posts',{title:'V50 Test Article',content:'Automated testing laboratory post.',type:'Article'});
    assert('Connect publishing creates moderated post',post.status===201&&post.json?.post?.status==='published');
    const pid=post.json?.post?.id;
    r=await request('GET','/api/admin/connect/posts'); assert('Admin Connect moderation',r.status===200&&Array.isArray(r.json?.posts));
    if(pid){
      r=await request('PATCH','/api/admin/connect/posts',{id:pid,action:'publish'}); assert('Published Connect post cannot be republished',r.status===409);
      r=await request('POST',`/api/connect/posts/${pid}/like`,{}); assert('Unique like first attempt',r.status===201&&r.json?.liked===true);
      r=await request('POST',`/api/connect/posts/${pid}/like`,{}); assert('Duplicate like rejected server-side',r.status===409);
      r=await request('POST',`/api/connect/posts/${pid}/comments`,{text:'First test comment'}); assert('Connect comments accepted',r.status===201);
      r=await request('POST',`/api/connect/posts/${pid}/comments`,{text:'Second test comment'}); assert('Repeated comments accepted',r.status===201);
      r=await request('POST','/api/admin/connect/posts/takedown',{id:pid,reason:'V50 automated test cleanup'}); assert('Admin takedown works',r.status===200&&r.json?.post?.status==='archived');
    }
    r=await request('GET','/api/admin/summary'); assert('Admin summary',r.status===200);
    r=await request('GET','/api/admin/database'); assert('Admin database health',r.status===200&&r.json?.database?.provider==='json-development');
    r=await request('GET','/admin/settings'); assert('Bearer admin endpoint in development mode',r.status===200);
    // Static integrity checks.
    const required=['index.html','home.html','classes.html','class.html','network.html','heritage.html','activities.html','media-admin.html','admin-control.html','creator-story.html','server.js','db.js','infrastructure.js'];
    for(const f of required)assert(`Required artifact: ${f}`,fs.existsSync(path.join(ROOT,f)));
    const htmls=fs.readdirSync(ROOT).filter(f=>f.endsWith('.html'));
    let broken=0; for(const f of htmls){const s=fs.readFileSync(path.join(ROOT,f),'utf8');for(const m of s.matchAll(/(?:src|href)=["']([^"']+)["']/g)){const ref=m[1];if(!ref||ref.includes('${')||/^(https?:|mailto:|#|data:|javascript:|\/)/i.test(ref))continue;const clean=ref.split('?')[0].split('#')[0];if(clean&& !fs.existsSync(path.join(ROOT,clean)))broken++;}}
    assert('Static local references resolve',broken===0,`broken=${broken}`);
    const serverText=fs.readFileSync(path.join(ROOT,'server.js'),'utf8');
    assert('Production security remains gated',/NODE_ENV !== 'production'/.test(serverText)&&/ST_MARYS_DEV_OPEN_ACCESS/.test(serverText)&&/ST_MARYS_ADMIN_API_TOKEN/.test(serverText));
    if(!smokeOnly){
      r=await request('GET','/api/pta'); assert('PTA endpoint',r.status===200);
      r=await request('GET','/api/publishing'); assert('Publishing endpoint',r.status===200);
      r=await request('GET','/api/alumni'); assert('Alumni endpoint',r.status===200);
      r=await request('GET','/api/achievements'); assert('Achievements endpoint',r.status===200);
      r=await request('GET','/api/clubs'); assert('Approved clubs retained',r.json.clubs.length===4,`clubs=${r.json.clubs.length}`);
    }
  }catch(e){failed++;console.error('✗ Test runner error:',e.stack||e)}
  finally{
    if(child)child.kill('SIGTERM');
    setTimeout(()=>{try{if(fs.existsSync(tempData))fs.unlinkSync(tempData)}catch{};console.log(`\nV50 RESULT: ${passed} passed, ${failed} failed`);process.exitCode=failed?1:0},200);
  }
}
run();
