const fs=require('fs'),assert=require('assert');
const h=fs.readFileSync('home.html','utf8'),c=fs.readFileSync('home-v52.css','utf8');
for(const x of ['assets/campus-gate-clear.jpg','home-v52.css','home-v52.js','heritage.html','classes.html','connect.html','activities.html']) assert(h.includes(x),`missing: ${x}`);
assert(!/class="nav-login"/.test(h),'homepage keeps sign-in out of the primary institutional row');
assert(h.includes('data-sm-nav="off"'),'duplicate side navigation disabled on the reference-style homepage');
assert(!h.includes('v20-it-control.html')&&!h.includes('Coming Soon')&&!h.includes('Prototype only')&&!h.includes('Come here dear one'),'stale homepage content remains');
assert(c.includes('.sm-hero-panel{background:#0b459f')&&c.includes('.sm-hero-image img'),'homepage styling missing');
assert(fs.existsSync('assets/campus-gate-clear.jpg'),'campus image missing');
console.log('V52 homepage checks passed.');
