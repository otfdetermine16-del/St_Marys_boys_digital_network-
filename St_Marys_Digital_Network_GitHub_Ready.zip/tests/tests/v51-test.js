const assert=require('assert');
const fs=require('fs');
const path=require('path');
const pkg=require('../package.json');
const db=require('../db');
const serverSource=fs.readFileSync(path.join(__dirname,'..','server.js'),'utf8');
let passed=0;
function ok(name,fn){try{fn();passed++;console.log('PASS',name)}catch(e){console.error('FAIL',name,e.message);process.exitCode=1}}
ok('package version is current integrated release',()=>assert.ok(Number(pkg.version.split('.')[0])>=54));
ok('production requires PostgreSQL',()=>assert(serverSource.includes("ST_MARYS_DB_PROVIDER")&&serverSource.includes("Production requires ST_MARYS_DB_PROVIDER=postgres")));
ok('production requires strong session secret',()=>assert(serverSource.includes("SESSION_SECRET.length<32")));
ok('JSON remains development-only',()=>assert(serverSource.includes('json-development')));
ok('PostgreSQL application state migration exists',()=>assert(fs.existsSync(path.join(__dirname,'..','database','migrations','002_application_state.sql'))));
ok('database adapter exports state persistence',()=>assert.equal(typeof db.loadState,'function')&&assert.equal(typeof db.saveState,'function'));
ok('database adapter exposes PostgreSQL provider switch',()=>assert(['json','postgres'].includes(db.provider)));
ok('server loads production state cache',()=>assert(serverSource.includes('productionState=await database.loadState()')));
ok('server persists mutations through PostgreSQL',()=>assert(serverSource.includes('database.saveState(db)')));
ok('write queue serializes PostgreSQL state writes',()=>{const src=fs.readFileSync(path.join(__dirname,'..','db.js'),'utf8');assert(src.includes('writeChain=writeChain.then'))});
ok('V44 relational schema retained',()=>assert(fs.existsSync(path.join(__dirname,'..','database','migrations','001_initial.sql'))));
ok('deployment gate remains present',()=>assert(fs.existsSync(path.join(__dirname,'..','scripts','deploy-preflight.js'))));
if(!process.argv.includes('--smoke-only')){
 ok('no plaintext master password in server source',()=>assert(!serverSource.includes('ST_MARYS_MASTER_PASSWORD')));
 ok('production open access is rejected',()=>assert(serverSource.includes('V53 open test mode cannot run in production. Add the new production security layer first.')));
}
console.log(`V51 tests: ${passed} passed`);
if(process.exitCode) process.exit(1);
