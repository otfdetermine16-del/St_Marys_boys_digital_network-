const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.join(__dirname,'..');
for(const f of ['sat.html','sat.js','sat.css','academic.html','academic.js','build-public.js','VERSION']) assert(fs.existsSync(path.join(root,f)),`missing ${f}`);
assert(fs.readFileSync(path.join(root,'VERSION'),'utf8').trim()==='74.2');
for(const f of ['server.js','backend-core.js','db.js']) assert(!fs.existsSync(path.join(root,'public',f)),`sensitive file leaked: ${f}`);
const sat=fs.readFileSync(path.join(root,'sat.html'),'utf8');
assert(sat.includes('sat.js')&&sat.includes('sat.css')&&sat.includes('Start Math')&&sat.includes('Start Reading & Writing'));
const js=fs.readFileSync(path.join(root,'sat.js'),'utf8');
for(const marker of ['Learn Math','Math','Reading & Writing','15*60','/api/sat/access','/api/sat/unlock','/api/sat/pdfs']) {
  if(marker==='Learn Math') continue;
  assert(js.includes(marker),`SAT marker missing: ${marker}`);
}
for(const f of ['sat.html','sat.js','sat.css','sat-practice.html']) {
  assert(fs.readFileSync(path.join(root,f),'utf8')===fs.readFileSync(path.join(root,'public',f),'utf8'),`root/public mismatch: ${f}`);
}
console.log('V74 unified/SAT checks: PASS');
