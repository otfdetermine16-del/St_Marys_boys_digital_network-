const assert=require('assert'),fs=require('fs'),path=require('path'),http=require('http'),{spawn}=require('child_process');
const port=33200+Math.floor(Math.random()*500), data=path.join(__dirname,'v52-final-test-data.json');
try{fs.unlinkSync(data)}catch{}
const child=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,PORT:String(port),NODE_ENV:'development',ST_MARYS_DATA_FILE:data,ST_MARYS_DEV_OPEN_ACCESS:'true'},stdio:['ignore','pipe','pipe']});
let ready=false; child.stdout.on('data',d=>{if(String(d).includes('running at'))ready=true});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function req(p,o={}){return fetch(`http://127.0.0.1:${port}${p}`,o)}
(async()=>{try{for(let i=0;i<30&&!ready;i++)await sleep(100);assert(ready,'server did not start');
 let r=await req('/home.html');assert.equal(r.status,200);
 r=await req('/api/site-access');assert((await r.json()).required===false);
 r=await req('/api/admin/site-access/rotate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:'SchoolCode52',required:true})});assert.equal(r.status,200);
 r=await req('/home.html',{redirect:'manual'});assert.equal(r.status,200);
 r=await req('/api/site-access',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:'SchoolCode52'})});assert.equal(r.status,200);

 r=await req('/api/clubs');const clubs=(await r.json()).clubs;assert(clubs.some(x=>x.name==='DRAMAS, WRITERS & DEBATORS CLUB'));assert(clubs.some(x=>x.name==='CADET CORP AND REGIMENTAL BAND'));
 r=await req('/api/suggestions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:'Test',body:'Suggestion'})});assert.equal(r.status,201);
 r=await req('/api/ai/query',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:'What is the school motto?'})});const ai=await r.json();assert.equal(r.status,200);assert(ai.assistant.answer.includes('Disce Ut Doceas'));
 console.log('V52 final integration checks passed.');
}catch(e){console.error('V52 final integration test failed:',e.message);process.exitCode=1}finally{child.kill('SIGTERM');try{fs.unlinkSync(data)}catch{}}})();
