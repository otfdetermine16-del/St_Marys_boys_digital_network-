const http=require('http');
const base=process.env.TEST_BASE||'http://127.0.0.1:3110';
function req(path){return new Promise((resolve,reject)=>{http.get(base+path,r=>{let b='';r.on('data',x=>b+=x);r.on('end',()=>{let j;try{j=JSON.parse(b)}catch{}resolve({status:r.statusCode,body:b,json:j})})}).on('error',reject)})}
(async()=>{
 const h=await req('/api/health'); if(h.status!==200) throw Error('health failed');
 const s=await req('/api/search?q=Science&type=all&page=1&limit=20'); if(s.status!==200||!Array.isArray(s.json?.results)) throw Error('search failed');
 const g=await req('/api/search?q=school&web=1'); if(g.status!==200||g.json?.webSearched!==true) throw Error('web search mode failed');
 console.log('Search V55 checks passed');
})().catch(e=>{console.error(e);process.exit(1)})
