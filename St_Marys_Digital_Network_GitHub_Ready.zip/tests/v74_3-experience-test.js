const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
function assert(c,m){if(!c)throw new Error(m)}
const index=fs.readFileSync(path.join(root,'index.html'),'utf8');
const connect=fs.readFileSync(path.join(root,'connect.html'),'utf8');
const social=fs.readFileSync(path.join(root,'social.js'),'utf8');
const classes=fs.readFileSync(path.join(root,'classes.html'),'utf8');
const classjs=fs.readFileSync(path.join(root,'classes.js'),'utf8');
const server=fs.readFileSync(path.join(root,'server.js'),'utf8');
assert(fs.existsSync(path.join(root,'assets','welcome-campus.jpg')),'welcome image missing');
assert(index.includes('assets/welcome-campus.jpg'),'index welcome background missing');
assert(connect.includes('connect.css')&&connect.includes('composerTrigger'),'Connect social UI missing');
assert(social.includes('/connect/posts/')&&social.includes('/chat/messages/')&&social.includes('/chat/requests'),'Connect backend actions missing');
assert(social.includes("/share")&&social.includes("/like")&&social.includes("/comments"),'Connect interactions missing');
assert(classes.includes('classes-v743.css'),'classes reference stylesheet missing');
assert(classjs.includes('Science')&&classjs.includes('General Arts')&&classjs.includes('Visual Arts')&&classjs.includes('Agriculture')&&classjs.includes('Business'),'class department order missing');
assert(server.includes('connectPostViewMatch')&&server.includes('connectLikeMatch')&&server.includes('connectShareMatch'),'Connect interaction routes missing');
assert(server.includes('authorPhotoAsset')&&server.includes('outgoing'),'Connect profile/request enhancements missing');
console.log('V74.3 experience checks: PASS');
