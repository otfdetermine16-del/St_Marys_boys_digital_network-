/* St. Mary's Digital Network — V12 Data Architecture
   Prototype schema: documents how production records should relate.
   This file does NOT provide security or real authentication.
*/
window.SM_SCHEMA = {
  version: '12.0',
  entities: {
    school: ['id','name','motto','location','contact','crestAsset'],
    academicYear: ['id','label','startDate','endDate','status'],
    department: ['id','name','status','sortOrder'],
    classGroup: ['id','departmentId','academicYearId','level','name','joinCode','status'],
    person: ['id','personType','name','studentId','staffId','departmentId','classGroupId','photoAsset','status'],
    account: ['id','personId','email','roleIds','status','lastLoginAt'],
    role: ['id','name','permissions'],
    club: ['id','name','description','patronPersonId','founderPersonId','foundedYear','status'],
    clubMembership: ['id','clubId','personId','membershipRole','status','joinedAt'],
    post: ['id','authorPersonId','channel','title','body','visibility','status','publishedAt'],
    comment: ['id','postId','authorPersonId','body','status','createdAt'],
    reaction: ['id','postId','personId','type','createdAt'],
    resource: ['id','ownerType','ownerId','title','fileAssetId','visibility','status'],
    assignment: ['id','classGroupId','teacherPersonId','title','dueAt','resourceIds','status'],
    event: ['id','title','description','startAt','endAt','location','visibility','status'],
    achievement: ['id','subjectType','subjectId','title','description','date','verificationStatus'],
    mediaAsset: ['id','fileName','storageKey','caption','category','visibility','reviewStatus','uploadedBy','createdAt'],
    notification: ['id','recipientPersonId','title','body','readAt','createdAt'],
    auditLog: ['id','actorAccountId','action','entityType','entityId','timestamp','metadata'],
    handover: ['id','fromAccountId','toAccountId','approvedBy','timestamp','notes']
  },
  relationships: [
    'department 1→many classGroup',
    'academicYear 1→many classGroup',
    'classGroup 1→many person',
    'person 1→0..1 account',
    'person many→many club through clubMembership',
    'person 1→many post/comment/reaction/achievement',
    'classGroup 1→many assignment',
    'post 1→many comment/reaction',
    'resource 1→many assignment',
    'person 1→many notification',
    'account 1→many auditLog',
    'mediaAsset can be referenced by school/person/club/post/resource/achievement'
  ]
};
