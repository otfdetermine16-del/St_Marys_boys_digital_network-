/* V29 — St. Mary's retractable left navigation. */
(() => {
  const items = [
    ["Home", "home.html", "⌂"],
    ["Academics", "academic.html", "▦"],
    ["St. Mary's Connect", "connect.html", "◉"],
    ["Heritage", "heritage.html", "◈"],
    ["Student Hub", "student-hub.html", "◎"],
    ["More", "community.html", "⋯"],
    ["Alumni", "alumni.html", "♧"],
    ["Search", "search.html", "⌕"],
    ["Notifications", "notifications.html", "♢"],
    ["Clubs & Achievements", "activities.html", "★"],
    ["Suggestion Box", "suggestions.html", "✎"],
    ["Chat", "chat.html", "◌"],
    ["MARISCAN AI", "ai.html", "✦"],
    ["MARISCAN ARTISTRY", "media-centre.html", "▣"]
  ];

  function mount() {
    if (document.body.dataset.smNav === "off" || /(?:^|\/)login\.html$/i.test(location.pathname)) return;
    if (document.querySelector(".sm-explore-nav")) return;

    const nav = document.createElement("aside");
    nav.className = "sm-explore-nav is-collapsed";
    nav.setAttribute("aria-label", "Explore your school");
    nav.innerHTML = `
      <div class="sm-explore-head">
        <img class="sm-explore-mark" src="assets/crest-lively.jpg" alt="St. Mary's Boys School crest">
        <div>
          <span class="sm-explore-kicker">ST. MARY'S</span>
          <strong>Explore your school</strong>
        </div>
      </div>
      <div class="sm-explore-links">
        ${items.map(([label, href, icon]) => `<a href="${href}" title="${label}"><span class="sm-explore-icon" aria-hidden="true">${icon}</span><span>${label}</span></a>`).join("")}
      </div>
      <button class="sm-explore-close" type="button" aria-label="Retract school navigation">‹</button>
    `;
    document.body.appendChild(nav);

    const edge = document.createElement("button");
    edge.className = "sm-explore-edge";
    edge.type = "button";
    edge.setAttribute("aria-label", "Open school navigation");
    edge.innerHTML = "☰";
    document.body.appendChild(edge);

    let timer;
    const open = (auto = true) => {
      nav.classList.remove("is-collapsed");
      nav.classList.add("is-open");
      edge.classList.add("is-hidden");
      clearTimeout(timer);
      if (auto) timer = setTimeout(() => collapse(), 5200);
    };
    const collapse = () => {
      clearTimeout(timer);
      nav.classList.remove("is-open");
      nav.classList.add("is-collapsed");
      edge.classList.remove("is-hidden");
    };

    edge.addEventListener("click", () => open(false));
    nav.querySelector(".sm-explore-close").addEventListener("click", collapse);
    nav.addEventListener("pointerenter", () => clearTimeout(timer));
    nav.addEventListener("pointerleave", () => timer = setTimeout(collapse, 3000));
    nav.addEventListener("focusin", () => clearTimeout(timer));
    nav.addEventListener("focusout", () => timer = setTimeout(collapse, 3000));
    nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => clearTimeout(timer)));

    document.addEventListener("keydown", e => {
      if (e.key === "Escape") collapse();
      if (e.key === "m" && !e.ctrlKey && !e.metaKey && !e.altKey) open(false);
    });

    // Give touch users an easy way to reveal it without keeping it permanently open.
    document.addEventListener("touchstart", e => {
      if (!nav.contains(e.target) && !edge.contains(e.target)) collapse();
    }, { passive: true });

    // Start collapsed so the page remains visually clean.
    collapse();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();
