# V65 — Backend Core Rebuild

V65 strengthens the backend foundation instead of adding another frontend-only patch.

## Included
- Atomic JSON development persistence with `.bak` snapshots and corrupt-file recovery.
- PostgreSQL connection pool limits/timeouts and durable migration 004.
- Stateless HMAC-signed production sessions so authentication can work across multiple backend instances.
- Production password bootstrap through `ST_MARYS_MASTER_PASSWORD` (hashed once; never shipped to browser code) or precomputed `ST_MARYS_MASTER_HASH` + `ST_MARYS_MASTER_SALT`.
- API and login rate limiting.
- Security response headers and production HSTS.
- `/api/backend/status` and `/api/admin/backend/diagnostics` operational endpoints.
- Additional database indexes for accounts, classes, memberships, Connect, media and audit/event data.
- Existing school modules remain intact.

## Production requirements
Set at minimum:
- `NODE_ENV=production`
- `SESSION_SECRET` (32+ random characters)
- `ST_MARYS_DB_PROVIDER=postgres`
- `DATABASE_URL`
- Firebase/OpenAI/YouTube secrets where those services are used.

Do not put production passwords or API keys into HTML, JavaScript, GitHub, or Firebase Hosting public files.
