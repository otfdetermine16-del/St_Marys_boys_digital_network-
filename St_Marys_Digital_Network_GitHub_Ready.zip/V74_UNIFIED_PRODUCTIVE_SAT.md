# V74 — Unified Productive Platform + SAT Practice Upgrade

V74 builds on V73.1. The goal is a cleaner production path with less duplicated UI logic and a stronger SAT experience.

## Platform cleanup
- `build-public.js` is the single synchronization utility for the Firebase Hosting `public/` tree.
- Root files remain the canonical editable source; the public tree can be regenerated after changes.
- Sensitive server files are excluded from the public tree.
- The SAT experience uses shared `sat.css` + `sat.js` rather than duplicated inline page logic.
- `sat-practice.html` is now a lightweight compatibility redirect to the unified SAT Centre.

## SAT Practice Centre
- Administrator-controlled access remains server-authoritative.
- Original school-created SAT-style questions are embedded in the practice engine.
- Math and Reading & Writing sections.
- 15-minute timed sessions.
- Progress bar and question navigator.
- Answer review and explanations.
- Session scoring and accuracy.
- Retry/change-section controls.
- Protected administrator-uploaded SAT PDFs remain available through existing protected routes.
- Official College Board and Khan Academy preparation links remain clearly separated from school-created material.

## Validation
- JavaScript syntax checks pass for SAT, Academic and public-build tooling.
- Public tree contains no `server.js`, `backend-core.js`, or `db.js` copies.
- Root/public SAT assets are synchronized.
