/* St. Mary's Digital Network — interaction foundation. */
(function(){
  'use strict';
  const style=document.createElement('style');
  style.textContent=`
    a,button,[role="button"]{-webkit-tap-highlight-color:transparent}
    a[href],button:not(:disabled),[role="button"]{cursor:pointer}
    a:not([aria-disabled="true"]):hover,button:not(:disabled):hover,[role="button"]:hover{filter:brightness(.985)}
    .sm-action-toast{position:fixed;left:50%;bottom:24px;transform:translate(-50%,14px);z-index:9998;background:#071a3a;color:#fff;padding:11px 16px;border-radius:12px;box-shadow:0 12px 32px rgba(0,0,0,.18);font:700 .82rem system-ui,sans-serif;opacity:0;pointer-events:none;transition:opacity .18s,transform .18s;max-width:min(440px,calc(100vw - 30px));text-align:center}
    .sm-action-toast.is-visible{opacity:1;transform:translate(-50%,0)}
    .sm-more-close{display:flex!important;align-items:center;justify-content:space-between;width:100%;padding:8px 10px;margin-bottom:5px;border:0;border-bottom:1px solid #e5e9f1;background:transparent;color:#667085;font:700 .72rem system-ui,sans-serif;cursor:pointer}
    .sm-more-close:hover{background:#f5f7fb}
  `;
  document.head.appendChild(style);
  let toastTimer;
  function toast(message){let t=document.querySelector('.sm-action-toast');if(!t){t=document.createElement('div');t.className='sm-action-toast';t.setAttribute('role','status');document.body.appendChild(t)}t.textContent=message;t.classList.add('is-visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('is-visible'),2800)}
  window.SMNetworkUI={toast};
  document.addEventListener('DOMContentLoaded',()=>{
    const details=document.querySelector('.nav-more');
    if(details){
      const menu=details.querySelector('.nav-more-menu');
      if(menu && !menu.querySelector('.sm-more-close')) menu.insertAdjacentHTML('afterbegin','<button type="button" class="sm-more-close" aria-label="Close More menu"><span>More</span><strong>×</strong></button>');
      const close=()=>details.removeAttribute('open');
      menu?.querySelector('.sm-more-close')?.addEventListener('click',close);
      menu?.querySelectorAll('a').forEach(a=>a.addEventListener('click',close));
      document.addEventListener('click',e=>{if(details.open&&!details.contains(e.target))close()});
      document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
    }
  });
  document.addEventListener('click',e=>{const target=e.target.closest('[data-prototype-action]');if(!target)return;e.preventDefault();toast(target.dataset.prototypeAction||'This feature is being prepared for the secure platform version.')});
})();
