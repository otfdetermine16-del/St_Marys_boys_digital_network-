# Production Readiness — V50

Status: **NOT YET CLEARED FOR REAL STUDENT DATA**

Reason: the PostgreSQL schema/adapter exists, but the application server's legacy domain routes still use the JSON store. A public deployment must not rely on an ephemeral/local JSON file for school records.

Required before V51 student pilot:
- migrate all domain reads/writes to PostgreSQL
- verify transaction boundaries and uniqueness constraints
- persistent object storage for media/uploads
- production session strategy suitable for the chosen scaling model
- backup/restore drill
- production authentication enabled
- HTTPS and security headers verified
- privacy/data-retention review
- end-to-end production smoke test
