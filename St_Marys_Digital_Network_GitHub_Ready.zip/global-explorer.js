(function(){'use strict';
if(document.getElementById('smExplorer'))return;
const items=[
['⌂','Home','home.html'],
['📚','Academics','academic.html'],
['👥',"St. Mary’s Connect",'connect.html'],
['🏛️','Heritage','heritage.html'],
['🎓','Student Hub','student-hub.html'],
['＋','More','activities.html'],
['🧑‍🎓','Alumni','alumni.html'],
['⌕','Search','search.html'],
['🔔','Notifications','notifications.html'],
['🏆','Clubs & Achievements','activities.html'],
['🎨','MARISCAN ARTISTRY','media-centre.html'],
['💡','Suggestion Box','suggestions.html'],
['👨‍👩‍👧','PTA','pta.html'],
['🗺️','School Map','map.html'],
['📜','School Rules, Vision & Mission','school-information.html'],
['🤖','MARISCAN AI Assistant','ai.html']
];
const shade=document.createElement('div');shade.className='sm-explorer-shade';shade.id='smExplorerShade';
const drawer=document.createElement('aside');drawer.className='sm-explorer';drawer.id='smExplorer';drawer.setAttribute('aria-label','Explore your school');
drawer.innerHTML='<div class="sm-explorer-head"><button class="sm-explorer-close" id="smExplorerClose" aria-label="Close">×</button><div class="sm-explorer-brand"><img src="assets/crest-lively.jpg" alt="St. Mary’s school crest"><div><div class="sm-explorer-kicker">ST. MARY’S DIGITAL NETWORK</div><h2>Explore<br>Your School</h2></div></div><div class="sm-explorer-rule"></div></div><nav class="sm-explorer-links">'+items.map((x,i)=>'<a href="'+x[2]+'" class="'+(i===0?'home-link':'')+'"><span class="ico">'+x[0]+'</span><span>'+x[1]+'</span><b style="margin-left:auto">›</b></a>').join('')+'</nav>';
const tab=document.createElement('button');tab.className='sm-explorer-tab';tab.id='smExplorerTab';tab.title='Explore your school';tab.setAttribute('aria-label','Open Explore Your School');tab.innerHTML='<span>EXPLORE</span>';
document.body.append(shade,drawer,tab);
function open(){drawer.classList.add('open');shade.classList.add('show');tab.style.display='none'}
function close(){drawer.classList.remove('open');shade.classList.remove('show');tab.style.display='block'}
tab.onclick=open;shade.onclick=close;drawer.querySelector('#smExplorerClose').onclick=close;
drawer.querySelectorAll('a').forEach(a=>a.addEventListener('click',close));
document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
})();