# St. Mary's Digital Network V74.2 — Backend Connection

## Architecture

Browser → Firebase Hosting →
- `/api/chat`, `/api/search`, `/api/youtube`, `/api/image`, `/api/pdf` → Firebase Function `api` for MARISCAN AI
- all other `/api/**`, `/media/**`, `/document/**` → Cloud Run service `st-marys-digital-network-api`

## 1. Build the public tree

```bash
node build-public.js
```

## 2. Deploy the full Node backend to Cloud Run

The Cloud Run service must be named exactly `st-marys-digital-network-api` because Firebase Hosting rewrites target that service.

```bash
gcloud config set project st-marys-digital-network
gcloud run deploy st-marys-digital-network-api \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars NODE_ENV=production,ST_MARYS_DEV_OPEN_ACCESS=false,ST_MARYS_DB_PROVIDER=postgres
```

Then add the sensitive values in Cloud Run → Service → Edit & Deploy New Revision → Variables & Secrets:

- `DATABASE_URL` — PostgreSQL connection string
- `SESSION_SECRET` — random secret, at least 32 characters
- `ST_MARYS_ADMIN_API_TOKEN` — long random admin API token
- `OPENAI_API_KEY` — only needed if MARISCAN AI is served through the Node backend/custom domain

Do not put real passwords or API keys into GitHub.

## 3. Configure Firebase MARISCAN AI secrets

```bash
firebase use st-marys-digital-network
firebase functions:secrets:set OPENAI_API_KEY
firebase functions:secrets:set YOUTUBE_API_KEY
firebase deploy --only functions,hosting
```

## 4. Verify

```bash
curl -i https://st-marys-digital-network.web.app/api/health
```

Expected backend response includes `status: online` and `backend`/service information.

After signing in, the browser should call:

```text
/api/auth/firebase-sync
/api/me
```

and receive a school-network account session.

## Critical database requirement

Production startup intentionally refuses to run without PostgreSQL. A real PostgreSQL connection string must be supplied before Cloud Run can become healthy.

## Media persistence warning

The current application writes uploaded media/documents to the Cloud Run filesystem. Cloud Run storage is ephemeral. For permanent school media, the next hardening step is Google Cloud Storage/Firebase Storage with metadata stored in PostgreSQL.
