## Summary

## Changes made
- 

## Testing
- [ ] `npm run github:preflight`
- [ ] `npm test`

## Security/privacy check
- [ ] No credentials, tokens, private keys, or private student data added.

## Screenshots (if UI changed)
