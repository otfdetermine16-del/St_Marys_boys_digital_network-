---
name: Bug report
about: Report a reproducible problem in the St. Mary's Digital Network
labels: bug
---

## What happened?

## Steps to reproduce
1.
2.
3.

## Expected behavior

## Device/browser

## Screenshots or logs

> Do not include passwords, tokens, student personal data, or other secrets.
