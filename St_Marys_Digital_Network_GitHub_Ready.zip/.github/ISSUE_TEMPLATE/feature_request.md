---
name: Feature request
about: Suggest an improvement to the St. Mary's Digital Network
labels: enhancement
---

## Feature

## Why would it help students, teachers, administrators, or alumni?

## Proposed behavior

## Notes
