#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: ./github-push.sh https://github.com/YOUR-USERNAME/st-marys-digital-network.git"
  exit 2
fi

REMOTE="$1"
if [[ "$REMOTE" != https://github.com/*/*.git ]]; then
  echo "Refusing remote: expected an HTTPS GitHub .git URL."
  exit 3
fi

git remote get-url origin >/dev/null 2>&1 && git remote set-url origin "$REMOTE" || git remote add origin "$REMOTE"
git branch -M main
git push -u origin main
