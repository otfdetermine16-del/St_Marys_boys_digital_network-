(()=>{
  'use strict';
  const K='sm_settings_v10', D={lastAnnualReview:new Date().getFullYear()};
  const load=()=>{try{return JSON.parse(localStorage.getItem(K))||D}catch(e){return D}};
  const save=s=>localStorage.setItem(K,JSON.stringify(s));
  function dialog(title,body){
    const d=document.querySelector('#sm-info-dialog'); if(!d)return;
    d.querySelector('h2').textContent=title;
    d.querySelector('.sm-dialog-body').innerHTML=body;
    d.classList.add('is-open');
  }
  function install(){
    if(document.querySelector('#sm-settings-button')) return;
    document.body.insertAdjacentHTML('beforeend',`
      <button id="sm-settings-button" aria-expanded="false" aria-controls="sm-settings-panel" aria-label="Settings" title="Settings">⚙</button>
      <div id="sm-settings-backdrop"></div>
      <aside id="sm-settings-panel" aria-hidden="true">
        <header><b>ST. MARY'S DIGITAL NETWORK</b><h2>Settings</h2><button id="sm-close" aria-label="Close settings">×</button></header>
        <section>
          <button id="sm-help-tile">❔ <span><b>Help</b><small>Get guidance for using the platform</small></span></button>
          <h3>Website information</h3>
          <button class="sm-link" id="sm-about">About this website <span>›</span></button>
          <a class="sm-link" href="creator-story.html">Creator's Story <span>›</span></a>
          <button class="sm-link" id="sm-update">Annual review &amp; update <span>›</span></button>
          <h3>Restricted area</h3>
          <p>The Control Centre is available only to authorized administrators.</p>
          <a class="sm-control-link" href="admin-control.html">Open Control Centre <span>›</span></a>
        </section>
      </aside>
      <div id="sm-info-dialog" role="dialog" aria-modal="true" aria-labelledby="sm-dialog-title">
        <div><button id="sm-dialog-close" aria-label="Close dialog">×</button><b>ST. MARY'S DIGITAL NETWORK</b><h2 id="sm-dialog-title"></h2><div class="sm-dialog-body"></div></div>
      </div>`);
    const panel=document.querySelector('#sm-settings-panel'), backdrop=document.querySelector('#sm-settings-backdrop'), trigger=document.querySelector('#sm-settings-button'), info=document.querySelector('#sm-info-dialog');
    const closeDialog=()=>info.classList.remove('is-open');
    const close=()=>{panel.classList.remove('is-open');backdrop.classList.remove('is-open');panel.setAttribute('aria-hidden','true');trigger.setAttribute('aria-expanded','false')};
    const open=()=>{panel.classList.add('is-open');backdrop.classList.add('is-open');panel.setAttribute('aria-hidden','false');trigger.setAttribute('aria-expanded','true')};
    trigger.addEventListener('click',()=>panel.classList.contains('is-open')?close():open());
    document.querySelector('#sm-close').addEventListener('click',close);
    backdrop.addEventListener('click',close);
    document.querySelector('#sm-dialog-close').addEventListener('click',closeDialog);
    document.querySelector('#sm-help-tile').addEventListener('click',()=>dialog('How can we help?','Choose the section you need from the main navigation. Students can use the Student Hub and class spaces; teachers use the Teacher Centre; authorized administrators use administration tools. If something does not work, note the page, action and result and report it to the appropriate school or IT administrator.'));
    document.querySelector('#sm-about').addEventListener('click',()=>dialog('About this website',"St. Mary's Digital Network began as a student-led idea to make communication, learning, school information and student–teacher coordination easier. It is designed as a long-term digital home for the school, where each academic year can update its people, classes, resources, events and records while historical records remain preserved."));
    document.querySelector('#sm-update').addEventListener('click',()=>{const s=load();s.lastAnnualReview=new Date().getFullYear();save(s);dialog('Annual review & update','This prototype records the review year locally. In production, authorized staff will review, approve and publish the next academic year before changes become official.')});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeDialog();close()}});
  }
  document.addEventListener('DOMContentLoaded',install);
})();
