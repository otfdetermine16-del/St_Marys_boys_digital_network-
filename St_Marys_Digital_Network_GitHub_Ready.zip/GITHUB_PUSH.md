# V49 — GitHub Upload & Repository Connection

This project is prepared to be pushed to a GitHub repository. The local repository is intentionally not configured with a personal remote URL yet.

## Recommended repository
Create a **private repository first** while the platform is under development and before real student data is introduced.

Suggested name:
`st-marys-digital-network`

## Push from your computer
```bash
git remote add origin https://github.com/YOUR-USERNAME/st-marys-digital-network.git
git branch -M main
git push -u origin main
```

If `origin` already exists:
```bash
git remote set-url origin https://github.com/YOUR-USERNAME/st-marys-digital-network.git
git push -u origin main
```

GitHub will normally authenticate through a browser/credential manager or GitHub CLI. **Do not put a password or personal access token in this file or in the repository URL.**

## After the first push
1. Keep the repository private during development.
2. Enable GitHub Actions and confirm the CI workflow is green.
3. Enable Dependabot/security alerts where available.
4. Add branch protection/rules for `main` when collaboration begins.
5. Never commit `.env`, production credentials, database dumps, uploads, or real student records.
6. Keep the development-open mode disabled on any public deployment.

## Verify the remote
```bash
git remote -v
git status
```

The repository should contain source code and documentation only; runtime data belongs on the server/database, not in Git.
