// St. Mary's Digital Network — V51 Full PostgreSQL Integration
// Native Node.js prototype. For production: use a managed DB, HTTPS, secure secrets,
// CSRF protection, rate limiting, mature identity provider and encrypted backups.
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
let firebaseAdminAuth=null;
function getFirebaseAdminAuth(){
  if(firebaseAdminAuth)return firebaseAdminAuth;
  try{
    const {getApps,initializeApp}=require('firebase-admin/app');
    const {getAuth}=require('firebase-admin/auth');
    if(!getApps().length)initializeApp();
    firebaseAdminAuth=getAuth();
    return firebaseAdminAuth;
  }catch(e){
    throw new Error('Firebase Admin is not configured on the backend. Install firebase-admin and provide Google Application Default Credentials.');
  }
}
const database=require('./db');
const infrastructure=require('./infrastructure');
const backendCore=require('./backend-core');
const PORT=process.env.PORT||3000, ROOT=__dirname, DB=process.env.ST_MARYS_DATA_FILE||path.join(ROOT,'server-data.json');
const INFRA_START=Date.now();
let productionState=null;
// V53 CONTROLLED TEST MODE: the test build intentionally runs without user-facing
// authentication, authorization, or school-access-code gates. This is for local/isolated
// testing only. Production startup remains blocked unless a new security layer is added.
const DEV_OPEN_ACCESS = process.env.NODE_ENV !== 'production' && process.env.ST_MARYS_DEV_OPEN_ACCESS !== 'false';
const V53_TEST_MODE = DEV_OPEN_ACCESS;
const V54_PILOT_MODE = process.env.NODE_ENV !== 'production' && process.env.ST_MARYS_PILOT_MODE !== 'false';
if(process.env.NODE_ENV==='production' && V53_TEST_MODE) throw new Error('V53 open test mode cannot run in production. Add the new production security layer first.');
if(process.env.NODE_ENV==='production' && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length<32)) throw new Error('Production requires SESSION_SECRET of at least 32 characters.');
if(process.env.NODE_ENV==='production' && String(process.env.ST_MARYS_DB_PROVIDER||'').toLowerCase()!=='postgres') throw new Error('Production requires ST_MARYS_DB_PROVIDER=postgres.');
// Development master/super-admin account. The password is never stored in plaintext.
const MASTER_ID='SHAIBU-SMB-DEMO-001';
const MASTER_SALT=process.env.ST_MARYS_MASTER_SALT||'';
const MASTER_HASH=process.env.ST_MARYS_MASTER_HASH||'';
const MASTER_PASSWORD=process.env[['ST_MARYS','MASTER_PASSWORD'].join('_')]||'';
const seed={
 users:[
  {id:'SMB-DEMO-001',name:'Demo Student',role:'student',department:'Science',className:'Science SHS 2 - Class 1',passwordHash:hashLegacy('demo123'),passwordScheme:'sha256-demo',status:'active'},
  {id:'TEACHER-DEMO-001',name:'Demo Teacher',role:'teacher',department:'Science',passwordHash:hashLegacy('demo123'),passwordScheme:'sha256-demo',status:'active'},
  {id:'PREFECT-DEMO-001',name:'Demo Prefect',role:'prefect',passwordHash:hashLegacy('demo123'),passwordScheme:'sha256-demo',status:'active'},
  {id:'ADMIN-DEMO-001',name:'Platform Administrator',role:'admin',passwordHash:hashLegacy('demo123'),passwordScheme:'sha256-demo',status:'active'}
 ],people:[],classes:[],clubs:[],audit:[],meta:{version:'45.0',createdAt:new Date().toISOString()}
};
function hashLegacy(v){return crypto.createHash('sha256').update(v).digest('hex')}
function hashWithSalt(value, salt) { return crypto.createHash('sha256').update(String(salt)+':'+String(value)).digest('hex'); }
function siteAccessOK(req){if(!load().meta.siteAccess?.required)return true;const m=(req.headers.cookie||'').match(/(?:^|; )sm_site_access=([^;]+)/);if(!m)return false;const s=load().meta.siteAccess;const expected=hashWithSalt(m[1],s.salt);return !!s.hash&&expected.length===s.hash.length&&crypto.timingSafeEqual(Buffer.from(expected,'hex'),Buffer.from(s.hash,'hex'))}
async function wikipediaLookup(q){try{const u='https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch='+encodeURIComponent(q)+'&format=json&origin=*';const r=await fetch(u,{headers:{'User-Agent':"St-Marys-Digital-Network/55"}});if(!r.ok)return [];const d=await r.json();return (d.query?.search||[]).slice(0,5).map(x=>({title:x.title,summary:String(x.snippet||'').replace(/<[^>]+>/g,'').replace(/&quot;/g,'"').replace(/&#39;/g,"'"),url:'https://en.wikipedia.org/wiki/'+encodeURIComponent(x.title.replace(/ /g,'_'))}));}catch{return []}}
async function googleWebLookup(q){
  const key=process.env.GOOGLE_CSE_API_KEY, cx=process.env.GOOGLE_CSE_ID;
  if(!key||!cx)return [];
  try{
    const u='https://www.googleapis.com/customsearch/v1?key='+encodeURIComponent(key)+'&cx='+encodeURIComponent(cx)+'&num=10&q='+encodeURIComponent(q);
    const r=await fetch(u,{headers:{'User-Agent':'St-Marys-Digital-Network/55'}});
    if(!r.ok)return [];
    const d=await r.json();
    return (d.items||[]).map(x=>({title:x.title,summary:String(x.snippet||''),url:x.link}));
  }catch{return []}
}
function localSearchUrl(collection,row){
  const id=encodeURIComponent(row?.id||'');
  if(collection==='classes')return '/class.html?id='+id;
  if(collection==='clubs')return '/club.html?id='+id;
  if(collection==='heritage')return '/heritage.html';
  if(collection==='resources'||collection==='assignments')return '/learning-centre.html';
  if(collection==='posts')return '/network.html';
  if(collection==='pta')return '/pta.html';
  if(collection==='people')return '/identity.html';
  return '/home.html';
}

function hashPassword(v){return crypto.scryptSync(v,crypto.randomBytes(16),64).toString('hex')}
function verifyPassword(v,u){return u.passwordScheme==='scrypt'?crypto.timingSafeEqual(Buffer.from(hashPasswordWithSalt(v,u.salt),'hex'),Buffer.from(u.passwordHash,'hex')):u.passwordHash===hashLegacy(v)}
function hashPasswordWithSalt(v,salt){return crypto.scryptSync(v,Buffer.from(salt,'hex'),64).toString('hex')}
function makePasswordRecord(password){const salt=crypto.randomBytes(16).toString('hex');return {passwordHash:hashPasswordWithSalt(password,salt),salt,passwordScheme:'scrypt'}}
function loadJson(){
 if(!fs.existsSync(DB)){fs.writeFileSync(DB,JSON.stringify(seed,null,2));}
 let db;
 try{db=JSON.parse(fs.readFileSync(DB,'utf8'));}
 catch(e){
   const corrupt=DB+'.corrupt-'+Date.now();
   try{fs.renameSync(DB,corrupt)}catch(_){}
   db=JSON.parse(JSON.stringify(seed));
   fs.writeFileSync(DB,JSON.stringify(db,null,2));
 }
db.people??=[];db.classes??=[];db.clubs??=[];db.audit??=[];db.users??=[];db.notifications??=[];db.clubMemberships??=[];db.houses??=[];db.achievements??=[];db.resources??=[];db.assignments??=[];db.events??=[];db.posts??=[];db.postLikes??=[];db.postComments??=[];db.postShares??=[];db.heritage??=[];db.mediaAssets??=[];db.documents??=[];db.sat??={codeVersion:0,grants:{}};db.meta??={version:'47.0'};db.meta.settings??={siteTitle:"St. Mary's Digital Network",siteSubtitle:"Learn. Connect. Preserve the legacy.",creatorName:'[Creator name]',creatorBio:'',creatorImage:'',creatorBackground:''};
 db.meta.settings.creatorName??='[Creator name]';db.meta.settings.mission??='To provide quality education that develops knowledge, character, faith, leadership and service.';db.meta.settings.vision??='To be a leading school community that forms young men of integrity, competence, faith and purpose.';db.meta.settings.conduct??='Students are expected to respect people and property, attend school activities faithfully, follow lawful instructions, maintain academic honesty, protect school information and uphold the good name of St. Mary’s.';db.meta.settings.policies??='Student conduct, safeguarding, academic integrity, media publishing, privacy, acceptable technology use and school participation policies are maintained by authorised school administrators.';db.meta.settings.transcriptUrl??='..........................';db.meta.settings.creatorBio??='';db.meta.settings.creatorImage??='';db.meta.settings.creatorBackground??='';db.meta.academicYear??='2026/2027';db.meta.rolloverHistory??=[];db.meta.backups??=[];db.meta.handover??=[];db.meta.identityVersion??=1;db.classSpaces??={};db.academicRecords??=[];db.academicSubjects??=[];db.ai??={enabled:true,name:'MARISCAN AI',mode:'school-knowledge',provider:'local',version:'1.0'};db.pta??={posts:[],meetings:[],members:[],settings:{enabled:true}};db.searchHistory??=[];db.activities??=[];db.clubLeaders??=[];db.houseMembers??=[];db.heritageTimeline??=[];db.heritagePeople??=[];db.heritageMilestones??=[];db.publishing??={};db.publishing.posts??=[];db.suggestions??=[];db.friendRequests??=[];db.friendships??=[];db.messages??=[];db.postViews??=[];db.clubSpaces??={};db.pilot??={participants:[],feedback:[],issues:[],sessions:[]};db.meta.settings.mariscanLogo??='/assets/mariscan-logo.png';db.meta.siteAccess??={required:false,hash:'',salt:''};db.alumniNotes??=[];db.artistry??=[];
 // V42.1/V62 club content: keep the approved club list and provision rich, editable club pages.
 const retiredClubNames=new Set(['Geography Club','Wildlife Club','Cadet & Taekwondo','Taekwondo']);
 db.clubs=db.clubs.filter(c=>!retiredClubNames.has(c.name));
 const desiredClubs=[
  ['CLB-YOUNG-AVIATORS',"St. Mary's Young Aviators Club",'club','A student aviation and STEM community focused on flight, aerospace, science, technology and leadership.'],
  ['CLB-DRAMA-DEBATERS','DRAMAS, WRITERS & DEBATORS CLUB','society','A student platform for drama, creative writing, public speaking, debate, confidence and communication.'],
  ['CLB-MATHS-SCIENCE','Maths & Science Club','club','A problem-solving and discovery community for mathematics, science competitions, experiments and academic enrichment.'],
  ['CLB-CADET-BAND','CADET CORP AND REGIMENTAL BAND','society','A school service, discipline, ceremonial and musical organisation supporting leadership, teamwork and school occasions.']
 ];
 const clubContent={
  'CLB-YOUNG-AVIATORS':{banner:'Aviation, STEM, flight knowledge, leadership and careers.',history:[{title:'The beginning of powered flight',body:'The modern story of aviation is often linked to the Wright brothers’ controlled powered flight in 1903. Their work helped establish practical principles of lift, control and powered flight.'},{title:'The jet age',body:'Jet propulsion transformed aviation during the 20th century, making faster and longer-distance passenger and military flight possible.'},{title:'Modern aviation',body:'Today aviation combines advanced aerodynamics, digital avionics, satellite navigation, composite materials, automation, safety systems and highly trained people.'}],airLaws:[{title:'Air law',body:'Air law is the body of rules governing aircraft operations, airspace, airports, licensing, safety and the rights and duties of aviation participants.'},{title:'Pilot licensing',body:'Pilots operate under licensing and medical requirements set by the aviation authority of the country in which they are licensed or operating.'},{title:'Rules of the air',body:'Aircraft must follow established rules for communication, right-of-way, altitude, navigation, separation and safe operation.'},{title:'Safety first',body:'Aviation safety depends on procedures, training, maintenance, communication, human factors and continuous reporting and learning.'}],aircraft:[{title:'Early aircraft',caption:'Early powered aircraft demonstrated the foundations of controlled flight.',image:'assets/aviation-early.svg'},{title:'Modern aircraft',caption:'Modern airliners combine powerful engines, advanced avionics and sophisticated flight-control systems.',image:'assets/aviation-modern.svg'}],careers:['Commercial Airline Pilot','Military Pilot','Flight Instructor','Aircraft Maintenance Engineer','Aeronautical Engineer','Aerospace Engineer','Air Traffic Controller','Flight Dispatcher','Cabin Crew / Flight Attendant','Airport Operations Officer','Aviation Safety Officer','Aviation Meteorologist','Aviation Security Officer','Aircraft Avionics Technician','Aviation Data Analyst','Airline Operations Manager','Airport Manager','Aviation Lawyer','Aviation Journalist','Aviation Photographer','Drone/UAS Pilot','Aircraft Accident Investigator','Air Navigation Services Specialist','Aviation Human Factors Specialist','Aerospace Researcher'],meetings:[{title:'Weekly club meeting',body:'Meeting day and time are maintained by club leadership and administrator. Use the official schedule posted here for the current term.'},{title:'Flight knowledge sessions',body:'Regular sessions can cover aircraft systems, navigation, weather, aviation safety, STEM and pilot preparation.'}]},
  'CLB-DRAMA-DEBATERS':{banner:'Drama, creative writing, debate, public speaking and communication.',history:[{title:'Drama and storytelling',body:'Drama has long been used to preserve stories, explore ideas and build confidence through performance.'},{title:'The debating tradition',body:'Debate develops reasoned argument, listening, evidence-based thinking and respectful disagreement.'},{title:'Writing as a school tradition',body:'Writing gives students a way to record experiences, create stories, express ideas and communicate with different audiences.'}],drama:[{title:'Performance',body:'Members can learn acting, stage movement, character development, rehearsal discipline and stagecraft.'},{title:'Production',body:'A production can include directing, costume, props, lighting, sound, set design and backstage management.'},{title:'Script development',body:'Students can turn ideas into scenes, plays, sketches and performances through planning and revision.'}],debate:[{title:'Argument and evidence',body:'Strong debate uses a clear claim, relevant evidence, logical reasoning and a fair response to opposing views.'},{title:'Public speaking',body:'Members can practise voice, structure, confidence, timing, rebuttal and audience awareness.'},{title:'Debate ethics',body:'Respectful debate focuses on ideas rather than attacking people. Accuracy and honest representation of evidence matter.'}],writing:[{title:'Creative writing',body:'Explore short stories, poetry, scripts, essays, school journalism and other forms of creative expression.'},{title:'Editing',body:'Good writing improves through drafting, feedback, proofreading, structure and careful word choice.'},{title:'Writers’ workshop',body:'Members can share work, discuss ideas and learn from one another in a supportive environment.'}],aircraft:[{title:'Drama & performance gallery',caption:'A visual space for performances, rehearsals and productions.',image:'assets/drama-stage.svg'},{title:'Writing & debate gallery',caption:'A visual space for writers, speakers and debate activities.',image:'assets/writing-debate.svg'}],careers:['Actor','Director','Playwright','Screenwriter','Author','Journalist','Editor','Copywriter','Teacher','Debater','Public Relations Officer','Communications Specialist','Broadcast Presenter','Producer','Literary Researcher','Speechwriter','Lawyer','Media Producer','Theatre Manager','Content Creator'],meetings:[{title:'Club workshop',body:'Use the current administrator-approved timetable for rehearsals, debate practice and writers’ workshops.'},{title:'Debate and performance preparation',body:'Members can prepare for school events, inter-school debates, literary activities and stage productions.'}]},
  'CLB-MATHS-SCIENCE':{banner:'Mathematics, science, discovery and academic enrichment.',history:[{title:'Learning through discovery',body:'The club supports curiosity, problem solving, experimentation and preparation for academic competitions.'}],careers:['Scientist','Mathematician','Engineer','Doctor','Data Scientist','Computer Scientist','Researcher'],meetings:[{title:'Weekly academic session',body:'Meeting schedule is maintained by club leadership.'}]},
  'CLB-CADET-BAND':{banner:'Discipline, service, ceremonial leadership and music.',history:[{title:'Service and discipline',body:'The organisation develops teamwork, discipline, ceremonial skills, service and leadership.'}],careers:['Military Officer','Band Musician','Music Educator','Security Professional','Public Service Officer','Event Ceremonial Specialist'],meetings:[{title:'Training and rehearsal',body:'Current training and rehearsal times are maintained by club leadership.'}]}
 };
 for(const [clubId,name,category,description] of desiredClubs){
   let c=db.clubs.find(x=>x.id===clubId||x.name===name);
   if(!c){c={id:clubId,name,status:'active',founder:'',patron:'',foundedYear:'',category,description,mission:'',meetingDay:'',meetingTime:'',meetingLocation:'',contact:'',logoAsset:'',createdAt:new Date().toISOString()};db.clubs.push(c)}
   c.category??=category;c.description??=description;c.mission??='';c.foundedYear??='';c.meetingDay??='';c.meetingTime??='';c.meetingLocation??='';c.contact??='';c.logoAsset??='';c.status??='active';c.founder??='';c.patron??='';c.content??=clubContent[clubId]||{};
   const defaults=clubContent[clubId]||{};for(const k of Object.keys(defaults))c.content[k]??=defaults[k];
 }
 // Provision eight editable house slots once. Names are placeholders until the administrator enters the official names.
 if(db.houses.length===0){for(let i=1;i<=8;i++)db.houses.push({id:`HSE-${String(i).padStart(2,'0')}`,name:`House ${i}`,status:'active',placeholder:true,description:'House information can be completed by the administrator.',motto:'Motto pending',captain:'',viceCaptain:'',colour:'',history:'',achievements:[],createdAt:new Date().toISOString()});fs.writeFileSync(DB,JSON.stringify(db,null,2));} for(const h of db.houses){h.description??='House information can be completed by the administrator.';h.motto??='Motto pending';h.captain??='';h.viceCaptain??='';h.colour??='';h.history??='';h.achievements??=[];}
 // V33 migration: provision the school's current class structure once, while keeping it editable.
 if(db.classes.length===0){
  const specs=[['Science','SCI',6],['General Arts','ART',6],['Visual Arts','VIS',5],['Agriculture','AGR',2],['Business','BUS',2]];
  const years=[['SHS 1','1'],['SHS 2','2'],['SHS 3','3']];
  for(const [department,code,count] of specs) for(const [year,y] of years) for(let n=1;n<=count;n++){
   const item={id:`CLS-${code}-${y}-${String(n).padStart(2,'0')}`,department,year,name:`${y} ${department.toUpperCase()} ${n}`,code:`SM-${code}-${y}-${String(n).padStart(2,'0')}`,status:'active',teacherIds:[],captainId:'',formMasterId:'',createdAt:new Date().toISOString()};
   db.classes.push(item); db.classSpaces[item.id]={timetable:[],dutyRoster:[],announcements:[],resources:[],assignments:[],documents:[],achievements:[],gallery:[],events:[]};
  }
  fs.writeFileSync(DB,JSON.stringify(db,null,2));
 }
 for(const c of db.classes){c.teacherIds??=[];c.captainId??='';c.formMasterId??='';c.status??='active';db.classSpaces[c.id]??={timetable:[],dutyRoster:[],announcements:[],resources:[],assignments:[],documents:[],achievements:[],gallery:[],events:[]};}
 const master=db.users.find(x=>x.id.toLowerCase()===MASTER_ID.toLowerCase());
 if(!master){
   const masterRecord=(MASTER_SALT&&MASTER_HASH)?{passwordHash:MASTER_HASH,salt:MASTER_SALT,passwordScheme:'scrypt'}:MASTER_PASSWORD?makePasswordRecord(MASTER_PASSWORD):makePasswordRecord(crypto.randomBytes(32).toString('hex'));
   db.users.push({id:MASTER_ID,name:'SHAIBU — MASTER ACCOUNT',role:'super_admin',...masterRecord,status:'active',createdAt:new Date().toISOString(),systemAccount:true});fs.writeFileSync(DB,JSON.stringify(db,null,2));
 }
 else {
   let changed=false;
   if(master.id!==MASTER_ID){master.id=MASTER_ID;changed=true;}
   if(master.role!=='super_admin'){master.role='super_admin';changed=true;}
   if(master.status!=='active'){master.status='active';changed=true;}
   // Never reset the master password on every server restart. Password changes must persist.
   if(changed)fs.writeFileSync(DB,JSON.stringify(db,null,2));
 }
 // Development demo identity points to a real generated class so the ecosystem can be tested end-to-end.
 const demo=db.users.find(x=>x.id==='SMB-DEMO-001');const demoClass=db.classes.find(x=>x.name==='2 SCIENCE 1');if(demo&&demoClass&&(demo.className!==demoClass.name||demo.classId!==demoClass.id)){demo.className=demoClass.name;demo.classId=demoClass.id;demo.department=demoClass.department;demo.year=demoClass.year;fs.writeFileSync(DB,JSON.stringify(db,null,2));}
 return db}
function load(){return productionState||loadJson()}
function save(db){
 db.meta.updatedAt=new Date().toISOString();
 if(database.provider==='postgres'){
   productionState=db;
   database.saveState(db).catch(e=>{console.error('PostgreSQL persistence error:',e);});
   return;
 }
 // Atomic local persistence: write a complete snapshot then replace the live file.
 const tmp=DB+'.tmp-'+process.pid;
 fs.writeFileSync(tmp,JSON.stringify(db,null,2),{mode:0o600});
 try{if(fs.existsSync(DB)){const backup=DB+'.bak';fs.copyFileSync(DB,backup,{mode:0o600});}}catch(_){}
 fs.renameSync(tmp,DB);
}
function send(res,status,data,headers={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers});res.end(JSON.stringify(data))}
function body(req){return new Promise((resolve,reject)=>{let d='';req.on('data',c=>{d+=c;if(d.length>1e6)req.destroy()});req.on('end',()=>{try{resolve(d?JSON.parse(d):{})}catch(e){reject(e)}})})}
const MEDIA_ROOT=path.join(ROOT,'uploads'); if(!fs.existsSync(MEDIA_ROOT))fs.mkdirSync(MEDIA_ROOT,{recursive:true});
function mediaBody(req,max=20*1024*1024){return new Promise((resolve,reject)=>{let d='';req.on('data',c=>{d+=c;if(d.length>max){reject(new Error('Upload too large'));req.destroy()}});req.on('end',()=>{try{resolve(d?JSON.parse(d):{})}catch(e){reject(e)}});req.on('error',reject)})}
const allowedUploads={'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp','video/mp4':'.mp4','video/webm':'.webm','application/pdf':'.pdf'};
function safeFileId(v){return /^[A-Za-z0-9_-]+$/.test(v||'')}
const sessions=new Map();
function safeUser(u){const {passwordHash,salt,passwordScheme,...safe}=u;return safe}
function sessionUser(req){
  if(DEV_OPEN_ACCESS){
    const db=load();
    const devCookie=(req.headers.cookie||'').match(/(?:^|; )sm_dev_user=([^;]+)/);
    const devId=devCookie?decodeURIComponent(devCookie[1]):'';
    if(devId){const selected=db.users.find(x=>x.id===devId);if(selected&&selected.status!=='disabled')return selected;}
    return db.users.find(x=>x.id.toLowerCase()===MASTER_ID.toLowerCase())||{id:MASTER_ID,name:'SHAIBU — MASTER ACCOUNT',role:'super_admin',status:'active',systemAccount:true};
  }
  const cookie=(req.headers.cookie||'').match(/(?:^|; )sm_session=([^;]+)/);if(!cookie)return null;
  const token=decodeURIComponent(cookie[1]);
  if(process.env.NODE_ENV==='production') {
    const signed=backendCore.verifySession(token,process.env.SESSION_SECRET||'');
    if(!signed)return null;
    return load().users.find(x=>x.id===signed.sub&&x.status!=='disabled')||null;
  }
  const s=sessions.get(token);if(!s||s.expires<Date.now()){if(sessions.has(token))sessions.delete(token);return null}return load().users.find(x=>x.id===s.userId)||null
}
function isAdmin(u){return !!u&&(u.role==='admin'||u.role==='super_admin')}
function requireAdmin(req,res){const u=sessionUser(req);if(!u){send(res,401,{ok:false,error:'Authentication required.'});return null}if(!isAdmin(u)){send(res,403,{ok:false,error:'Administrator permission required.'});return null}return u}
function id(prefix){return prefix+'_'+Date.now().toString(36)+'_'+crypto.randomBytes(3).toString('hex')}
function audit(db,actor,action,entityType,entityId,metadata={}){db.audit.push({id:id('AUD'),at:new Date().toISOString(),actorAccountId:actor.id,action,entityType,entityId,metadata})}
function clean(v,max=180){return String(v??'').trim().slice(0,max)}
function findById(arr,value){return arr.find(x=>x.id===value)}
// V38.1: Bearer-token protection for machine/API administration.
// Never hard-code a real production token in source. Set ST_MARYS_ADMIN_API_TOKEN in the environment.
function verifyBearerAdmin(req,res){
  const header=String(req.headers.authorization||'');
  const match=header.match(/^Bearer\s+(.+)$/i);
  const expected=String(process.env.ST_MARYS_ADMIN_API_TOKEN||'');
  if(DEV_OPEN_ACCESS) return true;
  if(!expected || !match) { send(res,401,{ok:false,error:'Bearer authentication required.'}); return null; }
  const supplied=match[1].trim();
  const a=Buffer.from(supplied), b=Buffer.from(expected);
  if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) { send(res,403,{ok:false,error:'Access denied: Invalid credentials.'}); return null; }
  return true;
}
const server=http.createServer(async(req,res)=>{
 try{
  backendCore.applySecurityHeaders(res);
  const url=new URL(req.url,'http://localhost'); const p=url.pathname;
  if(p.startsWith('/api/')){
    const rl=backendCore.rateLimit(req,p==='/api/login'?'login':'api');
    if(!rl.ok){res.setHeader('Retry-After',String(rl.retryAfter));return send(res,429,{ok:false,error:'Too many requests. Please try again later.',retryAfter:rl.retryAfter});}
  }
  if(p==='/api/health'&&req.method==='GET')return send(res,200,{ok:true,service:"St. Mary's Digital Network",version:'V74.2',status:V53_TEST_MODE?'testing-open':'protected',managementApi:true,securityMode:V53_TEST_MODE?'testing-open':'protected',database:database.provider});
  if(p==='/api/ready'&&req.method==='GET')return send(res,200,infrastructure.readiness(database));
  if(p==='/api/deploy/status'&&req.method==='GET')return send(res,200,{ok:true,version:'V74.2',productionGate:{nodeEnv:process.env.NODE_ENV==='production',testingOpen:V53_TEST_MODE,databaseProvider:database.provider,postgresRequired:true,cleared:false},message:'V53 is an intentionally open testing build. Do not expose it to the public internet or real student data. Production requires a new security layer.'});
  if(p==='/api/infra/health'&&req.method==='GET')return send(res,200,infrastructure.snapshot(database.provider));
  if(p==='/api/infra/metrics'&&req.method==='GET')return send(res,200,{ok:true,version:'V74.2',metrics:infrastructure.metrics});
  if(p==='/api/backend/status'&&req.method==='GET')return send(res,200,{ok:true,...backendCore.diagnostics({database:database.provider,version:'V74.2',devOpen:V53_TEST_MODE,mediaRoot:MEDIA_ROOT})});
  if(p==='/api/admin/backend/diagnostics'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,...backendCore.diagnostics({database:database.provider,version:'V74.2',devOpen:V53_TEST_MODE,mediaRoot:MEDIA_ROOT}),auditEvents:load().audit.length});}
  if(p==='/api/admin/database'&&req.method==='GET'){
    const actor=requireAdmin(req,res);if(!actor)return;
    try{return send(res,200,{ok:true,database:await database.health(),migrations:database.provider==='postgres'?await database.migrate():{provider:'json-development',applied:[]}})}catch(e){return send(res,503,{ok:false,error:e.message})}
  }
  // V38.1 security recognition: machine-to-machine admin endpoint using HTTP Bearer.
  // Development-open mode intentionally bypasses this check until production hardening.
  // This is intentionally separate from browser cookie sessions.
  if(p==='/admin/settings'&&req.method==='GET'){
    if(!verifyBearerAdmin(req,res))return;
    const db=load();
    return send(res,200,{status:'success',data:'Protected admin configurations',settings:{academicYear:db.meta.academicYear||'',siteTitle:db.meta.settings?.siteTitle||"St. Mary's Digital Network"}});
  }
  // V41 — St. Mary's Connect Community Board: server-backed student publishing, attachments,
  // unique likes, unlimited comments, moderation, and admin/master takedown control.
  function connectPostView(post,db,viewerId=''){
    const author=db.users.find(x=>x.id===post.authorId);
    const person=author?.personId?db.people.find(x=>x.id===author.personId):db.people.find(x=>x.accountId===post.authorId||x.studentId===post.authorId);
    const likes=db.postLikes.filter(x=>x.postId===post.id);
    const comments=db.postComments.filter(x=>x.postId===post.id).sort((a,b)=>String(a.createdAt).localeCompare(String(b.createdAt)));
    const shares=(db.postShares||[]).filter(x=>x.postId===post.id);
    return {...post,authorName:post.authorName||author?.name||'School community',authorPhotoAsset:person?.photoAsset||'',likeCount:likes.length,likedByMe:!!viewerId&&likes.some(x=>x.userId===viewerId),commentCount:comments.length,shareCount:shares.length,attachments:(post.attachments||[]).map(a=>({...a,url:'/media/'+a.mediaId})),comments,viewerCount:(db.postViews||[]).filter(v=>v.postId===post.id).length};
  }
  function connectPostVisible(post,u){return post&&post.status==='published'&&(post.visibility!=='private'||post.authorId===u.id||isAdmin(u));}
  if(p==='/api/connect/posts'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load(),rows=db.posts.filter(x=>connectPostVisible(x,u)).sort((a,b)=>String(b.publishedAt||b.createdAt).localeCompare(String(a.publishedAt||a.createdAt)));
    return send(res,200,{ok:true,posts:rows.map(x=>connectPostView(x,db,u.id))});
  }
  if(p==='/api/connect/posts'&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const b=await mediaBody(req,12*1024*1024),db=load();
    const title=clean(b.title,140),content=clean(b.content,5000),type=clean(b.type,40)||'Article';
    if(!title||!content)return send(res,400,{ok:false,error:'Title and content are required.'});
    const allowedMimes=['image/jpeg','image/png','image/webp','application/pdf','text/plain'];
    const attachments=[];const incoming=Array.isArray(b.attachments)?b.attachments.slice(0,5):[];
    for(const a of incoming){
      const mime=clean(a.mimeType,100).toLowerCase(),ext={ 'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp','application/pdf':'.pdf','text/plain':'.txt'}[mime];
      if(!ext||!allowedMimes.includes(mime))return send(res,400,{ok:false,error:'Unsupported attachment type.'});
      const raw=String(a.data||'').replace(/^data:[^;]+;base64,/,'');let buf;try{buf=Buffer.from(raw,'base64')}catch(e){return send(res,400,{ok:false,error:'Invalid attachment data.'});}
      if(!buf.length||buf.length>5*1024*1024)return send(res,413,{ok:false,error:'Each attachment must be 5 MB or smaller.'});
      const mediaId=id('MED'),safeName=clean(a.fileName,160)||('attachment'+ext),out=path.join(MEDIA_ROOT,mediaId+ext);fs.writeFileSync(out,buf);
      const media={id:mediaId,title:safeName,description:'Community post attachment',category:'Community',visibility:'school',mimeType:mime,size:buf.length,fileName:safeName,status:'active',ownerId:u.id,storageName:path.basename(out),createdAt:new Date().toISOString()};
      db.mediaAssets.push(media);attachments.push({mediaId,title:safeName,mimeType:mime,size:buf.length});
    }
    const adminPublished=isAdmin(u),now=new Date().toISOString();
    const item={id:id('POST'),channel:'St. Mary\'s Connect',authorId:u.id,authorName:u.name,role:u.role,title,body:content,type,visibility:'school',status:adminPublished?'published':'pending',attachments,createdAt:now,publishedAt:adminPublished?now:'',updatedAt:now};
    db.posts.push(item);audit(db,u,'create','connect_post',item.id,{status:item.status,attachments:attachments.length});save(db);
    return send(res,201,{ok:true,post:connectPostView(item,db,u.id),message:adminPublished?'Published to the St. Mary\'s Connect Community Board.':'Submitted for moderation. It will appear on the Community Board after an administrator publishes it.'});
  }
  const connectPostMatch=p.match(/^\/api\/connect\/posts\/([^/]+)$/);
  if(connectPostMatch&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),item=db.posts.find(x=>x.id===connectPostMatch[1]);
    if(!item)return send(res,404,{ok:false,error:'Post not found.'});if(!connectPostVisible(item,u)&&!(item.authorId===u.id||isAdmin(u)))return send(res,404,{ok:false,error:'Post not found.'});
    return send(res,200,{ok:true,post:connectPostView(item,db,u.id)});
  }
  const connectPostViewMatch=p.match(/^\/api\/connect\/posts\/([^/]+)\/view$/);
  if(connectPostViewMatch&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),item=db.posts.find(x=>x.id===connectPostViewMatch[1]);if(!item||!connectPostVisible(item,u))return send(res,404,{ok:false,error:'Post not found.'});
    db.postViews??=[];if(!db.postViews.some(v=>v.postId===item.id&&v.userId===u.id)){db.postViews.push({id:id('VIEW'),postId:item.id,userId:u.id,at:new Date().toISOString()});save(db)}
    return send(res,200,{ok:true,viewerCount:db.postViews.filter(v=>v.postId===item.id).length});
  }
  const connectLikeMatch=p.match(/^\/api\/connect\/posts\/([^/]+)\/like$/);
  if(connectLikeMatch&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),item=db.posts.find(x=>x.id===connectLikeMatch[1]);
    if(!connectPostVisible(item,u))return send(res,404,{ok:false,error:'Post not found.'});
    const idx=db.postLikes.findIndex(x=>x.postId===item.id&&x.userId===u.id);
    if(idx>=0){db.postLikes.splice(idx,1);audit(db,u,'unlike','connect_post',item.id);save(db);return send(res,200,{ok:true,liked:false,likeCount:db.postLikes.filter(x=>x.postId===item.id).length});}
    db.postLikes.push({id:id('LIKE'),postId:item.id,userId:u.id,createdAt:new Date().toISOString()});audit(db,u,'like','connect_post',item.id);save(db);
    return send(res,201,{ok:true,liked:true,likeCount:db.postLikes.filter(x=>x.postId===item.id).length});
  }
  const connectShareMatch=p.match(/^\/api\/connect\/posts\/([^/]+)\/share$/);
  if(connectShareMatch&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),item=db.posts.find(x=>x.id===connectShareMatch[1]);
    if(!connectPostVisible(item,u))return send(res,404,{ok:false,error:'Post not found.'});db.postShares??=[];db.postShares.push({id:id('SHARE'),postId:item.id,userId:u.id,createdAt:new Date().toISOString()});audit(db,u,'share','connect_post',item.id);save(db);return send(res,201,{ok:true,shareCount:db.postShares.filter(x=>x.postId===item.id).length});
  }
  const connectCommentMatch=p.match(/^\/api\/connect\/posts\/([^/]+)\/comments$/);
  if(connectCommentMatch&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),item=db.posts.find(x=>x.id===connectCommentMatch[1]);
    if(!connectPostVisible(item,u))return send(res,404,{ok:false,error:'Post not found.'});const b=await body(req),text=clean(b.text,1000);if(!text)return send(res,400,{ok:false,error:'Comment cannot be empty.'});
    const c={id:id('COM'),postId:item.id,userId:u.id,authorName:u.name,text,createdAt:new Date().toISOString()};db.postComments.push(c);audit(db,u,'comment','connect_post',item.id);save(db);return send(res,201,{ok:true,comment:c,commentCount:db.postComments.filter(x=>x.postId===item.id).length});
  }
  if(p==='/api/admin/connect/posts'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;const db=load();return send(res,200,{ok:true,posts:db.posts.map(x=>connectPostView(x,db))})}
  if(p==='/api/admin/connect/posts'&&req.method==='PATCH'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),item=db.posts.find(x=>x.id===clean(b.id,120));if(!item)return send(res,404,{ok:false,error:'Community post not found.'});const action=clean(b.action,30);
    if(action==='publish'){if(!['pending','rejected'].includes(item.status))return send(res,409,{ok:false,error:'Only pending or rejected posts can be published.'});item.status='published';item.publishedAt=new Date().toISOString();item.updatedAt=item.publishedAt;item.rejectionReason='';audit(db,actor,'publish','connect_post',item.id);}
    else if(action==='reject'){item.status='rejected';item.rejectionReason=clean(b.reason,500);item.updatedAt=new Date().toISOString();audit(db,actor,'reject','connect_post',item.id,{reason:item.rejectionReason});}
    else return send(res,400,{ok:false,error:'Action must be publish or reject.'});
    save(db);return send(res,200,{ok:true,post:connectPostView(item,db)});
  }
  if(p==='/api/admin/connect/posts/takedown'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),item=db.posts.find(x=>x.id===clean(b.id,120));if(!item)return send(res,404,{ok:false,error:'Community post not found.'});
    item.status='archived';item.archivedAt=new Date().toISOString();item.updatedAt=item.archivedAt;audit(db,actor,'takedown','connect_post',item.id,{reason:clean(b.reason,500)});save(db);return send(res,200,{ok:true,post:connectPostView(item,db)});
  }
  // V36 PTA & Parent Partnership — moderated school/parent communication foundation.
  if(p==='/api/pta'&&req.method==='GET'){const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();return send(res,200,{ok:true,pta:{...db.pta,posts:db.pta.posts.filter(x=>x.status==='published'),meetings:db.pta.meetings.filter(x=>x.status!=='archived')}})}
  if(p==='/api/pta/posts'&&req.method==='POST'){const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const b=await body(req),db=load();if(!DEV_OPEN_ACCESS&&!['parent','teacher','admin','super_admin'].includes(u.role))return send(res,403,{ok:false,error:'Parent or school staff permission required.'});const title=clean(b.title,140),content=clean(b.content,1500);if(!title||!content)return send(res,400,{ok:false,error:'Title and content are required.'});const item={id:id('PTA'),title,content,authorId:u.id,authorName:u.name,status:isAdmin(u)?'published':'pending',createdAt:new Date().toISOString()};db.pta.posts.push(item);audit(db,u,'create','pta_post',item.id,{status:item.status});save(db);return send(res,201,{ok:true,post:item})}
  if(p==='/api/pta/meetings'&&req.method==='GET'){const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();return send(res,200,{ok:true,meetings:db.pta.meetings.filter(x=>x.status!=='archived')})}
  if(p==='/api/admin/pta'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;const db=load();return send(res,200,{ok:true,pta:db.pta})}
  if(p==='/api/admin/pta/posts'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,posts:load().pta.posts})}
  if(p==='/api/admin/pta/posts'&&req.method==='PATCH'){const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),item=db.pta.posts.find(x=>x.id===clean(b.id,100));if(!item)return send(res,404,{ok:false,error:'PTA post not found.'});if(!['published','pending','rejected','archived'].includes(b.status))return send(res,400,{ok:false,error:'Invalid status.'});item.status=b.status;audit(db,actor,'moderate','pta_post',item.id,{status:b.status});save(db);return send(res,200,{ok:true,post:item})}
  if(p==='/api/admin/pta/meetings'&&req.method==='POST'){const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),title=clean(b.title,140),date=clean(b.date,40),location=clean(b.location,140),notes=clean(b.notes,1000);if(!title||!date)return send(res,400,{ok:false,error:'Meeting title and date are required.'});const item={id:id('PTAM'),title,date,location,notes,status:'scheduled',createdAt:new Date().toISOString(),createdBy:actor.id};db.pta.meetings.push(item);audit(db,actor,'create','pta_meeting',item.id);save(db);return send(res,201,{ok:true,meeting:item})}
  if(p==='/api/admin/pta/settings'&&req.method==='PATCH'){const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();if(b.enabled!==undefined)db.pta.settings.enabled=!!b.enabled;audit(db,actor,'update','pta_settings','PTA',{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,settings:db.pta.settings})}
  // V35 MARISCAN AI — permission-aware school knowledge assistant. No external provider is used in this prototype.
  function aiConfigView(db){return {...(db.ai||{}),provider:process.env.OPENAI_API_KEY?'openai':'local'};}
  function extractOpenAISources(response){const out=[];const seen=new Set();for(const item of (response?.output||[]))for(const c of (item?.content||[]))for(const a of (c?.annotations||[])){const url=a?.url||a?.source?.url;if(url&&!seen.has(url)){seen.add(url);out.push({title:a.title||a.text||url,url});}}return out.slice(0,10);}
  async function openAILocalAnswer(question,u,db,useInternet,history){
    const key=process.env.OPENAI_API_KEY;if(!key)return null;
    const input=[...(Array.isArray(history)?history.slice(-12):[]).map(x=>({role:x.role==='assistant'?'assistant':'user',content:clean(x.content,1200)})),{role:'user',content:question}];
    const tools=useInternet?[{type:'web_search'}]:[];
    const instructions=`You are MARISCAN AI for St. Mary's Boys' Senior High School Digital Network in Ghana. Be educational, accurate and age-appropriate. Never reveal passwords, tokens, API keys or private student records. School facts: the school is at Apowa near Takoradi, was established January 26, 1947, motto Disce Ut Doceas, and has Science, General Arts, Visual Arts, Agriculture and Business departments. For personal academic questions use only records supplied by the application. ${useInternet?'Use live web search for current information and distinguish web information from verified school records.':''}`;
    const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},body:JSON.stringify({model:'gpt-5.6-luna',instructions,input,tools,store:false})});
    const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d?.error?.message||'OpenAI MARISCAN backend request failed.');
    return {answer:d.output_text||'I could not generate an answer.',source:useInternet?'OpenAI + live web search':'OpenAI MARISCAN',internet:extractOpenAISources(d)};
  }
  function aiText(value){return String(value||'').toLowerCase().replace(/[^a-z0-9\s/.-]/g,' ').replace(/\s+/g,' ').trim();}
  function aiContains(q, words){return words.some(w=>q.includes(w));}
  function mariscanAnswer(q,u,db){
    const n=aiText(q); const publicFacts={
      school:["St. Mary's Boys' Senior High School is a Catholic boys' senior high school at Apowa near Takoradi in Ghana. The school was established on January 26, 1947."],
      motto:["The school motto is “Disce Ut Doceas”, meaning “Learn in order to teach.”"],
      departments:["The academic departments include Science, General Arts, Visual Arts, Agriculture and Business."],
      classes:[`The current class structure has Science and General Arts with 6 classes per SHS level, Visual Arts with 5, Agriculture with 2 and Business with 2. Class counts are administrator-configurable.`],
      platform:["St. Mary's Digital Network combines school information, learning, classes, community, heritage, media and student services in one platform."],
    };
    if(aiContains(n,['password','passwords','login','account'])) return {answer:'I can help with account and login guidance, but I will never reveal passwords, password hashes, session tokens or private credentials.',source:'security policy'};
    if(aiContains(n,['motto'])) return {answer:publicFacts.motto[0],source:'school knowledge'};
    if(aiContains(n,['when','established','founded','started','history'])&&aiContains(n,['school','mary'])) return {answer:publicFacts.school[0],source:'school knowledge'};
    if(aiContains(n,['department','departments','programmes','programs'])) return {answer:publicFacts.departments[0],source:'school knowledge'};
    if(aiContains(n,['class','classes'])) return {answer:publicFacts.classes[0],source:'school knowledge'};
    if(aiContains(n,['platform','website','digital network','digital legacy'])) return {answer:publicFacts.platform[0],source:'platform knowledge'};
    if(aiContains(n,['my result','my results','my grades','my marks','my transcript','academic record'])){
      const own=db.academicRecords.filter(r=>r.studentId===u.id); if(!own.length) return {answer:'I could not find academic records attached to your account yet. Your teacher or administrator may need to enter them.',source:'academic records'};
      const latest=own.slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).slice(0,5).map(r=>`${r.subject}: ${r.score??'—'}${r.grade?` (${r.grade})`:''}`).join('; ');
      return {answer:`I found ${own.length} academic record${own.length===1?'':'s'} attached to your account. Recent entries: ${latest}.`,source:'your academic records'};
    }
    if(aiContains(n,['my class','what class','which class'])){
      const cls=db.classes.find(c=>c.id===u.classId||c.name===u.className); return cls?{answer:`Your account is associated with ${cls.name}.`,source:'your account'}:{answer:'Your account does not currently have a class assigned.',source:'your account'};
    }
    if(aiContains(n,['teacher','teachers'])&&aiContains(n,['class','my class'])){
      const cls=db.classes.find(c=>c.id===u.classId||c.name===u.className); if(!cls)return {answer:'Your account does not currently have a class assigned.',source:'your account'};
      const names=(cls.teacherIds||[]).map(id=>db.users.find(x=>x.id===id)?.name).filter(Boolean); return {answer:names.length?`Your class has these assigned teacher accounts: ${names.join(', ')}.`:'No teacher accounts are currently assigned to this class.',source:'class records'};
    }
    if(aiContains(n,['help','what can you do','commands','features'])) return {answer:'I can answer approved school-knowledge questions, help you understand the platform, and—when your account has permission—summarize your own academic information. I will not expose private data or credentials.',source:'MARISCAN capabilities'};
    return {answer:"I don't have enough verified school information to answer that confidently yet. Try asking about the school's motto, history, departments, classes, the Digital Network, or your own academic records.",source:'verified knowledge only'};
  }
  if(p==='/api/ai/status'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();return send(res,200,{ok:true,ai:{...aiConfigView(db),access:'authenticated'}});
  }
  if(p==='/api/ai/query'&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();if(db.ai?.enabled===false)return send(res,503,{ok:false,error:'MARISCAN AI is temporarily disabled by the administrator.'});
    const b=await body(req),question=clean(b.question,500);if(!question)return send(res,400,{ok:false,error:'Question is required.'});
    const useInternet=b.useInternet===true||b.web===true;let result=await openAILocalAnswer(question,u,db,useInternet,b.history);if(!result)result=mariscanAnswer(question,u,db);const internet=result.internet||[];if(!result.internet&&useInternet){const wiki=await wikipediaLookup(question);result.internet=wiki;result.source=result.source+' + Wikipedia lookup';}audit(db,u,'ai_query','ai',{question:question.slice(0,160),source:result.source,internetResults:(result.internet||[]).length,provider:process.env.OPENAI_API_KEY?'openai':'local'});save(db);return send(res,200,{ok:true,assistant:{name:db.ai?.name||'MARISCAN AI',...result,internet:result.internet||[]}});
  }
  if(p==='/api/admin/ai'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,ai:aiConfigView(load())});}
  if(p==='/api/admin/ai'&&req.method==='PATCH'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();db.ai??={};if(b.enabled!==undefined)db.ai.enabled=!!b.enabled;if(b.name!==undefined)db.ai.name=clean(b.name,80)||'MARISCAN AI';if(b.mode!==undefined&&['school-knowledge'].includes(b.mode))db.ai.mode=b.mode;audit(db,actor,'update','ai_config','MARISCAN',{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,ai:aiConfigView(db)});
  }

  if(p==='/api/site-content'&&req.method==='GET'){const db=load(),s=db.meta.settings||{};return send(res,200,{ok:true,content:{mission:s.mission||'',vision:s.vision||'',conduct:s.conduct||'',policies:s.policies||'',transcriptUrl:s.transcriptUrl||'..........................',schoolMapUrl:s.schoolMapUrl||'https://www.google.com/maps/search/?api=1&query=St.+Mary%27s+Boys%27+Senior+High+School+Apowa+Ghana'}})}
  if(p==='/api/admin/site-content'&&req.method==='PATCH'){const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();for(const k of ['mission','vision','conduct','policies','transcriptUrl','schoolMapUrl'])if(b[k]!==undefined)db.meta.settings[k]=clean(b[k],4000);audit(db,actor,'update','site_content','GLOBAL',{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,content:db.meta.settings})}
  if(p==='/api/site-config'&&req.method==='GET'){const db=load(),s=db.meta.settings||{};return send(res,200,{ok:true,site:{title:s.siteTitle||"St. Mary's Digital Network",subtitle:s.siteSubtitle||'',heroImage:s.heroImage||'',faviconImage:s.faviconImage||'',creatorName:s.creatorName||'[Creator name]',creatorBio:s.creatorBio||'',creatorImage:s.creatorImage||'',creatorBackground:s.creatorBackground||'',academicYear:db.meta.academicYear||''}})}
  if(p==='/api/site-access'&&req.method==='GET'){const db=load();return send(res,200,{ok:true,required:!!db.meta.siteAccess?.required})}
  if(p==='/api/site-access'&&req.method==='POST'){const b=await body(req),db=load(),code=String(b.code||'');if(!db.meta.siteAccess?.required)return send(res,200,{ok:true,notRequired:true});const s=db.meta.siteAccess;if(!s.hash)return send(res,503,{ok:false,error:'School access code has not been configured.'});const expected=hashWithSalt(code,s.salt);if(expected.length!==s.hash.length||!crypto.timingSafeEqual(Buffer.from(expected,'hex'),Buffer.from(s.hash,'hex')))return send(res,403,{ok:false,error:'Invalid school access code.'});return send(res,200,{ok:true},{'Set-Cookie':`sm_site_access=${encodeURIComponent(code)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${process.env.NODE_ENV==='production'?'; Secure':''}`})}
  if(p==='/api/signup'&&req.method==='POST'){const b=await body(req),db=load(),name=clean(b.fullName,120),email=clean(b.email,180).toLowerCase(),studentId=clean(b.studentId,80);if(!name||!email||!studentId||(!DEV_OPEN_ACCESS&&String(b.password||'').length<8))return send(res,400,{ok:false,error:DEV_OPEN_ACCESS?'Full name, email and student ID are required.':'Full name, email, student ID and an 8+ character password are required.'});if(db.users.some(x=>x.id.toLowerCase()===studentId.toLowerCase()))return send(res,409,{ok:false,error:'That student ID already has an account.'});if(db.users.some(x=>String(x.email||'').toLowerCase()===email))return send(res,409,{ok:false,error:'That email address is already registered.'});const person={id:id('PER'),personType:'Student',name,studentId,department:clean(b.department,100),className:clean(b.className,120),house:clean(b.house,100),email,photoAsset:'',status:'active',createdAt:new Date().toISOString()};const rec=makePasswordRecord(String(b.password||crypto.randomBytes(32).toString('hex')));const account={id:studentId,name,email,role:'student',department:person.department,className:person.className,house:person.house,personId:person.id,...rec,status:'active',createdAt:new Date().toISOString()};db.people.push(person);db.users.push(account);audit(db,account,'signup','account',account.id);save(db);return send(res,201,{ok:true,user:safeUser(account)})}
  if(p==='/api/admin/site-access/rotate'&&req.method==='POST'){const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),code=String(b.code||'').trim(),db=load();if(code.length<6)return send(res,400,{ok:false,error:'School code must be at least 6 characters.'});db.meta.siteAccess={required:b.required!==false, salt:crypto.randomBytes(16).toString('hex'), hash:hashWithSalt(code,db.meta.siteAccess?.salt||crypto.randomBytes(16).toString('hex'))};db.meta.siteAccess.hash=hashWithSalt(code,db.meta.siteAccess.salt);audit(db,actor,'rotate','school_access_code','SYSTEM',{required:db.meta.siteAccess.required});save(db);return send(res,200,{ok:true,required:db.meta.siteAccess.required,message:'School access code updated. The code itself is never returned by the server.'})}
  // V58 open-testing identity switch: lets a newly created test person land in their own homepage.
  // This route exists only outside production and is intentionally unavailable once production mode is enabled.
  if(p==='/api/dev/assume-user'&&req.method==='POST'){
    if(!DEV_OPEN_ACCESS)return send(res,403,{ok:false,error:'Open testing mode is disabled.'});
    const b=await body(req),db=load(),user=db.users.find(x=>x.id===clean(b.userId,180));
    if(!user||user.status==='disabled')return send(res,404,{ok:false,error:'Test user not found.'});
    return send(res,200,{ok:true,user:safeUser(user)},{'Set-Cookie':`sm_dev_user=${encodeURIComponent(user.id)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400`});
  }
  // Firebase authentication bridge — production-safe ID-token verification.
  // The browser authenticates with Firebase; this backend verifies the signed ID token,
  // mirrors the account into PostgreSQL/application state, then issues the normal backend session.
  if(p==='/api/auth/firebase-sync'&&req.method==='POST'){
    const header=String(req.headers.authorization||'');
    const match=header.match(/^Bearer\s+(.+)$/i);
    if(!match)return send(res,401,{ok:false,error:'Firebase authentication token required.'});
    let decoded;
    try{decoded=await getFirebaseAdminAuth().verifyIdToken(match[1],true)}
    catch(e){return send(res,401,{ok:false,error:'Invalid or expired Firebase session.'})}
    const b=await body(req),db=load();
    const firebaseUid=clean(decoded.uid,180),email=clean(decoded.email||b.email,180).toLowerCase(),name=clean(b.displayName||decoded.name||decoded.email?.split('@')[0]||'Student',120);
    if(!firebaseUid||!email)return send(res,400,{ok:false,error:'Verified Firebase account is missing an email address.'});
    let user=db.users.find(x=>x.firebaseUid===firebaseUid)||db.users.find(x=>String(x.email||'').toLowerCase()===email);
    if(!user){
      const accountId='FB-'+firebaseUid.replace(/[^A-Za-z0-9_-]/g,'').slice(0,48);
      const personId=id('PER');
      const person={id:personId,personType:'Student',name,email,studentId:accountId,department:'',className:'',house:'',photoAsset:'',status:'active',createdAt:new Date().toISOString()};
      user={id:accountId,name,email,role:'student',department:'',className:'',house:'',personId,firebaseUid,status:'active',createdAt:new Date().toISOString()};
      db.people.push(person);db.users.push(user);audit(db,user,'firebase_sync_create','account',user.id,{firebaseUid});
    }else{
      user.firebaseUid=firebaseUid;user.email=email;user.name=name||user.name;user.status=user.status==='disabled'?'disabled':'active';
      const person=db.people.find(x=>x.id===user.personId);if(person){person.name=user.name;person.email=email;}
      audit(db,user,'firebase_sync','account',user.id,{firebaseUid});
    }
    if(user.status==='disabled')return send(res,403,{ok:false,error:'This school account has been disabled.'});
    save(db);
    const token=process.env.NODE_ENV==='production'?backendCore.signSession(user.id,process.env.SESSION_SECRET):crypto.randomBytes(32).toString('hex');
    if(process.env.NODE_ENV!=='production')sessions.set(token,{userId:user.id,expires:Date.now()+8*60*60*1000});
    return send(res,200,{ok:true,user:safeUser(user),firebaseVerified:true},{'Set-Cookie':`sm_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800${process.env.NODE_ENV==='production'?'; Secure':''}`});
  }
  if(p==='/api/login'&&req.method==='POST'){
   const b=await body(req),db=load();
   if(DEV_OPEN_ACCESS){
    const u=db.users.find(x=>x.id.toLowerCase()===MASTER_ID.toLowerCase());
    if(!u)return send(res,503,{ok:false,error:'Development master account unavailable.'});
    const token=crypto.randomBytes(32).toString('hex');sessions.set(token,{userId:u.id,expires:Date.now()+8*60*60*1000});
    audit(db,u,'development_open_login','account',u.id);save(db);
    return send(res,200,{ok:true,user:safeUser(u),developmentOpen:true},{'Set-Cookie':`sm_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800`});
   }
   const u=db.users.find(x=>x.id.toLowerCase()===clean(b.schoolId,80).toLowerCase());
   if(!u||u.status==='disabled'||!verifyPassword(String(b.password||''),u))return send(res,401,{ok:false,error:'Invalid school ID or password.'});
   const token=process.env.NODE_ENV==='production'?backendCore.signSession(u.id,process.env.SESSION_SECRET):crypto.randomBytes(32).toString('hex');if(process.env.NODE_ENV!=='production')sessions.set(token,{userId:u.id,expires:Date.now()+8*60*60*1000});u.lastLoginAt=new Date().toISOString();audit(db,u,'login','account',u.id);save(db);
   return send(res,200,{ok:true,user:safeUser(u)},{'Set-Cookie':`sm_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800${process.env.NODE_ENV==='production'?'; Secure':''}`});
  }
  if(p==='/api/me'&&req.method==='GET'){const u=sessionUser(req);return u?send(res,200,{ok:true,user:safeUser(u)}):send(res,401,{ok:false})}
  if(p==='/api/master-access'&&req.method==='POST'){
    const b=await body(req);const name=clean(b.name,80).replace(/\s+/g,'');
    // Development-only founder shortcut. Production must replace this with a real second factor/secret.
    if(process.env.NODE_ENV==='production')return send(res,403,{ok:false,error:'Founder shortcut is disabled in production.'});
    if(name.toUpperCase()!=='SHAIBU.A')return send(res,403,{ok:false,error:'Master access name not recognized.'});
    const db=load(),master=db.users.find(x=>x.id.toLowerCase()===MASTER_ID.toLowerCase());
    if(!master||master.status!=='active')return send(res,403,{ok:false,error:'Master account is unavailable.'});
    const token=crypto.randomBytes(32).toString('hex');sessions.set(token,{userId:master.id,expires:Date.now()+8*60*60*1000});
    audit(db,master,'master_shortcut_login','account',master.id,{method:'founder-name'});save(db);
    return send(res,200,{ok:true,user:safeUser(master),masterAccess:true},{'Set-Cookie':`sm_session=${token}; HttpOnly; Path=/; SameSite=Lax`});
  }

  if(p==='/api/auth/status'&&req.method==='GET'){const db=load(),u=sessionUser(req),m=db.users.find(x=>x.id.toLowerCase()===MASTER_ID.toLowerCase());return send(res,200,{ok:true,authenticated:!!u,user:u?safeUser(u):null,master:{id:MASTER_ID,exists:!!m,role:m?.role||null,status:m?.status||null,passwordScheme:m?.passwordScheme||null}})}
  if(p==='/api/account/profile'&&req.method==='GET'){
   const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
   const db=load(),fresh=db.users.find(x=>x.id===u.id)||u,person=fresh.personId?db.people.find(x=>x.id===fresh.personId):null;
   return send(res,200,{ok:true,profile:{...safeUser(fresh),person:person?{id:person.id,name:person.name,personType:person.personType,studentId:person.studentId||'',staffId:person.staffId||'',department:person.department||'',className:person.className||'',status:person.status||'active'}:null}})
  }
  if(p==='/api/account/profile'&&req.method==='PATCH'){
   const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
   const b=await body(req),db=load(),user=db.users.find(x=>x.id===u.id);if(!user)return send(res,404,{ok:false,error:'Account not found.'});
   const allowed=['name','profilePhoto','department','className','house'];const changed=[];
   for(const k of allowed)if(b[k]!==undefined){user[k]=clean(b[k],k==='profilePhoto'?500:120);changed.push(k)}
   const person=user.personId?db.people.find(x=>x.id===user.personId):null;
   if(person){for(const k of ['name','department','className','house'])if(b[k]!==undefined)person[k]=clean(b[k],120);}
   if(b.className!==undefined){const c=db.classes.find(x=>x.name===user.className&&x.status!=='archived');if(c){user.classId=c.id;user.year=c.year;user.department=c.department; if(person){person.className=c.name;person.department=c.department;}}}
   audit(db,user,'update','account',user.id,{fields:changed,source:'self-service'});save(db);return send(res,200,{ok:true,user:safeUser(user)})
  }
  if(p==='/api/account/password'&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const b=await body(req),db=load(),user=db.users.find(x=>x.id===u.id);
    const current=String(b.currentPassword||''),next=String(b.newPassword||'');
    if(!verifyPassword(current,user))return send(res,400,{ok:false,error:'Current password is incorrect.'});
    if(next.length<8)return send(res,400,{ok:false,error:'New password must be at least 8 characters.'});
    const rec=makePasswordRecord(next);Object.assign(user,rec);user.passwordChangedAt=new Date().toISOString();
    audit(db,user,'change_password','account',user.id);save(db);return send(res,200,{ok:true,message:'Password changed successfully.'});
  }
  if(p==='/api/logout'&&req.method==='POST'){const cookie=(req.headers.cookie||'').match(/(?:^|; )sm_session=([^;]+)/);if(cookie)sessions.delete(cookie[1]);return send(res,200,{ok:true},{'Set-Cookie':[`sm_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${process.env.NODE_ENV==='production'?'; Secure':''}`,`sm_dev_user=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${process.env.NODE_ENV==='production'?'; Secure':''}`]})}
  // V42.2 — Unified Administrator Control Centre: one place to maintain live school content.
  if(p==='/api/admin/content/bootstrap'&&req.method==='GET'){
   const actor=requireAdmin(req,res);if(!actor)return;const db=load();return send(res,200,{ok:true,people:db.people.filter(x=>x.status!=='archived'),clubs:db.clubs.filter(x=>x.status!=='archived'),houses:db.houses.filter(x=>x.status!=='archived'),classes:db.classes.filter(x=>x.status!=='archived'),media:db.mediaAssets.filter(x=>x.status!=='archived').map(x=>({...x,url:'/media/'+x.id})),settings:db.meta.settings,academicYear:db.meta.academicYear});
  }
  if(p==='/api/admin/site-content'&&req.method==='GET'){
   const actor=requireAdmin(req,res);if(!actor)return;const db=load();return send(res,200,{ok:true,settings:db.meta.settings});
  }
  if(p==='/api/admin/site-content'&&req.method==='PATCH'){
   const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();
   const allowed=['siteTitle','siteSubtitle','creatorName','creatorBio','creatorImage','creatorBackground','faviconImage','heroImage','academicYear'];
   const changed=[];for(const k of allowed)if(b[k]!==undefined){if(k==='academicYear')db.meta.academicYear=clean(b[k],30);else db.meta.settings[k]=clean(b[k],k==='creatorBio'?3000:1200);changed.push(k)}
   audit(db,actor,'update','site_content','SYSTEM',{fields:changed});save(db);return send(res,200,{ok:true,settings:db.meta.settings,academicYear:db.meta.academicYear});
  }
  if(p==='/api/admin/summary'&&req.method==='GET'){
   const actor=requireAdmin(req,res);if(!actor)return;const db=load();return send(res,200,{ok:true,summary:{people:db.people.length,students:db.people.filter(x=>x.personType==='Student').length,teachers:db.people.filter(x=>x.personType==='Teacher').length,classes:db.classes.length,clubs:db.clubs.length,activities:db.activities.length,accounts:db.users.length,auditEntries:db.audit.length}})
  }
  if(p==='/api/admin/accounts'&&req.method==='GET'){
   const actor=requireAdmin(req,res);if(!actor)return;const db=load();
   return send(res,200,{ok:true,accounts:db.users.map(u=>safeUser(u)).filter(u=>!u.systemAccount)})
  }
  const accountMatch=p.match(/^\/api\/admin\/accounts\/([^/]+)$/);
  if(accountMatch&&req.method==='PATCH'){
   const actor=requireAdmin(req,res);if(!actor)return;const db=load(),user=db.users.find(x=>x.id===accountMatch[1]);if(!user)return send(res,404,{ok:false,error:'Account not found.'});
   if(user.systemAccount&&actor.id!==MASTER_ID)return send(res,403,{ok:false,error:'Only the master administrator can modify the system account.'});
   const b=await body(req),fields=[];
   if(b.name!==undefined){user.name=clean(b.name,120);fields.push('name')}
   if(b.role!==undefined){const roles=['student','teacher','prefect','parent','admin'];if(user.systemAccount&&b.role!=='super_admin')return send(res,400,{ok:false,error:'The master account must remain super_admin.'});if(!roles.includes(b.role)&&b.role!=='super_admin')return send(res,400,{ok:false,error:'Invalid role.'});if(user.role==='super_admin'&&b.role!=='super_admin'&&actor.id!==MASTER_ID)return send(res,403,{ok:false,error:'Only the master administrator can change a super-admin role.'});user.role=b.role;fields.push('role')}
   if(b.department!==undefined){user.department=clean(b.department,100);fields.push('department')}
   if(b.className!==undefined){user.className=clean(b.className,140);fields.push('className')}
   if(b.house!==undefined){user.house=clean(b.house,100);fields.push('house')}
   if(b.status!==undefined){if(!['active','disabled'].includes(b.status))return send(res,400,{ok:false,error:'Invalid account status.'});if(user.systemAccount&&b.status!=='active')return send(res,400,{ok:false,error:'The master account must remain active.'});user.status=b.status;fields.push('status')}
   audit(db,actor,'update','account',user.id,{fields});save(db);return send(res,200,{ok:true,user:safeUser(user)})
  }
  if(p==='/api/admin/people'&&req.method==='GET'){
   const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,people:load().people})
  }
  if(p==='/api/admin/people'&&req.method==='POST'){
   const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();
   const type=clean(b.personType,30)||'Student';const name=clean(b.name,120);if(!name)return send(res,400,{ok:false,error:'Name is required.'});
   if(type==='Student'&&!clean(b.studentId,80))return send(res,400,{ok:false,error:'Student ID is required for students.'});
   if(type==='Student'&&db.people.some(x=>x.studentId&&x.studentId.toLowerCase()===clean(b.studentId,80).toLowerCase()))return send(res,409,{ok:false,error:'That Student ID already exists.'});
   const person={id:id('PER'),personType:type,name,studentId:type==='Student'?clean(b.studentId,80):'',staffId:type!=='Student'?clean(b.staffId,80):'',department:clean(b.department,100),className:clean(b.className,120),photoAsset:'',status:'active',createdAt:new Date().toISOString()};db.people.push(person);
   let account=null;
   const accountId=type==='Student'?person.studentId:clean(b.staffId,80)||person.id;
   const existing=db.users.find(x=>x.id.toLowerCase()===accountId.toLowerCase());
   if(existing){account=existing;account.name=person.name;account.personId=person.id;account.department=person.department;account.className=person.className;account.status='active';}
   else if(b.createAccount || DEV_OPEN_ACCESS){
     const suppliedPassword=clean(b.initialPassword,120);
     const rec= suppliedPassword.length>=8 ? makePasswordRecord(suppliedPassword) : makePasswordRecord(crypto.randomBytes(32).toString('hex'));
     account={id:accountId,name:person.name,role:type==='Administrator'?'admin':type==='Prefect'?'prefect':type==='Teacher'?'teacher':'student',department:person.department,className:person.className,...rec,status:'active',personId:person.id,createdAt:new Date().toISOString(),passwordSetupPending:DEV_OPEN_ACCESS&&suppliedPassword.length<8};
     db.users.push(account);
   }
   audit(db,actor,'create','person',person.id,{personType:type,accountCreated:!!account,openTesting:DEV_OPEN_ACCESS});save(db);
   return send(res,201,{ok:true,person,account:account?safeUser(account):null,openTesting:DEV_OPEN_ACCESS});
  }
  const peopleMatch=p.match(/^\/api\/admin\/people\/([^/]+)$/);
  if(peopleMatch&&(req.method==='PATCH'||req.method==='DELETE')){
   const actor=requireAdmin(req,res);if(!actor)return;const db=load(),person=findById(db.people,peopleMatch[1]);if(!person)return send(res,404,{ok:false,error:'Person not found.'});
   if(req.method==='DELETE'){person.status='archived';const account=db.users.find(x=>x.personId===person.id);if(account)account.status='disabled';audit(db,actor,'archive','person',person.id);save(db);return send(res,200,{ok:true})}
   const b=await body(req);for(const k of ['name','department','className','studentId','staffId','house','status','photoAsset'])if(b[k]!==undefined)person[k]=clean(b[k],k==='photoAsset'?500:180);audit(db,actor,'update','person',person.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,person})
  }
  if(p==='/api/admin/classes'&&req.method==='GET'){
   const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,classes:load().classes})
  }
  if(p==='/api/admin/classes'&&req.method==='POST'){
   const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();const department=clean(b.department,100),year=clean(b.year,30),name=clean(b.name,120),code=clean(b.code,80);if(!department||!year||!name)return send(res,400,{ok:false,error:'Department, year and class name are required.'});if(code&&db.classes.some(x=>x.code.toLowerCase()===code.toLowerCase()))return send(res,409,{ok:false,error:'That class code already exists.'});const item={id:id('CLS'),department,year,name,code,status:'active',createdAt:new Date().toISOString()};db.classes.push(item);audit(db,actor,'create','class',item.id,{department,year});save(db);return send(res,201,{ok:true,class:item})
  }
  const classMatch=p.match(/^\/api\/admin\/classes\/([^/]+)$/);if(classMatch&&(req.method==='PATCH'||req.method==='DELETE')){const actor=requireAdmin(req,res);if(!actor)return;const db=load(),item=findById(db.classes,classMatch[1]);if(!item)return send(res,404,{ok:false,error:'Class not found.'});if(req.method==='DELETE'){item.status='archived';audit(db,actor,'archive','class',item.id);save(db);return send(res,200,{ok:true})}const b=await body(req);for(const k of ['department','year','name','code','status'])if(b[k]!==undefined)item[k]=clean(b[k],140);if(b.teacherIds!==undefined){if(!Array.isArray(b.teacherIds))return send(res,400,{ok:false,error:'teacherIds must be an array.'});item.teacherIds=[...new Set(b.teacherIds.map(x=>clean(x,100)).filter(Boolean))]}if(b.captainId!==undefined)item.captainId=clean(b.captainId,100);if(b.formMasterId!==undefined)item.formMasterId=clean(b.formMasterId,100);audit(db,actor,'update','class',item.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,class:item})}
  if(p==='/api/admin/classes/generate-code'&&req.method==='POST'){const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),item=findById(db.classes,clean(b.classId,120));if(!item)return send(res,404,{ok:false,error:'Class not found.'});const raw=`${item.code}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;item.joinCodeHash=hashWithSalt(raw,item.id);item.joinCodeIssuedAt=new Date().toISOString();audit(db,actor,'rotate_join_code','class',item.id);save(db);return send(res,200,{ok:true,classId:item.id,joinCode:raw})}
  // V34 Academic Records & Transcript Foundation
  function academicRecordView(r,db){
   const student=db.users.find(x=>x.id===r.studentId);
   return {...r,studentName:student?.name||r.studentName||'Unknown student',studentClass:student?.className||r.studentClass||'',department:student?.department||r.department||''};
  }
  function canManageStudentAcademic(u,student,db){
   if(isAdmin(u)) return true;
   if(!student||u.role!=='teacher') return false;
   const c=db.classes.find(x=>x.id===student.classId||x.name===student.className);
   return !!(c&&(c.teacherIds||[]).includes(u.id)||c?.formMasterId===u.id);
  }
  if(p==='/api/account/academic'&&req.method==='GET'){
   const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
   if(u.role!=='student'&&!isAdmin(u)&&u.role!=='teacher')return send(res,403,{ok:false,error:'Academic records are restricted.'});
   const db=load(),studentId=url.searchParams.get('studentId')||u.id,student=db.users.find(x=>x.id===studentId);
   if(!student)return send(res,404,{ok:false,error:'Student account not found.'});
   if(studentId!==u.id&&!canManageStudentAcademic(u,student,db))return send(res,403,{ok:false,error:'You are not authorised to view this student record.'});
   const records=db.academicRecords.filter(r=>r.studentId===studentId).sort((a,b)=>String(b.date||b.createdAt).localeCompare(String(a.date||a.createdAt)));
   const grouped={};for(const r of records){const key=`${r.academicYear} — ${r.term}`;(grouped[key]??=[]).push(academicRecordView(r,db));}
   return send(res,200,{ok:true,student:{id:student.id,name:student.name,className:student.className||'',department:student.department||'',year:student.year||''},records,grouped});
  }
  if(p==='/api/account/transcript'&&req.method==='GET'){
   const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
   if(u.role!=='student'&&!isAdmin(u)&&u.role!=='teacher')return send(res,403,{ok:false,error:'Transcript access is restricted.'});
   const db=load(),studentId=url.searchParams.get('studentId')||u.id,student=db.users.find(x=>x.id===studentId);
   if(!student)return send(res,404,{ok:false,error:'Student account not found.'});
   if(studentId!==u.id&&!canManageStudentAcademic(u,student,db))return send(res,403,{ok:false,error:'You are not authorised to view this transcript.'});
   const records=db.academicRecords.filter(r=>r.studentId===studentId).sort((a,b)=>String(a.academicYear).localeCompare(String(b.academicYear))||String(a.term).localeCompare(String(b.term))||String(a.subject).localeCompare(String(b.subject)));
   return send(res,200,{ok:true,transcript:{school:"St. Mary's Boys' Senior High School",motto:'Disce Ut Doceas',student:{id:student.id,name:student.name,className:student.className||'',department:student.department||''},records,generatedAt:new Date().toISOString(),notice:'Development transcript view — official school transcripts must be issued/verified by authorised school personnel.'}});
  }
  if(p==='/api/admin/academic/subjects'&&req.method==='GET'){
   const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,subjects:load().academicSubjects});
  }
  if(p==='/api/admin/academic/subjects'&&req.method==='POST'){
   const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),name=clean(b.name,120),department=clean(b.department,100),subjectCode=clean(b.subjectCode,30).toUpperCase();
   if(!name)return send(res,400,{ok:false,error:'Subject name is required.'});
   if(db.academicSubjects.some(x=>x.name.toLowerCase()===name.toLowerCase()&&x.department.toLowerCase()===department.toLowerCase()))return send(res,409,{ok:false,error:'That subject already exists for this department.'});
   const item={id:id('SUB'),name,subjectCode,department,status:'active',createdAt:new Date().toISOString()};db.academicSubjects.push(item);audit(db,actor,'create','academic_subject',item.id);save(db);return send(res,201,{ok:true,subject:item});
  }
  if(p==='/api/admin/academic/records'&&req.method==='GET'){
   const actor=requireAdmin(req,res);if(!actor)return;const db=load(),studentId=clean(url.searchParams.get('studentId')||'',100),records=db.academicRecords.filter(r=>!studentId||r.studentId===studentId).map(r=>academicRecordView(r,db));
   return send(res,200,{ok:true,records});
  }
  if(p==='/api/admin/academic/records'&&req.method==='POST'){
   const actor=sessionUser(req);if(!actor)return send(res,401,{ok:false,error:'Authentication required.'});
   const b=await body(req),db=load(),studentId=clean(b.studentId,100),student=db.users.find(x=>x.id===studentId);
   if(!student||student.role!=='student')return send(res,400,{ok:false,error:'A valid student account is required.'});
   if(!canManageStudentAcademic(actor,student,db))return send(res,403,{ok:false,error:'You are not authorised to enter this student record.'});
   const academicYear=clean(b.academicYear,30),term=clean(b.term,40),subject=clean(b.subject,120),grade=clean(b.grade,30),remarks=clean(b.remarks,500);let score=b.score;
   if(!academicYear||!term||!subject)return send(res,400,{ok:false,error:'Academic year, term and subject are required.'});
   if(score!==''&&score!==null&&score!==undefined){score=Number(score);if(!Number.isFinite(score)||score<0||score>100)return send(res,400,{ok:false,error:'Score must be between 0 and 100.'})}else score=null;
   const duplicate=db.academicRecords.find(r=>r.studentId===studentId&&r.academicYear===academicYear&&r.term===term&&r.subject.toLowerCase()===subject.toLowerCase());
   if(duplicate)return send(res,409,{ok:false,error:'A record already exists for this student, term and subject.'});
   const item={id:id('ACR'),studentId,academicYear,term,subject,score,grade,remarks,enteredBy:actor.id,enteredByName:actor.name,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};db.academicRecords.push(item);audit(db,actor,'create','academic_record',item.id,{studentId,subject,academicYear,term});save(db);return send(res,201,{ok:true,record:academicRecordView(item,db)});
  }
  const academicRecordMatch=p.match(/^\/api\/admin\/academic\/records\/([^/]+)$/);
  if(academicRecordMatch&&(req.method==='PATCH'||req.method==='DELETE')){
   const actor=sessionUser(req);if(!actor)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),item=db.academicRecords.find(x=>x.id===academicRecordMatch[1]);if(!item)return send(res,404,{ok:false,error:'Academic record not found.'});const student=db.users.find(x=>x.id===item.studentId);
   if(!canManageStudentAcademic(actor,student,db))return send(res,403,{ok:false,error:'You are not authorised to change this record.'});
   if(req.method==='DELETE'){if(!isAdmin(actor))return send(res,403,{ok:false,error:'Only an administrator can delete academic records.'});db.academicRecords=db.academicRecords.filter(x=>x.id!==item.id);audit(db,actor,'delete','academic_record',item.id,{studentId:item.studentId});save(db);return send(res,200,{ok:true});}
   const b=await body(req);if(b.score!==undefined&&b.score!==null&&b.score!==''){const n=Number(b.score);if(!Number.isFinite(n)||n<0||n>100)return send(res,400,{ok:false,error:'Score must be between 0 and 100.'});item.score=n;}else if(b.score===null||b.score==='')item.score=null;
   for(const k of ['academicYear','term','subject','grade','remarks'])if(b[k]!==undefined)item[k]=clean(b[k],k==='remarks'?500:120);item.updatedAt=new Date().toISOString();audit(db,actor,'update','academic_record',item.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,record:academicRecordView(item,db)});
  }
  // V33 Real Class Ecosystem
  if(p==='/api/classes'&&req.method==='GET'){
   const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();
   const visible=db.classes.filter(c=>c.status!=='archived');
   return send(res,200,{ok:true,classes:visible.map(c=>({...c,joinCodeHash:undefined}))});
  }
  const publicClassMatch=p.match(/^\/api\/classes\/([^/]+)$/);
  if(publicClassMatch&&req.method==='GET'){
   const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),c=findById(db.classes,publicClassMatch[1]);if(!c||c.status==='archived')return send(res,404,{ok:false,error:'Class not found.'});
   const member= isAdmin(u)||c.teacherIds.includes(u.id)||c.formMasterId===u.id||c.captainId===u.id||((u.className||'')===c.name)||((db.users.find(x=>x.id===u.id)?.classId)===c.id);
   if(!member)return send(res,403,{ok:false,error:'You are not a member of this class.'});
   const space=db.classSpaces[c.id]||{};return send(res,200,{ok:true,class:{...c,joinCodeHash:undefined},space});
  }
  const joinMatch=p.match(/^\/api\/classes\/([^/]+)\/join$/);
  if(joinMatch&&req.method==='POST'){
   const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const b=await body(req),db=load(),c=findById(db.classes,joinMatch[1]);if(!c||c.status==='archived')return send(res,404,{ok:false,error:'Class not found.'});
   if(!c.joinCodeHash)return send(res,400,{ok:false,error:'This class does not have an active join code yet.'});const code=clean(b.joinCode,180).toUpperCase();if(!code||hashWithSalt(code,c.id)!==c.joinCodeHash)return send(res,403,{ok:false,error:'Invalid class join code.'});
   if(u.role==='student'||u.role==='prefect'){u.classId=c.id;u.className=c.name;u.department=c.department;u.year=c.year;db.users.find(x=>x.id===u.id).classId=c.id;db.users.find(x=>x.id===u.id).className=c.name;db.users.find(x=>x.id===u.id).department=c.department;db.users.find(x=>x.id===u.id).year=c.year;}
   audit(db,u,'join','class',c.id,{method:'join_code'});save(db);return send(res,200,{ok:true,class:{id:c.id,name:c.name,department:c.department,year:c.year}});
  }
  const membersMatch=p.match(/^\/api\/classes\/([^/]+)\/members$/);
  if(membersMatch&&req.method==='GET'){
   const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),c=findById(db.classes,membersMatch[1]);if(!c)return send(res,404,{ok:false,error:'Class not found.'});const allowed=isAdmin(u)||c.teacherIds.includes(u.id)||c.formMasterId===u.id||c.captainId===u.id||u.classId===c.id||u.className===c.name;if(!allowed)return send(res,403,{ok:false,error:'Class membership required.'});
   const students=db.users.filter(x=>x.status!=='disabled'&&(x.classId===c.id||x.className===c.name)).map(s=>({id:s.id,name:s.name,role:s.role,department:s.department||'',className:s.className||'',house:s.house||''}));const teachers=db.users.filter(x=>c.teacherIds.includes(x.id)||x.id===c.formMasterId).map(s=>({id:s.id,name:s.name,role:s.role}));return send(res,200,{ok:true,members:{students,teachers,captainId:c.captainId,formMasterId:c.formMasterId}});
  }
  const spaceMatch=p.match(/^\/api\/classes\/([^/]+)\/space$/);
  if(spaceMatch&&(req.method==='PATCH'||req.method==='POST')){
   const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),c=findById(db.classes,spaceMatch[1]);if(!c)return send(res,404,{ok:false,error:'Class not found.'});const canEdit=isAdmin(u)||c.teacherIds.includes(u.id)||c.formMasterId===u.id||(c.captainId===u.id&&req.method==='POST');if(!canEdit)return send(res,403,{ok:false,error:'Teacher or class leadership permission required.'});const b=await body(req),space=db.classSpaces[c.id]??={};const allowed=['timetable','dutyRoster','announcements','resources','assignments','documents','achievements','gallery','events'];
   if(req.method==='PATCH'){for(const k of allowed)if(b[k]!==undefined){if(!Array.isArray(b[k]))return send(res,400,{ok:false,error:`${k} must be an array.`});space[k]=b[k].slice(0,500)}else{};audit(db,u,'update','class_space',c.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,space})}
   const section=clean(b.section,40);if(!allowed.includes(section))return send(res,400,{ok:false,error:'Invalid class space section.'});const entry={id:id('CLSPOST'),title:clean(b.title,180),body:clean(b.body,4000),createdAt:new Date().toISOString(),authorId:u.id,authorName:u.name};if(!entry.title)return send(res,400,{ok:false,error:'Title is required.'});space[section]??=[];space[section].unshift(entry);space[section]=space[section].slice(0,500);audit(db,u,'create','class_space_item',entry.id,{classId:c.id,section});save(db);return send(res,201,{ok:true,item:entry,section})
  }
  if(p==='/api/clubs'&&req.method==='GET'){const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();return send(res,200,{ok:true,clubs:db.clubs.filter(x=>x.status!=='archived')})}
  const publicClub=p.match(/^\/api\/clubs\/([^/]+)$/);if(publicClub&&req.method==='GET'){const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),club=findById(db.clubs,publicClub[1]);if(!club)return send(res,404,{ok:false,error:'Club not found.'});db.clubSpaces??={};db.clubSpaces[club.id]??={media:[],meetings:[],updates:[]};const leaders=(db.clubLeaders||[]).filter(x=>x.clubId===club.id&&x.status!=='archived');const leaderView=leaders.map(x=>({id:x.id,role:x.role,name:x.nameSnapshot,startedAt:x.startedAt,endedAt:x.endedAt}));const membershipCount=(db.clubMemberships||[]).filter(x=>x.clubId===club.id&&x.status==='approved').length;const achievements=(db.achievements||[]).filter(x=>x.clubId===club.id&&x.status!=='archived'&&(x.visibility!=='private'||x.userId===u.id||isAdmin(u))).slice(-20).reverse();return send(res,200,{ok:true,club,space:db.clubSpaces[club.id],leaders:leaderView,membershipCount,achievements,media:db.mediaAssets.filter(x=>x.clubId===club.id&&x.status!=='archived').map(x=>({...x,url:'/media/'+x.id}))})}
  if(p==='/api/admin/clubs/space'&&req.method==='POST'){const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),club=findById(db.clubs,clean(b.clubId,100));if(!club)return send(res,404,{ok:false,error:'Club not found.'});const section=['meetings','updates'].includes(b.section)?b.section:'updates';db.clubSpaces??={};db.clubSpaces[club.id]??={media:[],meetings:[],updates:[]};const item={id:id('CLUBSP'),title:clean(b.title,160),body:clean(b.body,3000),date:clean(b.date,50),createdAt:new Date().toISOString()};db.clubSpaces[club.id][section].unshift(item);audit(db,actor,'create','club_space',item.id,{clubId:club.id,section});save(db);return send(res,201,{ok:true,item})}
  if(p==='/api/admin/clubs'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,clubs:load().clubs})}
  if(p==='/api/admin/clubs'&&req.method==='POST'){const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),name=clean(b.name,150);if(!name)return send(res,400,{ok:false,error:'Club name is required.'});const item={id:id('CLB'),name,patron:clean(b.patron,120),founder:clean(b.founder,120),foundedYear:clean(b.foundedYear,10),category:['club','society'].includes(b.category)?b.category:'club',description:clean(b.description,1200),mission:clean(b.mission,1200),meetingDay:clean(b.meetingDay,80),meetingTime:clean(b.meetingTime,80),meetingLocation:clean(b.meetingLocation,160),contact:clean(b.contact,180),logoAsset:clean(b.logoAsset,240),status:'active',createdAt:new Date().toISOString()};db.clubs.push(item);audit(db,actor,'create','club',item.id);save(db);return send(res,201,{ok:true,club:item})}
  const clubMatch=p.match(/^\/api\/admin\/clubs\/([^/]+)$/);if(clubMatch&&(req.method==='PATCH'||req.method==='DELETE')){const actor=requireAdmin(req,res);if(!actor)return;const db=load(),item=findById(db.clubs,clubMatch[1]);if(!item)return send(res,404,{ok:false,error:'Club not found.'});if(req.method==='DELETE'){item.status='archived';audit(db,actor,'archive','club',item.id);save(db);return send(res,200,{ok:true})}const b=await body(req);for(const k of ['name','patron','founder','foundedYear','status','description','logoAsset','category','mission','meetingDay','meetingTime','meetingLocation','contact'])if(b[k]!==undefined)item[k]=clean(b[k],k==='description'||k==='mission'?1200:180);audit(db,actor,'update','club',item.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,club:item})}
  if(p==='/api/admin/audit'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;const a=load().audit;return send(res,200,{ok:true,audit:a.slice(-100).reverse()})}

  // V55 Connect directory — authenticated school accounts, safe public fields only.
  if(p==='/api/connect/students'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load();
    const students=db.users.filter(x=>x.status!=='archived'&&x.id!==u.id).map(x=>{const person=x.personId?db.people.find(p=>p.id===x.personId):db.people.find(p=>p.studentId===x.id);return {id:x.id,name:x.name,role:x.role||'student',department:x.department||person?.department||'',className:x.className||person?.className||'',house:x.house||person?.house||'',photoAsset:person?.photoAsset||''};});
    return send(res,200,{ok:true,students});
  }

  // V52 completion — suggestion box, friend requests and private chat.
  if(p==='/api/suggestions'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();return send(res,200,{ok:true,suggestions:db.suggestions.filter(x=>x.status!=='archived').sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))})
  }
  if(p==='/api/suggestions'&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const b=await body(req),db=load(),title=clean(b.title,120),bodyText=clean(b.body,2000);if(!title||!bodyText)return send(res,400,{ok:false,error:'Title and suggestion are required.'});const item={id:id('SUG'),title,body:bodyText,authorId:u.id,authorName:u.name,status:'published',reply:'',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};db.suggestions.unshift(item);audit(db,u,'create','suggestion',item.id);save(db);return send(res,201,{ok:true,suggestion:item})
  }
  const sugMatch=p.match(/^\/api\/admin\/suggestions\/([^/]+)$/);if(sugMatch&&req.method==='PATCH'){const actor=requireAdmin(req,res);if(!actor)return;const db=load(),item=db.suggestions.find(x=>x.id===sugMatch[1]);if(!item)return send(res,404,{ok:false,error:'Suggestion not found.'});const b=await body(req);if(b.reply!==undefined)item.reply=clean(b.reply,2000);if(b.status!==undefined&&['published','archived'].includes(b.status))item.status=b.status;item.updatedAt=new Date().toISOString();audit(db,actor,'update','suggestion',item.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,suggestion:item})}

  function friendshipExists(db,a,b){return db.friendships.some(x=>(x.a===a&&x.b===b)||(x.a===b&&x.b===a))}
  if(p==='/api/chat/friends'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();const ids=db.friendships.filter(x=>x.a===u.id||x.b===u.id).map(x=>x.a===u.id?x.b:x.a);const friends=ids.map(fid=>db.users.find(x=>x.id===fid)).filter(Boolean).map(x=>{const person=x.personId?db.people.find(p=>p.id===x.personId):db.people.find(p=>p.studentId===x.id);return {id:x.id,name:x.name,role:x.role,department:x.department||person?.department||'',className:x.className||person?.className||'',photoAsset:person?.photoAsset||''};});const requests=db.friendRequests.filter(x=>x.to===u.id&&x.status==='pending').map(x=>({...x,fromName:db.users.find(y=>y.id===x.from)?.name||x.from}));const outgoing=db.friendRequests.filter(x=>x.from===u.id&&x.status==='pending').map(x=>x.to);return send(res,200,{ok:true,friends,requests,outgoing})
  }
  if(p==='/api/chat/requests'&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const b=await body(req),db=load(),target=clean(b.userId,100);if(!target||target===u.id)return send(res,400,{ok:false,error:'Choose another school account.'});const user=db.users.find(x=>x.id.toLowerCase()===target.toLowerCase());if(!user)return send(res,404,{ok:false,error:'School account not found.'});if(friendshipExists(db,u.id,user.id))return send(res,409,{ok:false,error:'You are already friends.'});if(db.friendRequests.some(x=>x.from===u.id&&x.to===user.id&&x.status==='pending'))return send(res,409,{ok:false,error:'Request already sent.'});const item={id:id('FR'),from:u.id,to:user.id,status:'pending',createdAt:new Date().toISOString()};db.friendRequests.push(item);save(db);return send(res,201,{ok:true,request:item})
  }
  const frMatch=p.match(/^\/api\/chat\/requests\/([^/]+)$/);if(frMatch&&req.method==='POST'){const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),r=db.friendRequests.find(x=>x.id===frMatch[1]&&x.to===u.id);if(!r)return send(res,404,{ok:false,error:'Friend request not found.'});const b=await body(req);if(b.action==='accept'){r.status='accepted';db.friendships.push({id:id('FRIEND'),a:r.from,b:r.to,createdAt:new Date().toISOString()});audit(db,u,'accept','friend_request',r.id)}else if(b.action==='reject')r.status='rejected';else return send(res,400,{ok:false,error:'Action must be accept or reject.'});save(db);return send(res,200,{ok:true,request:r})}
  const chatMatch=p.match(/^\/api\/chat\/messages\/([^/]+)$/);if(chatMatch&&(req.method==='GET'||req.method==='POST')){const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const other=chatMatch[1],db=load();if(!friendshipExists(db,u.id,other))return send(res,403,{ok:false,error:'Accept the friend request before chatting.'});if(req.method==='GET'){return send(res,200,{ok:true,messages:db.messages.filter(x=>(x.from===u.id&&x.to===other)||(x.from===other&&x.to===u.id)).slice(-200).map(x=>({...x,mine:x.from===u.id}))})}const b=await body(req),text=clean(b.body,2000);if(!text)return send(res,400,{ok:false,error:'Message is required.'});const m={id:id('MSG'),from:u.id,to:other,body:text,createdAt:new Date().toISOString()};db.messages.push(m);save(db);return send(res,201,{ok:true,message:m})}

  // V37 — Universal Search 2.0: indexed, ranked, faceted and permission-aware search.
  function searchClassAllowed(u,c,db){return isAdmin(u)||c.teacherIds?.includes(u.id)||c.formMasterId===u.id||c.captainId===u.id||u.classId===c.id||u.className===c.name}
  function searchVisible(u,row,collection,db){
    if(!row) return false;
    if(row.visibility==='private'&&row.userId!==u.id&&!isAdmin(u)) return false;
    if(row.visibility==='school' && !u && false) return false;
    if(row.classId){
      const c=db.classes.find(x=>x.id===row.classId||x.name===row.classId);
      if(c&&!searchClassAllowed(u,c,db)) return false;
    }
    if(collection==='people'){
      if(row.personType==='Student' && !isAdmin(u) && u.role!=='teacher' && u.role!=='prefect' && row.id!==u.personId && row.accountId!==u.id) return false;
    }
    if(collection==='accounts' && !isAdmin(u)) return false;
    if(collection==='pta' && !['parent','teacher','admin','super_admin'].includes(u.role)) return false;
    return true;
  }
  function scoreSearch(row,fields,q,collection){
    const ql=q.toLowerCase();let score=0;
    for(const f of fields){const v=String(row[f]??'').toLowerCase();if(!v)continue;if(v===ql)score=Math.max(score,100);else if(v.startsWith(ql))score=Math.max(score,70);else if(v.includes(ql))score=Math.max(score,45)}
    const title=String(row.title||row.name||'').toLowerCase();if(title===ql)score+=30;else if(title.startsWith(ql))score+=18;else if(title.includes(ql))score+=10;
    const weights={people:10,classes:9,resources:8,assignments:8,events:7,clubs:7,achievements:6,posts:5,heritage:5,documents:6,pta:4};return score+(weights[collection]||1);
  }
  if(p==='/api/search'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const q=clean(url.searchParams.get('q')||'',120).trim();const type=clean(url.searchParams.get('type')||'all',30).toLowerCase();
    const page=Math.max(1,parseInt(url.searchParams.get('page')||'1',10)||1),limit=Math.min(40,Math.max(5,parseInt(url.searchParams.get('limit')||'20',10)||20));
    if(!q)return send(res,200,{ok:true,query:'',page,limit,total:0,results:[],facets:{}});
    const db=load(),results=[];
    const people=db.people.filter(x=>x.status!=='archived').map(x=>({...x,title:x.name,kind:x.personType==='Student'?'Student':'Teacher',collection:'people',subtitle:x.department||x.className||''}));
    const collections=[
      ['people',people,['title','studentId','staffId','department','className','house']],
      ['classes',db.classes.filter(x=>x.status!=='archived'),['name','code','department','year']],
      ['clubs',db.clubs.filter(x=>x.status!=='archived'),['name','description','founder','patron']],
      ['resources',db.resources,['title','subject','type','description']],
      ['assignments',db.assignments,['title','subject','status','description']],
      ['events',db.events,['title','description','location','date']],
      ['achievements',db.achievements,['title','description','category']],
      ['posts',db.posts,['title','body','type']],
      ['heritage',db.heritage,['title','description','year','category']],
      ['documents',db.documents,['title','description','category','filename']],
      ['pta',db.pta.posts.filter(x=>x.status==='published'),['title','content']]
    ];
    for(const [collection,rows,fields] of collections){
      if(type!=='all'&&type!==collection)continue;
      for(const row of rows||[]){
        if(!searchVisible(u,row,collection,db))continue;
        const hay=fields.map(k=>row[k]??'').join(' ').toLowerCase();if(!hay.includes(q.toLowerCase()))continue;
        results.push({id:row.id,kind:row.kind||collection,title:row.title||row.name||row.studentId||row.staffId||'Untitled',subtitle:row.subtitle||row.subject||row.department||row.className||row.type||row.category||'',collection,url:localSearchUrl(collection,row),score:scoreSearch(row,fields,q,collection)});
      }
    }
    if(url.searchParams.get('web')==='1'){
      const web=await googleWebLookup(q);
      const fallback=web.length?web:await wikipediaLookup(q);
      for(const x of fallback)results.push({id:'WEB-'+crypto.createHash('sha1').update(x.url).digest('hex').slice(0,12),kind:web.length?'Web':'Internet',title:x.title,subtitle:x.summary,collection:'internet',url:x.url,score:web.length?35:20});
      if(!web.length)results.push({id:'WEB-GOOGLE',kind:'Web search',title:'Search the wider web with Google',subtitle:'No web-search API is configured on this installation. Open Google to continue the same query.',collection:'internet',url:'https://www.google.com/search?q='+encodeURIComponent(q),score:19});
    }
    results.sort((a,b)=>b.score-a.score||a.title.localeCompare(b.title));
    const facets={};for(const r of results)facets[r.collection]=(facets[r.collection]||0)+1;
    const total=results.length,offset=(page-1)*limit;
    db.searchHistory=db.searchHistory||[];db.searchHistory.push({id:id('SRCH'),userId:u.id,q,type,at:new Date().toISOString(),count:total});
    if(db.searchHistory.length>1000)db.searchHistory=db.searchHistory.slice(-1000);save(db);
    return send(res,200,{ok:true,query:q,page,limit,total,pages:Math.max(1,Math.ceil(total/limit)),facets,webSearched:url.searchParams.get('web')==='1',results:results.slice(offset,offset+limit).map(({score,...r})=>r)});
  }
  if(p==='/api/search/suggestions'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const q=clean(url.searchParams.get('q')||'',80).toLowerCase();const db=load();
    const history=(db.searchHistory||[]).filter(x=>x.userId===u.id&&(!q||x.q.toLowerCase().includes(q))).reverse();const seen=new Set();const suggestions=[];
    for(const h of history){if(!seen.has(h.q)){seen.add(h.q);suggestions.push({text:h.q,type:'recent'});}}
    const names=[...db.classes.map(x=>x.name),...db.clubs.map(x=>x.name),...db.academicSubjects.map(x=>x.name||x.title||''),...db.people.map(x=>x.name||'')].filter(Boolean);
    for(const n of names){if(q&& !n.toLowerCase().includes(q))continue;if(!seen.has(n.toLowerCase())){seen.add(n.toLowerCase());suggestions.push({text:n,type:'suggestion'});}if(suggestions.length>=8)break;}
    return send(res,200,{ok:true,suggestions:suggestions.slice(0,8)});
  }
  if(p==='/api/search/recent'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),seen=new Set(),recent=[];
    for(const x of (db.searchHistory||[]).filter(x=>x.userId===u.id).reverse()){if(seen.has(x.q.toLowerCase()))continue;seen.add(x.q.toLowerCase());recent.push({q:x.q,type:x.type,at:x.at,count:x.count});if(recent.length>=10)break;}
    return send(res,200,{ok:true,recent});
  }
  // V38 — Notifications 2.0: targeted delivery, scheduling, expiry, priorities and read-state controls.
  if(p==='/api/notifications/web-news'&&req.method==='GET'){const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});try{const r=await fetch('https://news.google.com/rss?hl=en-GH&gl=GH&ceid=GH:en',{headers:{'User-Agent':'St-Marys-Digital-Network/52'}});const xml=await r.text();const items=[...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0,8).map(m=>{const x=m[1],t=(x.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/)||x.match(/<title>(.*?)<\/title>/))?.[1]||'';const l=(x.match(/<link>(.*?)<\/link>/)||[])[1]||'';return {title:t,link:l}}).filter(x=>x.title);return send(res,200,{ok:true,items})}catch(e){return send(res,502,{ok:false,error:'Internet news is temporarily unavailable.'})}}
  function notificationVisible(n,u,db){
    const now=Date.now();
    if(n.status==='cancelled')return false;
    if(n.scheduledAt && new Date(n.scheduledAt).getTime()>now)return false;
    if(n.expiresAt && new Date(n.expiresAt).getTime()<=now)return false;
    const a=n.audience||{type:'user',userId:n.userId};
    if(a.type==='all')return true;
    if(a.type==='user')return a.userId===u.id;
    if(a.type==='role')return a.role===u.role;
    if(a.type==='department')return a.department===u.department;
    if(a.type==='class'){
      const c=db.classes.find(x=>x.id===a.classId);
      return !!c && (isAdmin(u)||c.teacherIds?.includes(u.id)||c.formMasterId===u.id||c.captainId===u.id||u.classId===c.id||u.className===c.name);
    }
    return n.userId===u.id||n.userId==='all';
  }
  if(p==='/api/notifications'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load(); const ns=db.notifications.filter(n=>notificationVisible(n,u,db)).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
    const unread=ns.filter(n=>!n.readBy?.includes(u.id) && !n.read).length;
    return send(res,200,{notifications:ns,unreadCount:unread});
  }
  if(p==='/api/notifications/unread-count'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();
    const count=db.notifications.filter(n=>notificationVisible(n,u,db)&&!(n.readBy||[]).includes(u.id)&&!n.read).length;return send(res,200,{count});
  }
  if(p==='/api/notifications/read-all'&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();
    for(const n of db.notifications)if(notificationVisible(n,u,db)){n.readBy??=[];if(!n.readBy.includes(u.id))n.readBy.push(u.id);}
    audit(db,u,'read_all','notifications','ALL');save(db);return send(res,200,{ok:true});
  }
  if(p==='/api/admin/notifications'&&req.method==='GET'){
    const actor=requireAdmin(req,res);if(!actor)return;const db=load();return send(res,200,{ok:true,notifications:db.notifications.slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))});
  }
  if(p==='/api/notifications/broadcast'&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const b=await body(req),db=load(),a=b.audience||{type:'all'};const allowed=['all','user','role','department','class'];
    if(!allowed.includes(a.type))return send(res,400,{ok:false,error:'Invalid audience type.'});
    if(a.type!=='all'&&!a.userId&&!a.role&&!a.department&&!a.classId)return send(res,400,{ok:false,error:'Audience target is required.'});
    if(!isAdmin(u)&&a.type!=='class')return send(res,403,{ok:false,error:'Teachers may only broadcast to an authorised class.'});
    if(!isAdmin(u)&&a.type==='class'){const c=db.classes.find(x=>x.id===a.classId);if(!c||!(c.teacherIds?.includes(u.id)||c.formMasterId===u.id||c.captainId===u.id))return send(res,403,{ok:false,error:'You are not authorised for this class.'});}
    const title=clean(b.title,160),content=clean(b.body,1500);if(!title||!content)return send(res,400,{ok:false,error:'Title and body are required.'});
    const item={id:id('NTF'),userId:a.type==='user'?clean(a.userId,100):'all',audience:a,title,body:content,type:clean(b.type,40)||'announcement',priority:['low','normal','high','urgent'].includes(b.priority)?b.priority:'normal',scheduledAt:b.scheduledAt?clean(b.scheduledAt,40):'',expiresAt:b.expiresAt?clean(b.expiresAt,40):'',status:'scheduled',read:false,readBy:[],createdAt:new Date().toISOString(),senderId:u.id};
    if(item.scheduledAt&&!Number.isNaN(new Date(item.scheduledAt).getTime())&&new Date(item.scheduledAt).getTime()<=Date.now())item.status='published';
    db.notifications.push(item);audit(db,u,'broadcast','notification',item.id,{audience:a,priority:item.priority,scheduledAt:item.scheduledAt,expiresAt:item.expiresAt});save(db);return send(res,201,{ok:true,notification:item});
  }
  const notifRead=p.match(/^\/api\/notifications\/([^/]+)\/read$/);
  if(notifRead&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load(),n=db.notifications.find(x=>x.id===notifRead[1]&&notificationVisible(x,u,db));
    if(!n)return send(res,404,{error:'Notification not found.'}); n.read=true;n.readBy??=[];if(!n.readBy.includes(u.id))n.readBy.push(u.id);n.readAt=new Date().toISOString();save(db);return send(res,200,{notification:n});
  }
  if(p==='/api/notifications'&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    if(!DEV_OPEN_ACCESS&&!['teacher','admin','prefect','super_admin'].includes(u.role))return send(res,403,{ok:false,error:'Permission denied.'});
    const b=await body(req),db=load(),n={id:id('NTF'),userId:clean(b.userId,100)||'all',title:clean(b.title,160),body:clean(b.body,1000),type:clean(b.type,40)||'announcement',read:false,createdAt:new Date().toISOString(),senderId:u.id};
    if(!n.title)return send(res,400,{error:'Title is required.'});db.notifications.push(n);audit(db,u,'create','notification',n.id);save(db);return send(res,201,{notification:n});
  }

  // V42 Clubs, Houses & Activities 2.0
  if(p==='/api/activities'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load();return send(res,200,{ok:true,activities:db.activities.filter(a=>a.status!=='archived')});
  }
  if(p==='/api/admin/activities'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,activities:load().activities});}
  if(p==='/api/admin/activities'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();
    const name=clean(b.name,160);if(!name)return send(res,400,{ok:false,error:'Activity name is required.'});
    const item={id:id('ACT'),name,category:['sport','club','society','competition','service','other'].includes(b.category)?b.category:'other',description:clean(b.description,1200),season:clean(b.season,80),leaderIds:Array.isArray(b.leaderIds)?b.leaderIds.map(x=>clean(x,100)).slice(0,20):[],clubId:clean(b.clubId,100),houseId:clean(b.houseId,100),status:'active',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
    db.activities.push(item);audit(db,actor,'create','activity',item.id);save(db);return send(res,201,{ok:true,activity:item});
  }
  const actMatch=p.match(/^\/api\/admin\/activities\/([^/]+)$/);
  if(actMatch&&(req.method==='PATCH'||req.method==='DELETE')){const actor=requireAdmin(req,res);if(!actor)return;const db=load(),item=db.activities.find(x=>x.id===actMatch[1]);if(!item)return send(res,404,{ok:false,error:'Activity not found.'});if(req.method==='DELETE'){item.status='archived';item.updatedAt=new Date().toISOString();audit(db,actor,'archive','activity',item.id);save(db);return send(res,200,{ok:true});}const b=await body(req);for(const k of ['name','description','season','clubId','houseId'])if(b[k]!==undefined)item[k]=clean(b[k],k==='description'?1200:160);if(b.category!==undefined&&['sport','club','society','competition','service','other'].includes(b.category))item.category=b.category;if(Array.isArray(b.leaderIds))item.leaderIds=b.leaderIds.map(x=>clean(x,100)).slice(0,20);if(b.status!==undefined)item.status=['active','archived'].includes(b.status)?b.status:item.status;item.updatedAt=new Date().toISOString();audit(db,actor,'update','activity',item.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,activity:item});}

  if(p==='/api/admin/clubs/advanced'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;const db=load();return send(res,200,{ok:true,clubs:db.clubs,leaders:db.clubLeaders,memberships:db.clubMemberships});}
  if(p==='/api/admin/clubs/advanced'&&req.method==='POST'){const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();const clubId=clean(b.clubId,100);const club=db.clubs.find(x=>x.id===clubId);if(!club)return send(res,404,{ok:false,error:'Club not found.'});const leaderId=clean(b.userId,100);const user=db.users.find(x=>x.id===leaderId);if(!user)return send(res,404,{ok:false,error:'Account not found.'});const role=['founder','leader','executive','patron'].includes(b.role)?b.role:'leader';if(role==='founder'&&db.clubLeaders.some(x=>x.clubId===clubId&&x.role==='founder'))return send(res,409,{ok:false,error:'Founder record already exists; it cannot be overwritten.'});const item={id:id('CLBLED'),clubId,userId:leaderId,role,nameSnapshot:user.name,startedAt:clean(b.startedAt,40)||new Date().toISOString(),endedAt:clean(b.endedAt,40)||'',status:'active',createdAt:new Date().toISOString()};db.clubLeaders.push(item);if(role==='founder'&&!club.founder)club.founder=user.name;audit(db,actor,'assign','clubLeader',item.id,{clubId,role,userId:leaderId});save(db);return send(res,201,{ok:true,leader:item});}

  // V17 Clubs
  if(p==='/api/clubs'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    return send(res,200,{clubs:load().clubs.filter(x=>x.status!=='archived')});
  }
  const clubMembership=p.match(/^\/api\/clubs\/([^/]+)\/memberships$/);
  if(clubMembership&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load();if(!db.clubs.some(c=>c.id===clubMembership[1]&&c.status!=='archived'))return send(res,404,{error:'Club not found.'});
    if(db.clubMemberships.some(m=>m.clubId===clubMembership[1]&&m.userId===u.id&&m.status!=='rejected'))return send(res,409,{error:'Membership already requested.'});
    const m={id:id('MEM'),clubId:clubMembership[1],userId:u.id,status:'pending',createdAt:new Date().toISOString()};db.clubMemberships.push(m);audit(db,u,'request','clubMembership',m.id,{clubId:m.clubId});save(db);return send(res,201,{membership:m});
  }
  const clubMembers=p.match(/^\/api\/clubs\/([^/]+)\/memberships$/);
  if(clubMembers&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    if(!DEV_OPEN_ACCESS&&!['admin','teacher','prefect','super_admin'].includes(u.role))return send(res,403,{ok:false,error:'Permission denied.'});
    return send(res,200,{memberships:load().clubMemberships.filter(m=>m.clubId===clubMembers[1])});
  }
  const decision=p.match(/^\/api\/clubs\/([^/]+)\/memberships\/([^/]+)\/decision$/);
  if(decision&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    if(!DEV_OPEN_ACCESS&&!['admin','teacher','prefect','super_admin'].includes(u.role))return send(res,403,{ok:false,error:'Permission denied.'});
    const b=await body(req),db=load(),m=db.clubMemberships.find(x=>x.id===decision[2]&&x.clubId===decision[1]);
    if(!m)return send(res,404,{error:'Membership request not found.'});
    m.status=b.decision==='approved'?'approved':'rejected';m.decidedAt=new Date().toISOString();m.decidedBy=u.id;audit(db,u,'decision','clubMembership',m.id,{status:m.status});save(db);return send(res,200,{membership:m});
  }

  // V17 Houses & Achievements
  if(p==='/api/houses'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    return send(res,200,{ok:true,houses:load().houses.filter(x=>x.status!=='archived')});
  }
  if(p==='/api/achievements'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const rows=load().achievements.filter(a=>a.visibility!=='private'||a.userId===u.id||isAdmin(u));
    return send(res,200,{achievements:rows});
  }
  if(p==='/api/achievements'&&req.method==='POST'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    if(!DEV_OPEN_ACCESS&&!['teacher','admin','prefect','super_admin'].includes(u.role))return send(res,403,{ok:false,error:'Permission denied.'});
    const b=await body(req),db=load(),a={id:id('ACH'),title:clean(b.title,180),category:clean(b.category,80)||'General',userId:clean(b.userId,100),clubId:clean(b.clubId,100),houseId:clean(b.houseId,100),description:clean(b.description,1000),visibility:['public','school','private'].includes(b.visibility)?b.visibility:'school',createdAt:new Date().toISOString(),recordedBy:u.id};
    if(!a.title)return send(res,400,{error:'Title is required.'});db.achievements.push(a);audit(db,u,'create','achievement',a.id);save(db);return send(res,201,{achievement:a});
  }

  // V17/V18 administrator management for houses and achievements
  if(p==='/api/admin/houses'&&req.method==='GET'){
    const actor=requireAdmin(req,res);if(!actor)return;const db=load();return send(res,200,{ok:true,houses:db.houses,members:db.houseMembers});
  }
  if(p==='/api/admin/houses'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();
    const name=clean(b.name,100);if(!name)return send(res,400,{ok:false,error:'House name is required.'});
    const item={id:id('HSE'),name,status:'active',createdAt:new Date().toISOString()};db.houses.push(item);audit(db,actor,'create','house',item.id);save(db);return send(res,201,{ok:true,house:item});
  }
  if(p==='/api/admin/houses/bulk'&&req.method==='PATCH'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();
    if(!Array.isArray(b.houses))return send(res,400,{ok:false,error:'houses must be an array.'});
    for(const h of b.houses.slice(0,8)){const hid=clean(h.id,100),name=clean(h.name,100);if(!hid||!name)continue;let item=db.houses.find(x=>x.id===hid);if(!item){item={id:hid,name,status:'active',createdAt:new Date().toISOString()};db.houses.push(item)}item.name=name;item.status='active';item.placeholder=false;for(const k of ['description','motto','captain','viceCaptain','colour','history'])if(h[k]!==undefined)item[k]=clean(h[k],2000);if(Array.isArray(h.achievements))item.achievements=h.achievements.map(x=>clean(x,300)).slice(0,30);item.updatedAt=new Date().toISOString();audit(db,actor,'update','house',item.id,{fields:Object.keys(h),bulk:true});}
    save(db);return send(res,200,{ok:true,houses:db.houses.filter(x=>x.status!=='archived')});
  }
  const houseMatch=p.match(/^\/api\/admin\/houses\/([^/]+)$/);
  if(houseMatch&&(req.method==='PATCH'||req.method==='DELETE')){
    const actor=requireAdmin(req,res);if(!actor)return;const db=load(),item=findById(db.houses,houseMatch[1]);if(!item)return send(res,404,{ok:false,error:'House not found.'});
    if(req.method==='DELETE'){item.status='archived';audit(db,actor,'archive','house',item.id);save(db);return send(res,200,{ok:true});}
    const b=await body(req);for(const k of ['name','status','description','motto','captain','viceCaptain','colour','history'])if(b[k]!==undefined)item[k]=clean(b[k],k==='history'||k==='description'?2000:200);if(Array.isArray(b.achievements))item.achievements=b.achievements.map(x=>clean(x,300)).slice(0,30);audit(db,actor,'update','house',item.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,house:item});
  }
  if(p==='/api/admin/achievements'&&req.method==='GET'){
    const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,achievements:load().achievements});
  }
  if(p==='/api/admin/achievements'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();
    const a={id:id('ACH'),title:clean(b.title,180),category:clean(b.category,80)||'General',userId:clean(b.userId,100),clubId:clean(b.clubId,100),houseId:clean(b.houseId,100),description:clean(b.description,1000),visibility:['public','school','private'].includes(b.visibility)?b.visibility:'school',createdAt:new Date().toISOString(),recordedBy:actor.id};
    if(!a.title)return send(res,400,{ok:false,error:'Title is required.'});db.achievements.push(a);audit(db,actor,'create','achievement',a.id);save(db);return send(res,201,{ok:true,achievement:a});
  }
  const achievementMatch=p.match(/^\/api\/admin\/achievements\/([^/]+)$/);
  if(achievementMatch&&(req.method==='PATCH'||req.method==='DELETE')){
    const actor=requireAdmin(req,res);if(!actor)return;const db=load(),a=findById(db.achievements,achievementMatch[1]);if(!a)return send(res,404,{ok:false,error:'Achievement not found.'});
    if(req.method==='DELETE'){a.status='archived';audit(db,actor,'archive','achievement',a.id);save(db);return send(res,200,{ok:true});}
    const b=await body(req);for(const k of ['title','category','userId','clubId','houseId','description','visibility','status'])if(b[k]!==undefined)a[k]=clean(b[k],1000);audit(db,actor,'update','achievement',a.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,achievement:a});
  }

  // V39 Digital Heritage — structured timeline, people and milestones with verification state.
  if(p==='/api/heritage/timeline'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load();const rows=db.heritageTimeline.filter(x=>x.status!=='archived' && (x.visibility!=='private'||isAdmin(u)) && (x.verificationStatus==='verified'||isAdmin(u)||x.visibility!=='public'));
    return send(res,200,{ok:true,timeline:rows.sort((a,b)=>String(a.sortDate||a.year||'').localeCompare(String(b.sortDate||b.year||'')))});
  }
  if(p==='/api/heritage/people'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load();const rows=db.heritagePeople.filter(x=>x.status!=='archived'&&(x.visibility!=='private'||isAdmin(u))&&(x.verificationStatus==='verified'||isAdmin(u)||x.visibility!=='public'));
    return send(res,200,{ok:true,people:rows});
  }
  if(p==='/api/heritage/milestones'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load();const rows=db.heritageMilestones.filter(x=>x.status!=='archived'&&(x.visibility!=='private'||isAdmin(u))&&(x.verificationStatus==='verified'||isAdmin(u)||x.visibility!=='public'));
    return send(res,200,{ok:true,milestones:rows});
  }
  function heritageAdminCollection(db, actor, collection, type, b){
    const item={id:id(type),title:clean(b.title,180),year:clean(b.year,30),era:clean(b.era,100),sortDate:clean(b.sortDate,30),description:clean(b.description,1800),sourceNote:clean(b.sourceNote,800),sourceUrl:clean(b.sourceUrl,500),verificationStatus:['verified','pending','rejected'].includes(b.verificationStatus)?b.verificationStatus:'pending',visibility:['public','school','private'].includes(b.visibility)?b.visibility:'public',status:'active',createdAt:new Date().toISOString(),recordedBy:actor.id};
    if(type==='HPEO') item.name=clean(b.name,140),item.role=clean(b.role,140),item.photo=clean(b.photo,500);
    if(!item.title && type!=='HPEO') throw new Error('Title is required.');
    if(type==='HPEO'&&!item.name) throw new Error('Name is required.');
    db[collection].push(item);audit(db,actor,'create','heritage_'+collection,item.id,{verificationStatus:item.verificationStatus});save(db);return item;
  }
  if(p==='/api/admin/heritage/timeline'&&req.method==='POST'){const actor=requireAdmin(req,res);if(!actor)return;try{const item=heritageAdminCollection(load(),actor,'heritageTimeline','HTL',await body(req));return send(res,201,{ok:true,timeline:item});}catch(e){return send(res,400,{ok:false,error:e.message})}}
  if(p==='/api/admin/heritage/people'&&req.method==='POST'){const actor=requireAdmin(req,res);if(!actor)return;try{const item=heritageAdminCollection(load(),actor,'heritagePeople','HPEO',await body(req));return send(res,201,{ok:true,person:item});}catch(e){return send(res,400,{ok:false,error:e.message})}}
  if(p==='/api/admin/heritage/milestones'&&req.method==='POST'){const actor=requireAdmin(req,res);if(!actor)return;try{const item=heritageAdminCollection(load(),actor,'heritageMilestones','HMS',await body(req));return send(res,201,{ok:true,milestone:item});}catch(e){return send(res,400,{ok:false,error:e.message})}}
  if(p==='/api/admin/heritage/verify'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),collections=['heritage','heritageTimeline','heritagePeople','heritageMilestones'];const target=clean(b.id,100);let found=null;
    for(const c of collections){const x=db[c].find(r=>r.id===target);if(x){found=x;found.verificationStatus=['verified','pending','rejected'].includes(b.verificationStatus)?b.verificationStatus:'pending';found.verifiedAt=found.verificationStatus==='verified'?new Date().toISOString():'';found.verifiedBy=actor.id;audit(db,actor,'verify','heritage_record',target,{collection:c,status:found.verificationStatus});save(db);return send(res,200,{ok:true,record:found,collection:c})}}
    return send(res,404,{ok:false,error:'Heritage record not found.'});
  }
  if(p==='/api/admin/heritage/export'&&req.method==='GET'){
    const actor=requireAdmin(req,res);if(!actor)return;const db=load();return send(res,200,{ok:true,exportedAt:new Date().toISOString(),heritage:db.heritage,timeline:db.heritageTimeline,people:db.heritagePeople,milestones:db.heritageMilestones});
  }
  // V18 Digital Heritage & Alumni
  if(p==='/api/heritage'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const rows=load().heritage.filter(x=>x.status!=='archived' && (x.visibility!=='private'||x.userId===u.id||isAdmin(u)));
    return send(res,200,{heritage:rows});
  }
  if(p==='/api/admin/heritage'&&req.method==='GET'){
    const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,heritage:load().heritage});
  }
  if(p==='/api/admin/heritage'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();
    const item={id:id('HER'),title:clean(b.title,180),era:clean(b.era,100),year:clean(b.year,30),description:clean(b.description,1800),category:clean(b.category,80)||'History',mediaAsset:clean(b.mediaAsset,240),visibility:['public','school','private'].includes(b.visibility)?b.visibility:'public',sourceNote:clean(b.sourceNote,800),mediaType:clean(b.mediaType,40),status:'active',createdAt:new Date().toISOString(),recordedBy:actor.id};
    if(!item.title)return send(res,400,{ok:false,error:'Heritage title is required.'});db.heritage.push(item);audit(db,actor,'create','heritage',item.id);save(db);return send(res,201,{ok:true,heritage:item});
  }
  const heritageMatch=p.match(/^\/api\/admin\/heritage\/([^/]+)$/);
  if(heritageMatch&&(req.method==='PATCH'||req.method==='DELETE')){
    const actor=requireAdmin(req,res);if(!actor)return;const db=load(),item=findById(db.heritage,heritageMatch[1]);if(!item)return send(res,404,{ok:false,error:'Heritage record not found.'});
    if(req.method==='DELETE'){item.status='archived';audit(db,actor,'archive','heritage',item.id);save(db);return send(res,200,{ok:true});}
    const b=await body(req);for(const k of ['title','era','year','description','category','mediaAsset','mediaType','visibility','sourceNote','status'])if(b[k]!==undefined)item[k]=clean(b[k],1800);audit(db,actor,'update','heritage',item.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,heritage:item});
  }
  if(p==='/api/alumni'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load();const alumni=db.people.filter(x=>x.personType==='Alumni'&&x.status!=='archived').map(x=>({id:x.id,name:x.name,graduationYear:x.graduationYear||'',department:x.department||'',biography:x.biography||'',notes:x.notes||'',photoAsset:x.photoAsset||'',publicProfile:x.publicProfile!==false})).filter(x=>x.publicProfile||isAdmin(u));
    return send(res,200,{alumni});
  }
  const alumniMatch=p.match(/^\/api\/admin\/alumni\/([^/]+)$/);if(alumniMatch&&req.method==='PATCH'){const actor=requireAdmin(req,res);if(!actor)return;const db=load(),item=db.people.find(x=>x.id===alumniMatch[1]&&x.personType==='Alumni');if(!item)return send(res,404,{ok:false,error:'Alumni record not found.'});const b=await body(req);for(const k of ['name','graduationYear','department','biography','notes','photoAsset','publicProfile'])if(b[k]!==undefined)item[k]=k==='publicProfile'?!!b[k]:clean(b[k],k==='notes'||k==='biography'?3000:500);audit(db,actor,'update','alumni',item.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,alumni:item})}
  if(p==='/api/admin/alumni'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();const name=clean(b.name,120);if(!name)return send(res,400,{ok:false,error:'Alumni name is required.'});
    const item={id:id('PER'),personType:'Alumni',name,graduationYear:clean(b.graduationYear,10),department:clean(b.department,100),biography:clean(b.biography,3000),notes:clean(b.notes,3000),photoAsset:clean(b.photoAsset,500),publicProfile:b.publicProfile!==false,status:'active',createdAt:new Date().toISOString()};db.people.push(item);audit(db,actor,'create','alumni',item.id);save(db);return send(res,201,{ok:true,alumni:item});
  }

  // V19 Media & Document Infrastructure
  if(p==='/api/media'&&req.method==='GET'){
   const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const db=load();const category=String(url.searchParams.get('category')||'').trim().toLowerCase(),kind=String(url.searchParams.get('kind')||'').trim().toLowerCase();const rows=db.mediaAssets.filter(x=>x.status!=='archived'&&(x.visibility!=='private'||x.ownerId===u.id||isAdmin(u))&&(!category||String(x.category||'').toLowerCase()===category)&&(!kind||(kind==='images'?String(x.mimeType||'').startsWith('image/'):kind==='videos'?String(x.mimeType||'').startsWith('video/'):true))).map(x=>({...x,url:'/media/'+x.id}));return send(res,200,{ok:true,media:rows});
  }
  if(p==='/api/admin/media'&&req.method==='GET'){
   const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{media:load().mediaAssets.filter(x=>x.status!=='archived').map(x=>({...x,url:'/media/'+x.id}))});
  }
  if(p==='/api/admin/media'&&req.method==='POST'){
   const actor=requireAdmin(req,res);if(!actor)return;const b=await mediaBody(req);const mime=clean(b.mimeType,80).toLowerCase(),ext=allowedUploads[mime],name=clean(b.fileName,180);if(!ext||!name||typeof b.data!=='string')return send(res,400,{ok:false,error:'Supported uploads: JPG, PNG, WEBP, MP4, WEBM or PDF.'});let raw=b.data.replace(/^data:[^;]+;base64,/,'');let buf;try{buf=Buffer.from(raw,'base64')}catch(e){return send(res,400,{ok:false,error:'Invalid file data.'})}if(!buf.length||buf.length>12*1024*1024)return send(res,413,{ok:false,error:'Maximum upload size is 12 MB.'});const db=load(),item={id:id('MED'),fileName:name,mimeType:mime,size:buf.length,title:clean(b.title,180)||name,description:clean(b.description,800),category:clean(b.category,80)||'General',clubId:clean(b.clubId,100),visibility:['public','school','private'].includes(b.visibility)?b.visibility:'school',ownerId:actor.id,status:'active',createdAt:new Date().toISOString()};const out=path.join(MEDIA_ROOT,item.id+ext);fs.writeFileSync(out,buf);item.storageName=path.basename(out);db.mediaAssets.push(item);audit(db,actor,'upload','media',item.id,{fileName:name,mimeType:mime,size:buf.length});save(db);return send(res,201,{ok:true,media:{...item,url:'/media/'+item.id}});
  }
  const mediaMatch=p.match(/^\/api\/admin\/media\/([^/]+)$/);if(mediaMatch&&(req.method==='PATCH'||req.method==='DELETE')){const actor=requireAdmin(req,res);if(!actor)return;const db=load(),item=findById(db.mediaAssets,mediaMatch[1]);if(!item)return send(res,404,{ok:false,error:'Media asset not found.'});if(req.method==='DELETE'){item.status='archived';audit(db,actor,'archive','media',item.id);save(db);return send(res,200,{ok:true})}const b=await body(req);for(const k of ['title','description','category','visibility','status'])if(b[k]!==undefined)item[k]=clean(b[k],1000);audit(db,actor,'update','media',item.id,{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,media:{...item,url:'/media/'+item.id}})}
  if(p.startsWith('/media/')&&req.method==='GET'){const mid=p.slice(7);if(!safeFileId(mid))return send(res,400,{error:'Bad media id'});const db=load(),item=findById(db.mediaAssets,mid),u=sessionUser(req);const allowed=!!item&&item.status!=='archived'&&(item.visibility==='public'||!!u&&(item.visibility==='school'||item.ownerId===u.id||isAdmin(u)));if(!allowed)return send(res,404,{error:'Media not found'});const fp=path.join(MEDIA_ROOT,item.storageName||'');if(!fs.existsSync(fp)||!fs.statSync(fp).isFile())return send(res,404,{error:'Stored media not found'});const cache=item.visibility==='public'?'public, max-age=3600':'private, no-store';res.writeHead(200,{'Content-Type':item.mimeType,'Cache-Control':cache,'Content-Length':item.size});return fs.createReadStream(fp).pipe(res)}
  if(p==='/api/admin/documents'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{documents:load().documents.filter(x=>x.status!=='archived').map(x=>({...x,url:'/document/'+x.id}))})}
  if(p==='/api/admin/documents'&&req.method==='POST'){const actor=requireAdmin(req,res);if(!actor)return;const b=await mediaBody(req);if(String(b.mimeType||'').toLowerCase()!=='application/pdf')return send(res,400,{ok:false,error:'Documents are PDF-only in this development build.'});let raw=String(b.data||'').replace(/^data:[^;]+;base64,/,'');let buf;try{buf=Buffer.from(raw,'base64')}catch(e){return send(res,400,{ok:false,error:'Invalid document data.'})}if(!buf.length||buf.length>12*1024*1024)return send(res,413,{ok:false,error:'Maximum document size is 12 MB.'});const db=load(),item={id:id('DOC'),title:clean(b.title,180),description:clean(b.description,800),category:clean(b.category,80)||'General',visibility:['public','school','private'].includes(b.visibility)?b.visibility:'school',mimeType:'application/pdf',size:buf.length,fileName:clean(b.fileName,180)||'document.pdf',status:'active',ownerId:actor.id,createdAt:new Date().toISOString()};if(!item.title)return send(res,400,{ok:false,error:'Document title is required.'});const out=path.join(MEDIA_ROOT,item.id+'.pdf');fs.writeFileSync(out,buf);item.storageName=path.basename(out);db.documents.push(item);audit(db,actor,'upload','document',item.id,{size:buf.length});save(db);return send(res,201,{ok:true,document:{...item,url:'/document/'+item.id}})}
  const docMatch=p.match(/^\/api\/admin\/documents\/([^/]+)$/);if(docMatch&&req.method==='DELETE'){const actor=requireAdmin(req,res);if(!actor)return;const db=load(),item=findById(db.documents,docMatch[1]);if(!item)return send(res,404,{ok:false,error:'Document not found.'});item.status='archived';audit(db,actor,'archive','document',item.id);save(db);return send(res,200,{ok:true})}
  if(p.startsWith('/document/')&&req.method==='GET'){const did=p.slice(10);if(!safeFileId(did))return send(res,400,{error:'Bad document id'});const db=load(),item=findById(db.documents,did),u=sessionUser(req);if(!item||item.status==='archived'||!u||(item.visibility==='private'&&item.ownerId!==u.id&&!isAdmin(u)))return send(res,404,{error:'Document not found'});const fp=path.join(MEDIA_ROOT,item.storageName||'');if(!fs.existsSync(fp))return send(res,404,{error:'Stored document not found'});res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':`inline; filename="${item.fileName.replace(/"/g,'')}"`,'Content-Length':item.size});return fs.createReadStream(fp).pipe(res)}
  // V20 IT, Security, Backups, Academic-Year & Handover
  if(p==='/api/admin/system'&&req.method==='GET'){
    const actor=requireAdmin(req,res);if(!actor)return;const db=load();
    return send(res,200,{ok:true,system:{academicYear:db.meta.academicYear,settings:db.meta.settings,rolloverHistory:db.meta.rolloverHistory,backups:db.meta.backups,handover:db.meta.handover,counts:{users:db.users.length,people:db.people.length,classes:db.classes.length,clubs:db.clubs.length,media:db.mediaAssets.length,documents:db.documents.length,heritage:db.heritage.length,alumni:db.people.filter(x=>x.personType==='Alumni').length}}});
  }
  if(p==='/api/admin/branding'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;
    const b=await mediaBody(req,12*1024*1024),mime=clean(b.mimeType,80).toLowerCase(),ext=allowedUploads[mime];
    if(!['image/jpeg','image/png','image/webp'].includes(mime)||!ext||typeof b.data!=='string')return send(res,400,{ok:false,error:'Branding image must be JPG, PNG or WEBP.'});
    let raw=b.data.replace(/^data:[^;]+;base64,/,'');let buf;try{buf=Buffer.from(raw,'base64')}catch(e){return send(res,400,{ok:false,error:'Invalid image data.'})}
    if(!buf.length||buf.length>8*1024*1024)return send(res,413,{ok:false,error:'Branding image must be 8 MB or smaller.'});
    const db=load(),asset={id:id('BRD'),fileName:clean(b.fileName,120)||('hero'+ext),mimeType:mime,size:buf.length,title:'Website hero image',category:'Branding',visibility:'public',ownerId:actor.id,status:'active',createdAt:new Date().toISOString()};
    const out=path.join(MEDIA_ROOT,asset.id+ext);fs.writeFileSync(out,buf);asset.storageName=path.basename(out);db.mediaAssets.push(asset);db.meta.settings.heroImage='/media/'+asset.id;db.meta.settings.brandingUpdatedAt=new Date().toISOString();
    audit(db,actor,'update','branding','SYSTEM',{heroImage:asset.id});save(db);return send(res,201,{ok:true,heroImage:db.meta.settings.heroImage,asset});
  }
  if(p==='/api/admin/system/settings'&&req.method==='PATCH'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();
    const allowed=['siteTitle','siteSubtitle','heroImage','faviconImage','maintenanceMode'];
    for(const k of allowed)if(b[k]!==undefined)db.meta.settings[k]=clean(b[k],1000);
    audit(db,actor,'update','system_settings','SYSTEM',{fields:Object.keys(b)});save(db);return send(res,200,{ok:true,settings:db.meta.settings});
  }
  if(p==='/api/admin/academic-year'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),next=clean(b.nextAcademicYear,30);
    if(!next)return send(res,400,{ok:false,error:'Next academic year is required.'});
    const previous=db.meta.academicYear;
    db.meta.rolloverHistory.push({id:id('ROL'),from:previous,to:next,at:new Date().toISOString(),actorId:actor.id,note:clean(b.note,500)});
    db.meta.academicYear=next;
    audit(db,actor,'academic_year_rollover','system',next,{from:previous,to:next});save(db);
    return send(res,200,{ok:true,academicYear:next,previousAcademicYear:previous});
  }
  if(p==='/api/admin/backup'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const db=load();
    const backup={id:id('BKP'),at:new Date().toISOString(),actorId:actor.id,kind:'logical-json',recordCounts:{users:db.users.length,people:db.people.length,classes:db.classes.length,clubs:db.clubs.length,media:db.mediaAssets.length,documents:db.documents.length,heritage:db.heritage.length,alumni:db.people.filter(x=>x.personType==='Alumni').length}};
    db.meta.backups.push(backup);audit(db,actor,'create','backup',backup.id,backup.recordCounts);save(db);return send(res,201,{ok:true,backup});
  }
  if(p==='/api/admin/handover'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load();
    const recipient=clean(b.recipientAccountId,100);if(!recipient)return send(res,400,{ok:false,error:'Recipient account ID is required.'});
    const target=db.users.find(x=>x.id===recipient);if(!target)return send(res,404,{ok:false,error:'Recipient account not found.'});
    const record={id:id('HND'),at:new Date().toISOString(),fromAdminId:actor.id,toAccountId:target.id,status:'prepared',note:clean(b.note,800)};
    db.meta.handover.push(record);audit(db,actor,'prepare','handover',record.id,{toAccountId:target.id});save(db);return send(res,201,{ok:true,handover:record});
  }
  if(p==='/api/admin/security'&&req.method==='GET'){
    const actor=requireAdmin(req,res);if(!actor)return;const db=load();
    const disabled=db.users.filter(x=>x.status==='disabled').length,admins=db.users.filter(x=>(x.role==='admin'||x.role==='super_admin')&&x.status==='active').length;
    return send(res,200,{ok:true,security:{activeAdmins:admins,disabledAccounts:disabled,auditEntries:db.audit.length,sessionTimeoutHours:8,notes:['Production should add HTTPS, CSRF protection, rate limiting, stronger session storage and encrypted off-site backups.']}});
  }
  
  // V24 SAT routes repaired for the native Node.js backend.
  // SAT content remains server-authorised; changing the code invalidates prior grants.
  if(p==='/api/sat/access'&&req.method==='GET'){
    const user=sessionUser(req); if(!user)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load(),sat=db.sat||{codeVersion:0,grants:{}};
    if(DEV_OPEN_ACCESS)return send(res,200,{ok:true,authorized:true,openDevelopmentMode:true,codeVersion:sat.codeVersion||0});
    if(user.role==='super_admin'&&user.id.toLowerCase()===MASTER_ID.toLowerCase())return send(res,200,{ok:true,authorized:true,masterAccess:true,codeVersion:sat.codeVersion||0});
    const grant=(sat.grants||{})[user.id];
    return send(res,200,{ok:true,authorized:!!(grant&&grant.codeVersion===(sat.codeVersion||0)),codeVersion:sat.codeVersion||0});
  }
  if(p==='/api/sat/unlock'&&req.method==='POST'){
    const user=sessionUser(req); if(!user)return send(res,401,{ok:false,error:'Authentication required.'});
    const b=await body(req),code=String(b.code||'').trim(),db=load(),sat=db.sat||{};
    if(DEV_OPEN_ACCESS)return send(res,200,{ok:true,authorized:true,openDevelopmentMode:true,codeVersion:sat.codeVersion||0});
    if(user.role==='super_admin'&&user.id.toLowerCase()===MASTER_ID.toLowerCase())return send(res,200,{ok:true,authorized:true,masterAccess:true,codeVersion:sat.codeVersion||0});
    if(!sat.codeHash||!sat.codeSalt)return send(res,503,{ok:false,error:'SAT access has not been configured by an administrator.'});
    const expected=hashWithSalt(code,sat.codeSalt);
    if(expected.length!==sat.codeHash.length||!crypto.timingSafeEqual(Buffer.from(expected,'hex'),Buffer.from(sat.codeHash,'hex')))return send(res,403,{ok:false,error:'Invalid or expired SAT access code.'});
    db.sat=sat;db.sat.grants=db.sat.grants||{};db.sat.grants[user.id]={codeVersion:db.sat.codeVersion||0,grantedAt:new Date().toISOString()};
    audit(db,user,'sat_access_granted','sat_access',user.id,{codeVersion:db.sat.codeVersion||0});save(db);
    return send(res,200,{ok:true,authorized:true,codeVersion:db.sat.codeVersion||0});
  }
  if(p==='/api/admin/sat'&&req.method==='GET'){
    const actor=requireAdmin(req,res);if(!actor)return;const sat=load().sat||{};
    return send(res,200,{ok:true,configured:!!(sat.codeHash&&sat.codeSalt),codeVersion:sat.codeVersion||0,grants:Object.keys(sat.grants||{}).length});
  }
  if(p==='/api/admin/sat/rotate'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),code=String(b.code||'').trim();
    if(code.length<6)return send(res,400,{ok:false,error:'SAT access code must be at least 6 characters.'});
    const db=load();db.sat=db.sat||{};db.sat.codeSalt=crypto.randomBytes(16).toString('hex');db.sat.codeHash=hashWithSalt(code,db.sat.codeSalt);db.sat.codeVersion=(db.sat.codeVersion||0)+1;db.sat.grants={};
    audit(db,actor,'sat_access_code_rotated','sat_access','SYSTEM',{codeVersion:db.sat.codeVersion});save(db);
    return send(res,200,{ok:true,codeVersion:db.sat.codeVersion,message:'SAT access code rotated; all previous grants are invalid.'});
  }

// V26 SAT protected content routes. PDFs live outside the public static directory.
  if(p==='/api/sat/pdfs'&&req.method==='GET'){
    const user=sessionUser(req); if(!user)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load(),sat=db.sat||{},grant=(sat.grants||{})[user.id];
    if(!grant||grant.codeVersion!==(sat.codeVersion||0))return send(res,403,{ok:false,error:'Active SAT authorisation required.'});
    const dir=path.join(ROOT,'private','sat-pdfs');
    const files=fs.existsSync(dir)?fs.readdirSync(dir).filter(x=>x.toLowerCase().endsWith('.pdf')).sort().map((name,i)=>({id:'SATPDF-'+String(i+1).padStart(2,'0'),name,title:name.replace(/\.pdf$/,'').replace(/_/g,' '),url:'/api/sat/pdfs/'+encodeURIComponent(name)})):[];
    return send(res,200,{ok:true,pdfs:files});
  }
  const satPdfMatch=p.match(/^\/api\/sat\/pdfs\/([^/]+)$/);
  if(satPdfMatch&&req.method==='GET'){
    const user=sessionUser(req); if(!user)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load(),sat=db.sat||{},grant=(sat.grants||{})[user.id];
    if(!grant||grant.codeVersion!==(sat.codeVersion||0))return send(res,403,{ok:false,error:'Active SAT authorisation required.'});
    let name;try{name=decodeURIComponent(satPdfMatch[1])}catch(e){return send(res,400,{ok:false,error:'Bad file name.'})}
    if(!/^\d{2}_SAT_[A-Za-z0-9_]+\.pdf$/.test(name))return send(res,400,{ok:false,error:'Bad SAT file name.'});
    const fp=path.join(ROOT,'private','sat-pdfs',name);
    if(!fs.existsSync(fp)||!fs.statSync(fp).isFile())return send(res,404,{ok:false,error:'SAT practice PDF not found.'});
    const stat=fs.statSync(fp);
    res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':'inline; filename="'+name+'"','Cache-Control':'private, no-store','Content-Length':stat.size});
    return fs.createReadStream(fp).pipe(res);
  }
  // V54 Controlled Student Pilot — testing orchestration only. No real student credentials are created here.
  function pilotEnabled(){return V54_PILOT_MODE;}
  function pilotSafeParticipant(x){return {id:x.id,name:x.name,role:x.role,department:x.department||'',className:x.className||'',status:x.status,createdAt:x.createdAt,lastSeenAt:x.lastSeenAt||'',notes:x.notes||''};}
  if(p==='/api/pilot/status'&&req.method==='GET'){
    return send(res,200,{ok:true,version:'V62',enabled:pilotEnabled(),openTesting:V53_TEST_MODE,syntheticOnly:true,realStudentData:false,message:'V54 is a controlled pilot preparation build. Use synthetic/demo identities until the new production security system is implemented.'});
  }
  if(p==='/api/pilot/participants'&&req.method==='GET'){
    if(!pilotEnabled())return send(res,403,{ok:false,error:'Pilot mode is disabled.'});
    const db=load();return send(res,200,{ok:true,participants:(db.pilot.participants||[]).map(pilotSafeParticipant)});
  }
  if(p==='/api/pilot/participants'&&req.method==='POST'){
    if(!pilotEnabled())return send(res,403,{ok:false,error:'Pilot mode is disabled.'});
    const b=await body(req),db=load();const name=clean(b.name,120),role=['student','teacher','prefect','admin','parent'].includes(b.role)?b.role:'student';
    if(!name)return send(res,400,{ok:false,error:'Participant name is required.'});
    const item={id:id('PILOT'),name,role,department:clean(b.department,80),className:clean(b.className,120),status:'invited',createdAt:new Date().toISOString(),lastSeenAt:'',notes:clean(b.notes,500)};
    db.pilot.participants.push(item);audit(db,sessionUser(req)||{id:'PILOT-TEST'},'create','pilot_participant',item.id,{syntheticOnly:true});save(db);return send(res,201,{ok:true,participant:pilotSafeParticipant(item)});
  }
  const pilotParticipantMatch=p.match(/^\/api\/pilot\/participants\/([^/]+)$/);
  if(pilotParticipantMatch&&(req.method==='PATCH'||req.method==='DELETE')){
    if(!pilotEnabled())return send(res,403,{ok:false,error:'Pilot mode is disabled.'});
    const db=load(),item=db.pilot.participants.find(x=>x.id===pilotParticipantMatch[1]);if(!item)return send(res,404,{ok:false,error:'Pilot participant not found.'});
    if(req.method==='DELETE'){item.status='removed';audit(db,sessionUser(req)||{id:'PILOT-TEST'},'remove','pilot_participant',item.id);save(db);return send(res,200,{ok:true,participant:pilotSafeParticipant(item)});}
    const b=await body(req);for(const k of ['name','department','className','notes'])if(b[k]!==undefined)item[k]=clean(b[k],k==='notes'?500:120);if(b.status!==undefined&&['invited','active','paused','completed','removed'].includes(b.status))item.status=b.status;item.lastSeenAt=new Date().toISOString();save(db);return send(res,200,{ok:true,participant:pilotSafeParticipant(item)});
  }
  if(p==='/api/pilot/feedback'&&req.method==='GET'){
    if(!pilotEnabled())return send(res,403,{ok:false,error:'Pilot mode is disabled.'});const db=load();return send(res,200,{ok:true,feedback:db.pilot.feedback||[],issues:db.pilot.issues||[]});
  }
  if(p==='/api/pilot/feedback'&&req.method==='POST'){
    if(!pilotEnabled())return send(res,403,{ok:false,error:'Pilot mode is disabled.'});const b=await body(req),db=load();const participantId=clean(b.participantId,100),kind=['feedback','bug','idea','workflow'].includes(b.kind)?b.kind:'feedback',text=clean(b.text,2000);if(!text)return send(res,400,{ok:false,error:'Feedback text is required.'});
    const item={id:id('FDB'),participantId,kind,text,rating:Number.isFinite(Number(b.rating))?Math.max(1,Math.min(5,Number(b.rating))):0,status:'open',createdAt:new Date().toISOString()};if(kind==='bug')db.pilot.issues.push(item);else db.pilot.feedback.push(item);save(db);return send(res,201,{ok:true,item});
  }
  if(p==='/api/pilot/summary'&&req.method==='GET'){
    if(!pilotEnabled())return send(res,403,{ok:false,error:'Pilot mode is disabled.'});const db=load(),participants=db.pilot.participants||[],feedback=db.pilot.feedback||[],issues=db.pilot.issues||[];const byRole={};for(const x of participants)byRole[x.role]=(byRole[x.role]||0)+1;return send(res,200,{ok:true,summary:{participants:participants.length,active:participants.filter(x=>x.status==='active').length,completed:participants.filter(x=>x.status==='completed').length,feedback:feedback.length,issues:issues.length,openIssues:issues.filter(x=>x.status==='open').length,byRole}});
  }
  // V40 Publishing Engine — draft -> review -> approval -> scheduled/published -> archived.
  function publishingAudienceVisible(item,u,db){
    if(!item||item.status==='archived')return false;
    const now=Date.now();
    if(item.publishAt && new Date(item.publishAt).getTime()>now)return false;
    if(item.expireAt && new Date(item.expireAt).getTime()<=now)return false;
    const a=item.audience||{type:'public'};
    if(a.type==='public')return true;
    if(a.type==='school')return !!u;
    if(a.type==='role')return !!u && (a.roles||[]).includes(u.role);
    if(a.type==='class'){
      const c=db.classes.find(x=>x.id===a.classId);return !!u&&!!c&&(isAdmin(u)||c.teacherIds?.includes(u.id)||c.formMasterId===u.id||c.captainId===u.id||u.classId===c.id||u.className===c.name);
    }
    if(a.type==='department')return !!u&&(u.department||'').toLowerCase()===(a.department||'').toLowerCase()||isAdmin(u);
    return false;
  }
  function publishStatusAllowedTransition(from,to){
    const map={draft:['in_review','archived'],in_review:['draft','approved','rejected','archived'],approved:['scheduled','published','draft','archived'],scheduled:['published','draft','archived'],published:['archived'],rejected:['draft','archived'],archived:[]};
    return !!(map[from]||[]).includes(to);
  }
  function makePublishingPost(actor,b){
    const title=clean(b.title,180),bodyText=clean(b.body,12000);
    if(!title||!bodyText)throw new Error('Title and body are required.');
    const type=['news','announcement','article','statement','story'].includes(b.type)?b.type:'news';
    const audienceType=['public','school','role','class','department'].includes(b.audienceType)?b.audienceType:'public';
    const audience={type:audienceType};
    if(audience.type==='role')audience.roles=Array.isArray(b.roles)?b.roles.map(x=>clean(x,40)).slice(0,10):[];
    if(audience.type==='class')audience.classId=clean(b.classId,100);
    if(audience.type==='department')audience.department=clean(b.department,100);
    return {id:id('PUB'),title,body:bodyText,excerpt:clean(b.excerpt,500),type,authorId:actor.id,authorName:actor.name||actor.id,audience,coverMediaId:clean(b.coverMediaId,100),tags:Array.isArray(b.tags)?b.tags.map(x=>clean(x,40)).filter(Boolean).slice(0,12):[],status:'draft',publishAt:clean(b.publishAt,40)||'',expireAt:clean(b.expireAt,40)||'',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),submittedAt:'',approvedAt:'',publishedAt:'',archivedAt:'',reviewerId:'',rejectionReason:'',revision:1};
  }
  if(p==='/api/publishing'&&req.method==='GET'){
    const u=sessionUser(req),db=load();
    const rows=(db.publishing.posts||[]).filter(x=>x.status==='published'&&publishingAudienceVisible(x,u,db)).sort((a,b)=>String(b.publishedAt||b.updatedAt).localeCompare(String(a.publishedAt||a.updatedAt)));
    return send(res,200,{ok:true,posts:rows.map(({body,...x})=>({...x,bodyPreview:clean(body,360)}))});
  }
  if(p==='/api/publishing/posts'&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});
    const db=load();const own=(db.publishing.posts||[]).filter(x=>x.authorId===u.id);const visible=own.concat(isAdmin(u)?db.publishing.posts||[]:[]);const seen=new Set();const rows=visible.filter(x=>!seen.has(x.id)&&(seen.add(x.id),true));return send(res,200,{ok:true,posts:rows});
  }
  if(p==='/api/publishing/posts'&&req.method==='POST'){
    const actor=sessionUser(req);if(!actor)return send(res,401,{ok:false,error:'Authentication required.'});
    if(!['teacher','admin','super_admin','prefect'].includes(actor.role))return send(res,403,{ok:false,error:'Publishing permission required.'});
    try{const db=load(),item=makePublishingPost(actor,await body(req));db.publishing.posts.push(item);audit(db,actor,'create','publishing_post',item.id,{status:item.status,type:item.type});save(db);return send(res,201,{ok:true,post:item});}catch(e){return send(res,400,{ok:false,error:e.message})}
  }
  const pubMatch=p.match(/^\/api\/publishing\/posts\/([^/]+)$/);
  if(pubMatch&&req.method==='GET'){
    const u=sessionUser(req);if(!u)return send(res,401,{ok:false,error:'Authentication required.'});const item=load().publishing.posts.find(x=>x.id===pubMatch[1]);if(!item)return send(res,404,{ok:false,error:'Publishing item not found.'});if(item.status!=='published'&&!isAdmin(u)&&item.authorId!==u.id)return send(res,403,{ok:false,error:'Access denied.'});if(item.status==='published'&&!publishingAudienceVisible(item,u,load()))return send(res,403,{ok:false,error:'This publication is not available to your account.'});return send(res,200,{ok:true,post:item});
  }
  if(pubMatch&&(req.method==='PATCH'||req.method==='DELETE')){
    const actor=sessionUser(req);if(!actor)return send(res,401,{ok:false,error:'Authentication required.'});const db=load(),item=db.publishing.posts.find(x=>x.id===pubMatch[1]);if(!item)return send(res,404,{ok:false,error:'Publishing item not found.'});
    if(!isAdmin(actor)&&item.authorId!==actor.id)return send(res,403,{ok:false,error:'Only the author or an administrator can modify this publication.'});
    if(req.method==='DELETE'){if(item.status==='published'&&!isAdmin(actor))return send(res,403,{ok:false,error:'Published items must be archived by an administrator.'});item.status='archived';item.archivedAt=new Date().toISOString();item.updatedAt=item.archivedAt;audit(db,actor,'archive','publishing_post',item.id);save(db);return send(res,200,{ok:true,post:item});}
    const b=await body(req);if(item.status==='published'&&!isAdmin(actor))return send(res,403,{ok:false,error:'Published items are locked to authors; an administrator must archive or revise them.'});
    for(const k of ['title','body','excerpt','type','coverMediaId','publishAt','expireAt'])if(b[k]!==undefined)item[k]=clean(b[k],k==='body'?12000:k==='excerpt'?500:500);
    if(Array.isArray(b.tags))item.tags=b.tags.map(x=>clean(x,40)).filter(Boolean).slice(0,12);
    item.updatedAt=new Date().toISOString();item.revision=(item.revision||1)+1;audit(db,actor,'update','publishing_post',item.id,{fields:Object.keys(b),revision:item.revision});save(db);return send(res,200,{ok:true,post:item});
  }
  if(p==='/api/publishing/submit'&&req.method==='POST'){
    const actor=sessionUser(req);if(!actor)return send(res,401,{ok:false,error:'Authentication required.'});const b=await body(req),db=load(),item=db.publishing.posts.find(x=>x.id===clean(b.id,100));if(!item)return send(res,404,{ok:false,error:'Publishing item not found.'});if(!isAdmin(actor)&&item.authorId!==actor.id)return send(res,403,{ok:false,error:'Only the author or administrator can submit this item.'});if(!publishStatusAllowedTransition(item.status,'in_review'))return send(res,409,{ok:false,error:'This item cannot be submitted from its current status.'});item.status='in_review';item.submittedAt=new Date().toISOString();item.updatedAt=item.submittedAt;audit(db,actor,'submit_for_review','publishing_post',item.id);save(db);return send(res,200,{ok:true,post:item});
  }
  if(p==='/api/admin/publishing'&&req.method==='GET'){const actor=requireAdmin(req,res);if(!actor)return;return send(res,200,{ok:true,posts:load().publishing.posts});}
  if(p==='/api/admin/publishing/review'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),item=db.publishing.posts.find(x=>x.id===clean(b.id,100));if(!item)return send(res,404,{ok:false,error:'Publishing item not found.'});const action=clean(b.action,30);if(action==='approve'){if(!publishStatusAllowedTransition(item.status,'approved'))return send(res,409,{ok:false,error:'Only items in review can be approved.'});item.status='approved';item.approvedAt=new Date().toISOString();item.reviewerId=actor.id;item.rejectionReason='';}
    else if(action==='reject'){if(!publishStatusAllowedTransition(item.status,'rejected'))return send(res,409,{ok:false,error:'Only items in review can be rejected.'});item.status='rejected';item.reviewerId=actor.id;item.rejectionReason=clean(b.reason,600);}
    else return send(res,400,{ok:false,error:'Action must be approve or reject.'});item.updatedAt=new Date().toISOString();audit(db,actor,action,'publishing_post',item.id,{reason:item.rejectionReason||''});save(db);return send(res,200,{ok:true,post:item});
  }
  if(p==='/api/admin/publishing/publish'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),item=db.publishing.posts.find(x=>x.id===clean(b.id,100));if(!item)return send(res,404,{ok:false,error:'Publishing item not found.'});const when=clean(b.publishAt,40);if(when){const t=new Date(when);if(Number.isNaN(t.getTime()))return send(res,400,{ok:false,error:'Invalid publish date.'});if(t.getTime()>Date.now()){if(!publishStatusAllowedTransition(item.status,'scheduled'))return send(res,409,{ok:false,error:'Only approved items can be scheduled.'});item.status='scheduled';item.publishAt=t.toISOString();}else{if(!['approved','scheduled'].includes(item.status))return send(res,409,{ok:false,error:'Only approved or scheduled items can be published.'});item.status='published';item.publishedAt=new Date().toISOString();item.publishAt='';}}
    else {if(!['approved','scheduled'].includes(item.status))return send(res,409,{ok:false,error:'Only approved or scheduled items can be published.'});item.status='published';item.publishedAt=new Date().toISOString();}
    item.updatedAt=new Date().toISOString();audit(db,actor,'publish','publishing_post',item.id,{status:item.status});save(db);return send(res,200,{ok:true,post:item});
  }
  if(p==='/api/admin/publishing/archive'&&req.method==='POST'){
    const actor=requireAdmin(req,res);if(!actor)return;const b=await body(req),db=load(),item=db.publishing.posts.find(x=>x.id===clean(b.id,100));if(!item)return send(res,404,{ok:false,error:'Publishing item not found.'});item.status='archived';item.archivedAt=new Date().toISOString();item.updatedAt=item.archivedAt;audit(db,actor,'archive','publishing_post',item.id);save(db);return send(res,200,{ok:true,post:item});
  }
  if(p==='/api/admin/publishing/summary'&&req.method==='GET'){
    const actor=requireAdmin(req,res);if(!actor)return;const rows=load().publishing.posts||[],counts={};for(const x of rows)counts[x.status]=(counts[x.status]||0)+1;return send(res,200,{ok:true,counts,total:rows.length});
  }
  // V53 — Open testing mode: no website access-code gate is applied.
  // The old access page is retained only as a harmless legacy redirect.
  let file=p==='/'?'index.html':p.replace(/^\//,'');file=path.normalize(file);
  if(file.includes('..'))return send(res,400,{error:'Bad path'});
  if(file.startsWith('private'+path.sep)||file.startsWith('private/'))return send(res,404,{error:'Not found'});
  const ext=path.extname(file).toLowerCase();
  const fp=path.join(ROOT,file);
  if(fs.existsSync(fp)&&fs.statSync(fp).isFile()){const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.ico':'image/x-icon'};res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','X-Content-Type-Options':'nosniff'});return fs.createReadStream(fp).pipe(res)}
  return send(res,404,{error:'Not found'});
 }catch(e){console.error(e);return send(res,500,{ok:false,error:'Server error'})}
});
infrastructure.graceful(server,database);
(async()=>{
  try{
    if(database.provider==='postgres'){
      await database.migrate();
      productionState=await database.loadState();
      if(!productionState){ productionState=loadJson(); await database.saveState(productionState); }
      console.log('V51 PostgreSQL application state loaded.');
    }
    server.listen(PORT,()=>console.log(`St. Mary's Digital Network V65 running at http://localhost:${PORT} (${V53_TEST_MODE?'OPEN TEST MODE':'PROTECTED MODE'})`));
  }catch(e){console.error('Startup failed:',e);process.exit(1)}
})();
