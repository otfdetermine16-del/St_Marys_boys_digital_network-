# GitHub Repository Plan

This repository is the source code for St. Mary's Digital Network.

## Before the first public push
1. Replace the CODEOWNERS placeholder with the real repository owner.
2. Create the repository as **private** during the controlled testing period.
3. Push only this source tree; never push `.env`, runtime data, uploads, database dumps, passwords, tokens, or student personal data.
4. Enable GitHub Actions and branch protection after the first successful CI run.
5. Keep production credentials in the eventual hosting provider's secret/environment-variable store.

## Recommended repository settings
- Visibility: **Private** during student pilot testing.
- Default branch: `main`.
- Pull requests: required for non-owner contributors.
- CI: required status check before merge.
- Secret scanning / push protection: enabled when available.
- Dependabot: enabled after the repository is established.

## Release discipline
Use version tags such as `v48.0.0`, `v49.0.0`, etc. Do not treat GitHub as the production database or media store.
