(function(){
 const year=document.getElementById('year'); if(year) year.textContent=new Date().getFullYear();
 const toggle=document.getElementById('menuToggle'),nav=document.getElementById('mainNav');
 if(toggle&&nav){toggle.addEventListener('click',()=>{nav.classList.toggle('open');toggle.setAttribute('aria-expanded',nav.classList.contains('open'));});nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')))}
 document.querySelectorAll('.filter').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.filter').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const f=btn.dataset.filter;document.querySelectorAll('#mediaGrid figure').forEach(card=>{card.hidden=f!=='all'&&card.dataset.category!==f;});}));
 const form=document.getElementById('studentLogin'),msg=document.getElementById('loginMessage');
 if(form){form.addEventListener('submit',e=>{e.preventDefault();const id=document.getElementById('studentId').value.trim();if(!id){return} if(id==='SMB-DEMO-001'){location.href='student-portal.html'}else{msg.textContent='For now, use SMB-DEMO-001 to preview the prototype. Real school IDs will only work after secure backend authentication is implemented.';msg.style.color='#a32929';}})}
 const io='IntersectionObserver' in window?new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.08}):null;
 if(io)document.querySelectorAll('.section,.quick-grid article,.hero').forEach(e=>io.observe(e));
})();
