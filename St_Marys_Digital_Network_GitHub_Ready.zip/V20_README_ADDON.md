# V20 — IT, Security, Continuity & Academic-Year Engine
V20 adds administrator-controlled system continuity: academic-year rollover records, logical backup records, security summary, handover preparation, and system settings including future hero-image/branding control. The current upload endpoint remains the production-development media path; final deployment should use object storage/CDN and signed access where appropriate.

**Demo admin:** `ADMIN-DEMO-001` / `demo123` (development only). Change/remove demo credentials before school deployment.
