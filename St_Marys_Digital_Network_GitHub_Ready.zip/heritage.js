const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const card=(x,extra='')=>`<article class="v17-item"><div><strong>${esc(x.title||x.name)}</strong><small>${esc(x.era||x.year||'Date pending')} · ${esc(x.category||x.role||'Heritage')} · ${esc(x.verificationStatus||'verified')}</small><p>${esc(x.description||'')}</p>${x.sourceNote?`<small>Source: ${esc(x.sourceNote)}</small>`:''}${extra}</div></article>`;
(async()=>{const box=document.getElementById('heritage');try{const r=await fetch('/api/heritage',{credentials:'include'});const d=await r.json();if(!r.ok)throw Error(d.error||'Sign in required');
 const [tr,pr,mr]=await Promise.all([fetch('/api/heritage/timeline',{credentials:'include'}),fetch('/api/heritage/people',{credentials:'include'}),fetch('/api/heritage/milestones',{credentials:'include'})]);
 const [td,pd,md]=await Promise.all([tr.json(),pr.json(),mr.json()]);
 box.innerHTML=`<div class="heritage-block"><h3>School history records</h3>${d.heritage.length?d.heritage.map(x=>card(x)).join(''):'<div class="empty-state">No verified history records have been published yet.</div>'}</div>`+
 `<div class="heritage-block"><h3>Timeline</h3>${(td.timeline||[]).length?td.timeline.map(x=>card(x)).join(''):'<div class="empty-state">The timeline is ready for verified milestones.</div>'}</div>`+
 `<div class="heritage-block"><h3>People who shaped the school</h3>${(pd.people||[]).length?pd.people.map(x=>card(x, x.photo?`<small>Photo reference: ${esc(x.photo)}</small>`:'')).join(''):'<div class="empty-state">Historical people will appear here after verification.</div>'}</div>`+
 `<div class="heritage-block"><h3>Milestones</h3>${(md.milestones||[]).length?md.milestones.map(x=>card(x)).join(''):'<div class="empty-state">Verified milestones will appear here.</div>'}</div>`;
 }catch(e){box.innerHTML='<div class="empty-state">Please sign in to access the protected archive.</div>'}})();
