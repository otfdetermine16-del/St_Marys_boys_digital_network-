/* V12 local prototype store. Replace with API/database calls in production. */
(function(){
  'use strict';
  const KEY='sm_v12_data_store';
  const blank={meta:{schemaVersion:'12.0',updatedAt:null},school:null,academicYears:[],departments:[],classes:[],people:[],accounts:[],roles:[],clubs:[],memberships:[],posts:[],comments:[],reactions:[],resources:[],assignments:[],events:[],achievements:[],media:[],notifications:[],auditLogs:[],handovers:[]};
  function load(){try{return Object.assign(blank,JSON.parse(localStorage.getItem(KEY)||'{}'));}catch{return structuredClone?structuredClone(blank):JSON.parse(JSON.stringify(blank));}}
  function save(db){db.meta.updatedAt=new Date().toISOString();localStorage.setItem(KEY,JSON.stringify(db));return db;}
  function id(prefix){return prefix+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);}
  window.SM_STORE={KEY,load,save,id,blank};
})();
