(function(){
  const box=document.getElementById('relationshipList');
  if(!box||!window.SM_SCHEMA)return;
  box.innerHTML=SM_SCHEMA.relationships.map((r,i)=>`<div class="relationship"><span>${String(i+1).padStart(2,'0')}</span><b>${r.split(' ')[0]}</b><em>${r}</em></div>`).join('');
})();
