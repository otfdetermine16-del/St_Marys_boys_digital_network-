/* V52 homepage — compact interactions without sideways scrolling. */
(() => {
  'use strict';
  const form = document.querySelector('.sm-search');
  const input = form?.querySelector('input');
  form?.addEventListener('submit', e => {
    if (!input?.value.trim()) e.preventDefault();
  });
})();
