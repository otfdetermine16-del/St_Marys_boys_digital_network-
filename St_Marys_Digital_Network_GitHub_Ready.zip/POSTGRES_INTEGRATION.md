# V51 — Full PostgreSQL Integration

Production mode now requires PostgreSQL. The application state is loaded into memory once at startup and persisted through a serialized PostgreSQL write queue after mutations. The V44 relational tables remain available for gradual domain decomposition.

## Production requirements
- `NODE_ENV=production`
- `ST_MARYS_DB_PROVIDER=postgres`
- `DATABASE_URL`
- `SESSION_SECRET` of at least 32 characters
- `ST_MARYS_SECURITY_ENABLED=true`

The development JSON store remains available only outside production.
