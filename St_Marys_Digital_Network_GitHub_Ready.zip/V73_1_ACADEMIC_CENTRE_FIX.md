# V73.1 — Academic Centre Fix

Implemented on the V73 MARISCAN baseline.

- Fixed the Academic Centre module loading bug by loading `academic.js` as an ES module.
- Reworked the Academic Centre UI for mobile and desktop.
- Added subject search and academic-term filtering.
- Added subject count, record count, average numeric score and latest-term summaries.
- Added robust transcript access handling using the configured `/api/site-content` transcript URL.
- Added print controls and a cleaner transcript summary.
- Added authorised result-entry UI for teachers/administrators.
- Preserved server-side authorization and academic privacy checks.
- Synced root/public academic assets.
