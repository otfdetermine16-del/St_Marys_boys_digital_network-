# V54 — Controlled Student Pilot (historical)

V54 adds a pilot coordination centre for isolated testing. It uses synthetic/demo identities only and collects no passwords.

## Pilot workflow
1. Run the site locally or in an isolated test environment.
2. Add demo participant labels in `pilot.html`.
3. Test homepage, identity, classes, academics, Connect, clubs, media, suggestions and admin editing.
4. Record feedback and bugs in Pilot Centre.
5. Fix issues before any real student data is introduced.

## Security boundary
V53/V54 intentionally remain open for testing. Do not expose these builds publicly or use real confidential student information. A new production authentication/authorization system must be implemented before school-wide deployment.
