(async()=>{
 const $=s=>document.querySelector(s); const msg=t=>{$('#identityMsg').textContent=t};
 try{
  const r=await fetch('/api/account/profile',{credentials:'same-origin'}); const j=await r.json();
  if(!r.ok) throw new Error(j.error||'Please sign in.');
  const u=j.profile, p=u.person||{};
  $('[data-name]').textContent=u.name||'—'; $('[data-id]').textContent=u.id||'—'; $('[data-role]').textContent=u.role||'—';
  $('#name').value=u.name||''; $('#fullName').textContent=u.name||'—'; $('#email').textContent=u.email||p.email||'Not provided'; $('#department').textContent=p.department||u.department||'Not assigned'; $('#className').textContent=p.className||u.className||'Not assigned'; $('#house').textContent=u.house||'Not assigned'; $('#personType').textContent=p.personType||'Account profile';
 }catch(e){location.href='login.html'}
 $('#identityForm').onsubmit=async e=>{e.preventDefault();msg('Saving…');const r=await fetch('/api/account/profile',{method:'PATCH',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('#name').value})});const j=await r.json();msg(r.ok?'Identity updated successfully.':(j.error||'Could not update identity.'))};
})();
