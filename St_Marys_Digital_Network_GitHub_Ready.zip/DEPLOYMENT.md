# V50 — Internet Deployment Foundation

This package prepares St. Mary's Digital Network for production hosting.

## Important production gate
The application currently has a PostgreSQL architecture adapter, but the majority of legacy application routes still read/write the JSON development store through `load()` / `save()`. Therefore **do not launch this build publicly as the final production system yet**. Production startup requires PostgreSQL, but full route-level PostgreSQL migration must be completed before real student data is used online.

## Included
- Docker production image
- Render deployment blueprint
- production startup gate
- deployment preflight checks
- database migration at startup
- `/api/ready` health check
- secret/environment guidance

## Safe sequence
1. Push repository to GitHub.
2. Create a managed PostgreSQL database.
3. Complete route-level PostgreSQL data migration and test it.
4. Configure secrets only in the host dashboard.
5. Run `npm run deploy:preflight`.
6. Deploy the web service.
7. Verify HTTPS, backups, authentication, uploads and recovery.
8. Only then add the controlled student pilot accounts.

Never commit `.env`, database URLs, API tokens, session secrets, student records or uploaded media containing private information.
