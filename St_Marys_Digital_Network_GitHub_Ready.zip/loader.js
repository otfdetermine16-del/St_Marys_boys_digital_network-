(function(){
  'use strict';
  const reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if('scrollRestoration' in history) history.scrollRestoration='manual';
  const loader=document.createElement('div');
  loader.id='sm-page-loader';
  loader.innerHTML='<div class="sm-loader-box" role="status" aria-live="polite"><div class="sm-loader-mark"><div class="sm-loader-ring"></div><div class="sm-loader-plane" aria-hidden="true">✈</div></div><div class="sm-loader-title">St. Mary\'s Digital Network</div><div class="sm-loader-status">Preparing your page…</div></div>';
  document.documentElement.prepend(loader);

  function finish(){
    document.body.classList.add('sm-page-ready');
    requestAnimationFrame(()=>loader.classList.add('is-done'));
  }
  function showLoader(message){
    const status=loader.querySelector('.sm-loader-status');
    if(status) status.textContent=message||'Preparing your page…';
    loader.classList.remove('is-done');
    document.body.classList.remove('sm-page-ready');
  }

  window.addEventListener('load',()=>setTimeout(finish,reduced?0:550),{once:true});
  setTimeout(finish,reduced?500:3500);

  /* Internal pages use the plane loader, then the new document simply appears. */
  document.addEventListener('click',e=>{
    const a=e.target.closest('a');
    if(!a||e.defaultPrevented||a.target==='_blank'||a.hasAttribute('download')) return;
    const href=a.getAttribute('href');
    if(!href||href.startsWith('#')||href.startsWith('mailto:')||href.startsWith('tel:')||href.startsWith('javascript:')) return;
    try{
      const u=new URL(href,location.href);
      if(u.origin!==location.origin) return;
      if(u.pathname===location.pathname && u.search===location.search) return;
    }catch(_){return;}
    e.preventDefault();
    showLoader('Opening '+(a.textContent.trim()||'page')+'…');
    window.scrollTo(0,0);
    setTimeout(()=>{location.href=href;},reduced?0:500);
  });
})();
