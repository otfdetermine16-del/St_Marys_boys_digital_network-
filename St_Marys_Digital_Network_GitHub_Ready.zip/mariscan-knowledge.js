// MARISCAN AI V73 — verified public school knowledge and navigation map.
// Keep private student records out of this file.
window.MARISCAN_SCHOOL_KNOWLEDGE = {
  school: {
    name: "St. Mary's Boys' Senior High School",
    location: 'Apowa, near Takoradi, Western Region, Ghana',
    established: 'January 26, 1947',
    motto: 'Disce Ut Doceas — Learn in order to teach',
    colours: ['blue', 'dark blue', 'white', 'violet']
  },
  departments: ['Science', 'General Arts', 'Visual Arts', 'Agriculture', 'Business'],
  levels: ['SHS 1', 'SHS 2', 'SHS 3'],
  clubs: [
    "St. Mary's Young Aviators Club",
    'DRAMAS, WRITERS & DEBATORS CLUB',
    'Maths & Science Club',
    'CADET CORP AND REGIMENTAL BAND'
  ],
  history: [
    'The institution traces its origin to Amisa Ano in the Central Region and was established by the Catholic Church as a two-year training college.',
    'It was formally opened by His Lordship W.T. Porter on January 26, 1947.',
    'The permanent Apowa site was associated with a building completed February 1, 1954 and formally opened December 11, 1957.',
    'J.D. Otoo became the first Ghanaian principal on November 26, 1951.',
    'The school transformed in 1973, with the last teacher trainees leaving in August 1978.',
    'The 1991 educational reforms introduced a new phase of development; the school returned to boys-only status in 1994.',
    'Margaret Lemaire served as headmistress from 2005 to 2009 and was the first female head of the school.',
    'Joseph Bagbine served as headmaster from 2009 to 2017.',
    'The school became St. Mary’s Boys’ Senior High School in 2010.'
  ],
  navigation: [
    ['Home', 'home.html'], ['Academics', 'academic.html'], ['St. Mary’s Connect', 'connect.html'],
    ['Heritage', 'heritage.html'], ['Student Hub', 'student-hub.html'], ['Alumni', 'alumni.html'],
    ['Search', 'search.html'], ['Notifications', 'notifications.html'], ['Clubs & Achievements', 'clubs.html'],
    ['MARISCAN ARTISTRY', 'media-centre.html'], ['Suggestion Box', 'suggestions.html'], ['PTA', 'pta.html'],
    ['School Map', 'map.html'], ['Rules / Vision / Mission', 'school-information.html'], ['MARISCAN AI Assistant', 'ai.html']
  ]
};
