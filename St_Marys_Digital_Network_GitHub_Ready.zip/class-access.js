
/* St. Mary's Digital Network — V6 Class Access Prototype
   Demo-only client-side access model. Production MUST move all
   authentication, authorization, class-code validation and membership
   decisions to a secure server/database.
*/
(function () {
  "use strict";

  const STORAGE = "sm_class_access_demo";

  const defaultState = {
    currentUser: {
      id: "SMB-DEMO-001",
      name: "Demo Student",
      role: "student",
      department: "Science",
      year: "SHS 2",
      classId: "science-2a"
    },
    classes: {
      "science-2a": {
        code: "SCI2A-DEMO",
        department: "Science",
        year: "SHS 2",
        name: "Science 2A",
        teacher: "Teacher assignment pending",
        archived: false,
        members: ["SMB-DEMO-001"]
      }
    }
  };

  function load() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE)) || structuredClone(defaultState);
    } catch (_) {
      return structuredClone(defaultState);
    }
  }

  function save(state) {
    localStorage.setItem(STORAGE, JSON.stringify(state));
  }

  function canViewClass(state, classId) {
    const c = state.classes[classId];
    if (!c || c.archived) return false;
    const u = state.currentUser;
    if (!u) return false;
    return u.role === "admin" || u.role === "super_admin" || u.role === "teacher" ||
           (Array.isArray(c.members) && c.members.includes(u.id));
  }

  window.SMClassAccess = {
    load,
    save,
    canViewClass,
    joinWithCode(code) {
      const state = load();
      const normalized = String(code || "").trim().toUpperCase();
      const match = Object.entries(state.classes)
        .find(([, c]) => !c.archived && String(c.code).toUpperCase() === normalized);

      if (!match) return { ok: false, message: "That class code is not valid." };

      const [classId, cls] = match;
      const user = state.currentUser;
      if (!user) return { ok: false, message: "Please sign in first." };

      if (!cls.members.includes(user.id)) cls.members.push(user.id);
      user.classId = classId;
      user.department = cls.department;
      user.year = cls.year;
      state.currentUser = user;
      save(state);

      return { ok: true, classId, className: cls.name };
    }
  };
})();
