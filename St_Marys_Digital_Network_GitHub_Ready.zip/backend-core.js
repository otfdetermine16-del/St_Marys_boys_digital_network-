'use strict';
// V65 Backend Core: shared production primitives for authentication, rate limiting,
// request hardening, signed sessions, validation and operational diagnostics.
const crypto = require('crypto');

const WINDOW_MS = 60_000;
const buckets = new Map();
const LOGIN_WINDOW_MS = 10 * 60_000;
const LOGIN_MAX = 8;
const API_MAX = 180;

function now(){ return Date.now(); }
function clientKey(req){
  // Only trust forwarded addresses when explicitly enabled by the deployment.
  const forwarded = process.env.TRUST_PROXY === 'true' ? String(req.headers['x-forwarded-for']||'').split(',')[0].trim() : '';
  return forwarded || req.socket?.remoteAddress || 'unknown';
}
function rateLimit(req, kind='api'){
  const key = `${kind}:${clientKey(req)}`;
  const t=now(); const max=kind==='login'?LOGIN_MAX:API_MAX; const win=kind==='login'?LOGIN_WINDOW_MS:WINDOW_MS;
  let b=buckets.get(key);
  if(!b || t-b.start>=win){ b={start:t,count:0}; buckets.set(key,b); }
  b.count++;
  if(b.count>max) return {ok:false,retryAfter:Math.max(1,Math.ceil((win-(t-b.start))/1000))};
  if(buckets.size>5000 && Math.random()<0.02){ for(const [k,v] of buckets) if(t-v.start>LOGIN_WINDOW_MS) buckets.delete(k); }
  return {ok:true};
}
function applySecurityHeaders(res){
  const headers={
    'X-Content-Type-Options':'nosniff',
    'X-Frame-Options':'SAMEORIGIN',
    'Referrer-Policy':'strict-origin-when-cross-origin',
    'Permissions-Policy':'camera=(), microphone=(), geolocation=()',
    'Cross-Origin-Opener-Policy':'same-origin-allow-popups'
  };
  for(const [k,v] of Object.entries(headers)) res.setHeader(k,v);
  if(process.env.NODE_ENV==='production') res.setHeader('Strict-Transport-Security','max-age=31536000; includeSubDomains');
}
function signSession(userId, secret, ttlMs=8*60*60*1000){
  if(!secret || secret.length<32) throw new Error('SESSION_SECRET must be at least 32 characters.');
  const exp=Date.now()+ttlMs;
  const payload=Buffer.from(JSON.stringify({sub:String(userId),exp})).toString('base64url');
  const sig=crypto.createHmac('sha256',secret).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}
function verifySession(token, secret){
  try{
    if(!token || !secret || secret.length<32) return null;
    const [payload,sig]=String(token).split('.'); if(!payload||!sig)return null;
    const expected=crypto.createHmac('sha256',secret).update(payload).digest('base64url');
    const a=Buffer.from(sig),b=Buffer.from(expected); if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;
    const data=JSON.parse(Buffer.from(payload,'base64url').toString('utf8'));
    if(!data?.sub || !Number.isFinite(data.exp) || data.exp<Date.now())return null;
    return data;
  }catch{return null}
}
function passwordPolicy(password){
  const p=String(password||'');
  if(p.length<12) return {ok:false,error:'Password must be at least 12 characters in production.'};
  if(!/[A-Z]/.test(p)||!/[a-z]/.test(p)||!/[0-9]/.test(p)) return {ok:false,error:'Password must include upper-case, lower-case and a number in production.'};
  return {ok:true};
}
function redactConfig(env){
  const keys=['OPENAI_API_KEY','YOUTUBE_API_KEY','DATABASE_URL','SESSION_SECRET','ST_MARYS_MASTER_HASH','ST_MARYS_MASTER_SALT','ST_MARYS_MASTER_PASSWORD','ST_MARYS_ADMIN_API_TOKEN'];
  const out={}; for(const k of keys) out[k]=Boolean(env[k]); return out;
}
function diagnostics({database,version,devOpen,mediaRoot}){
  return {
    version, node:process.version, environment:process.env.NODE_ENV||'development',
    security:{production:process.env.NODE_ENV==='production',devOpen,sessionSecretConfigured:Boolean(process.env.SESSION_SECRET&&process.env.SESSION_SECRET.length>=32)},
    database:{provider:database},
    storage:{mediaRoot,localDisk:database!=='postgres' || process.env.ST_MARYS_STORAGE_PROVIDER!=='firebase',provider:process.env.ST_MARYS_STORAGE_PROVIDER||'local-disk'},
    secrets:redactConfig(process.env),
    timestamp:new Date().toISOString()
  };
}
module.exports={rateLimit,applySecurityHeaders,signSession,verifySession,passwordPolicy,diagnostics};
