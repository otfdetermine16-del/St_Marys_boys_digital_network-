// St. Mary's Digital Network — Firebase Authentication Bridge (V58)
// Firebase Auth is used for browser identity during testing. The Network backend
// still owns academic records, clubs, houses and other school data.
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  updateProfile
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyAYHTYttEQhgt8HMyQyEBnkFTjWXtLPoeM",
  authDomain: "st-marys-digital-network.firebaseapp.com",
  projectId: "st-marys-digital-network",
  storageBucket: "st-marys-digital-network.firebasestorage.app",
  messagingSenderId: "117888972500",
  appId: "1:117888972500:web:7fb3d98e45cdd16f0fad41",
  measurementId: "G-VRCPNYMH44"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const friendly = code => ({
  "auth/invalid-credential": "The email or password is incorrect.",
  "auth/user-not-found": "No account was found with this email.",
  "auth/wrong-password": "The password is incorrect.",
  "auth/email-already-in-use": "An account with this email already exists.",
  "auth/weak-password": "Please use a stronger password (at least 6 characters).",
  "auth/invalid-email": "Please enter a valid email address.",
  "auth/too-many-requests": "Too many attempts. Please wait and try again.",
  "auth/network-request-failed": "Network error. Check your internet connection.",
  "auth/operation-not-allowed": "Email/password sign-in is not enabled in Firebase yet."
}[code] || "Something went wrong. Please try again.");

async function syncBackend(firebaseUser, displayName = "") {
  if (!firebaseUser) return null;
  const token = await firebaseUser.getIdToken();
  const r = await fetch('/api/auth/firebase-sync', {
    method: 'POST',
    credentials: 'same-origin',
    headers: {'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`},
    body: JSON.stringify({
      firebaseUid: firebaseUser.uid,
      email: firebaseUser.email || '',
      displayName: displayName || firebaseUser.displayName || ''
    })
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || 'Could not connect your Firebase account to the Network.');
  return data.user;
}

async function backendMe() {
  try {
    const r = await fetch('/api/me', {credentials:'same-origin'});
    const j = await r.json().catch(() => ({}));
    return r.ok && j.ok ? j.user : null;
  } catch { return null; }
}

window.SMAuth = {
  auth,
  getCurrentUser: () => auth.currentUser,
  friendlyError: friendly,
  async requireRole(allowedRoles = []) {
    let user = auth.currentUser;
    if (!user) {
      await new Promise(resolve => {
        const unsub = onAuthStateChanged(auth, u => { user = u; unsub(); resolve(); });
      });
    }
    if (!user) {
      const returnTo = location.pathname.split('/').pop() + location.search;
      location.href = 'access.html?return=' + encodeURIComponent(returnTo);
      return null;
    }
    const serverUser = await syncBackend(user);
    const role = serverUser?.role || localStorage.getItem('sm_role_' + user.uid) || 'student';
    if (allowedRoles.length && !allowedRoles.includes(role) && !(role === 'super_admin' && allowedRoles.includes('admin'))) {
      alert('Your account does not have permission to open this area.');
      return null;
    }
    return {id: serverUser.id, email:user.email, role, firebaseUser:user, ...serverUser};
  },
  async syncCurrentUser(displayName='') { return syncBackend(auth.currentUser, displayName); },
  setTestRole(role) {
    if (!['student','teacher','admin'].includes(role)) return false;
    const user = auth.currentUser;
    if (!user) return false;
    localStorage.setItem('sm_role_' + user.uid, role);
    return true;
  },
  async serverMe() { return backendMe(); },
  async logout() {
    try { await fetch('/api/logout',{method:'POST',credentials:'same-origin'}); } catch {}
    await signOut(auth);
    location.href='login.html';
  }
};

window.loginUser = async (email, password) => {
  const credential = await signInWithEmailAndPassword(auth, email.trim(), password);
  await syncBackend(credential.user);
  return credential;
};
window.registerUser = async (email, password, displayName='') => {
  const credential = await createUserWithEmailAndPassword(auth, email.trim(), password);
  if (displayName) await updateProfile(credential.user, {displayName});
  await syncBackend(credential.user, displayName);
  return credential;
};
window.resetUserPassword = email => sendPasswordResetEmail(auth, email.trim());
window.logoutUser = () => signOut(auth);

onAuthStateChanged(auth, async user => {
  document.dispatchEvent(new CustomEvent(user ? 'sm:user-signed-in' : 'sm:user-signed-out', {detail:user || null}));
});
