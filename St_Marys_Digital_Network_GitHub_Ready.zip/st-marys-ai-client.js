// St. Mary's Digital Network — MARISCAN AI client
// Uses Firebase Cloud Functions when hosted on Firebase, and the existing
// Network Node backend when running locally. Secrets never live in the browser.
(function () {
  const firebaseApi = () => Boolean(window.SMAuth?.auth && /firebaseapp\.com$|web\.app$/.test(location.hostname));

  async function firebaseUser() {
    const auth = window.SMAuth?.auth;
    if (!auth) throw new Error('Firebase authentication is not loaded.');
    if (auth.currentUser) return auth.currentUser;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Waiting for Firebase authentication timed out.')), 10000);
      const unsub = auth.onAuthStateChanged(user => {
        clearTimeout(timeout); unsub();
        user ? resolve(user) : reject(new Error('Please sign in to use MARISCAN AI.'));
      });
    });
  }

  async function firebaseCall(path, body, method = 'POST') {
    const user = await firebaseUser();
    const token = await user.getIdToken(true);
    const r = await fetch(path, {
      method, credentials: 'include',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: method === 'GET' ? undefined : JSON.stringify(body || {})
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || `MARISCAN request failed (${r.status}).`);
    return data;
  }

  async function nodeCall(path, body) {
    const r = await fetch(path, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || `MARISCAN request failed (${r.status}).`);
    return data;
  }

  async function health() {
    if (firebaseApi()) return firebaseCall('/api/health', {}, 'GET');
    const r = await fetch('/api/ai/status', { credentials: 'same-origin' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || 'MARISCAN backend unavailable.');
    return { ok: true, status: d.enabled === false ? 'offline' : 'online', backend: 'network-node' };
  }

  async function chat(message, web = false, history = []) {
    if (firebaseApi()) return firebaseCall('/api/chat', { question: message, web, history });
    const r = await fetch('/api/ai/query', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: message, useInternet: web, history })
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || 'MARISCAN backend unavailable.');
    return { answer: d.assistant?.result || d.answer || '', sources: (d.internet || []).map(x => ({ title: x.title, url: x.url })) };
  }

  const api = {
    health,
    chat,
    ask: chat,
    search: q => firebaseApi() ? firebaseCall('/api/ai/search', { query: q }) : chat(`Search the internet for current information about: ${q}`, true, []),
    youtube: q => firebaseApi() ? firebaseCall('/api/youtube', { query: q }) : Promise.reject(new Error('YouTube search requires the Firebase MARISCAN backend to be deployed.')),
    generateImage: p => firebaseApi() ? firebaseCall('/api/image', { mode: 'generate', prompt: p }) : Promise.reject(new Error('Image generation requires the Firebase MARISCAN backend to be deployed.')),
    editImage: (p, dataUrl) => firebaseApi() ? firebaseCall('/api/image', { mode: 'edit', prompt: p, imageDataUrl: dataUrl }) : Promise.reject(new Error('Image editing requires the Firebase MARISCAN backend to be deployed.')),
    createPDF: (title, content) => firebaseApi() ? firebaseCall('/api/pdf', { title, content }) : Promise.reject(new Error('PDF generation requires the Firebase MARISCAN backend to be deployed.'))
  };
  window.StMarysAI = api;
})();
