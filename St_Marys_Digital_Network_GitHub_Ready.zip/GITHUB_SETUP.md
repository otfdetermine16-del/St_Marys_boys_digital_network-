# GitHub Preparation — V47

This repository is prepared for source control, but **it is not automatically a production deployment**.

## Before the first push

1. Create a new **private** GitHub repository while the platform is being tested.
2. Copy this project into the repository and inspect the files before pushing.
3. Confirm `.env`, `server-data.json`, uploads and logs are ignored.
4. Never commit real student records, passwords, phone numbers, grades, tokens, database URLs or private school documents.
5. Keep `ST_MARYS_DEV_OPEN_ACCESS=true` only for local development. Internet deployment must disable it.
6. Add production secrets through the hosting provider's secret/environment settings, not Git.

## Recommended first repository state

- Default branch: `main`
- Protect `main` once collaboration begins.
- Use pull requests for changes.
- Tag tested releases, e.g. `v46.0.0`, `v47.0.0`.
- Keep real school data out of GitHub; use the production database and object storage instead.

## Local run

```bash
npm install
npm test
npm start
```

Then open `http://localhost:3000/`.

## Production gate

The server refuses unsafe production settings. Production must have:

- `NODE_ENV=production`
- `ST_MARYS_DEV_OPEN_ACCESS=false`
- `SESSION_SECRET` with at least 32 characters
- real authentication/authorization configuration
- PostgreSQL/managed database
- HTTPS
- secure secret storage
- backups and monitoring

See `README.md` and `TESTING.md` for the broader deployment/security requirements.
