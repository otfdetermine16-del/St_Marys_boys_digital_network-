(function(){
const KEY='sm_young_aviators_v5';
const initial={founder:{name:'[Founder name to be entered]',photo:'assets/crest-lively.jpg',year:'2026'},leaders:[{period:'Founding era',position:'Founder / First Leader',name:'[Founder name to be entered]',status:'Founder'}],members:[],requests:[]};
function load(){try{return Object.assign({},initial,JSON.parse(localStorage.getItem(KEY)||'{}'))}catch(e){return initial}}
function save(x){localStorage.setItem(KEY,JSON.stringify(x))}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function render(){const d=load();document.getElementById('founderName').textContent=d.founder.name;document.getElementById('founderName2').textContent=d.founder.name;document.getElementById('memberCount').textContent=d.members.length;document.getElementById('pendingCount').textContent=d.requests.length;document.getElementById('leadershipTimeline').innerHTML=d.leaders.map(l=>`<div class="timeline-item"><b>${esc(l.period)}</b><span>${esc(l.position)} — ${esc(l.name)}</span><small>${esc(l.status)}</small></div>`).join('');document.getElementById('memberList').innerHTML=d.members.length?d.members.map(m=>`<div><b>${esc(m.name)}</b><span>${esc(m.level)} · Approved member</span></div>`).join(''):'<div class="empty">No approved prototype members yet.</div>'}
document.getElementById('joinBtn').onclick=()=>{const d=load();if(d.requests.some(r=>r.name==='Demo Student')||d.members.some(m=>m.name==='Demo Student')){show('You already have a pending/approved demo membership.');return}d.requests.push({name:'Demo Student',level:'SHS 2',createdAt:new Date().toISOString()});save(d);show('Membership request submitted. A current authorized club leader would review it.');render()};
function show(msg){const el=document.getElementById('membershipMessage');el.textContent=msg;el.style.display='block';setTimeout(()=>el.style.display='none',4000)}
render();
})();
