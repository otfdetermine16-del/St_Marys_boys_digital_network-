// St. Mary's Digital Network — V73 Academic Centre
import './firebase-auth.js';

(async () => {
  const user = await window.SMAuth.requireRole(['student', 'teacher', 'admin']);
  if (!user) return;

  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const state = { data: null, records: [], selectedStudentId: null };

  async function get(path) {
    const response = await fetch(path, { credentials: 'same-origin' });
    const json = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(json.error || 'Request failed.');
    return json;
  }

  function scoreClass(score) {
    if (score === null || score === undefined || score === '') return '';
    const n = Number(score);
    if (n >= 80) return 'score-high';
    if (n >= 50) return 'score-mid';
    return 'score-low';
  }

  function populateSummary(records) {
    const numeric = records.map(r => Number(r.score)).filter(Number.isFinite);
    const subjects = new Set(records.map(r => String(r.subject || '').trim().toLowerCase()).filter(Boolean));
    $('recordCount').textContent = records.length;
    $('subjectCount').textContent = subjects.size;
    $('averageScore').textContent = numeric.length ? `${(numeric.reduce((a,b) => a + b, 0) / numeric.length).toFixed(1)}%` : '—';
    $('latestTerm').textContent = records[0] ? `${records[0].academicYear || '—'} · ${records[0].term || '—'}` : '—';
  }

  function buildTermFilter(records) {
    const select = $('termFilter');
    const terms = [...new Set(records.map(r => `${r.academicYear || '—'} — ${r.term || '—'}`))];
    select.innerHTML = '<option value="all">All terms</option>' + terms.map(t => `<option value="${esc(t)}">${esc(t)}</option>`).join('');
  }

  function renderRecords() {
    const filter = $('subjectFilter').value.trim().toLowerCase();
    const term = $('termFilter').value;
    const records = state.records.filter(r => {
      const subjectOK = !filter || String(r.subject || '').toLowerCase().includes(filter);
      const termKey = `${r.academicYear || '—'} — ${r.term || '—'}`;
      return subjectOK && (term === 'all' || termKey === term);
    });

    if (!records.length) {
      $('recordArea').innerHTML = `<div class="academic-empty"><span>∅</span><div><strong>No matching academic records</strong><p class="muted">There are no results matching the current filter.</p></div></div>`;
      return;
    }

    const grouped = {};
    for (const record of records) {
      const key = `${record.academicYear || '—'} — ${record.term || '—'}`;
      (grouped[key] ||= []).push(record);
    }

    $('recordArea').innerHTML = Object.entries(grouped).map(([key, rows]) => `
      <div class="academic-term">
        <div class="section-head-row term-heading"><h3>${esc(key)}</h3><span class="badge">${rows.length} record${rows.length === 1 ? '' : 's'}</span></div>
        <div class="table-wrap">
          <table class="academic-table">
            <thead><tr><th>Subject</th><th>Score</th><th>Grade</th><th>Remarks</th><th>Updated</th></tr></thead>
            <tbody>${rows.map(r => `
              <tr>
                <td><strong>${esc(r.subject || '—')}</strong></td>
                <td><span class="score-chip ${scoreClass(r.score)}">${r.score === null || r.score === undefined || r.score === '' ? '—' : `${esc(r.score)}%`}</span></td>
                <td>${esc(r.grade || '—')}</td>
                <td>${esc(r.remarks || '—')}</td>
                <td>${esc(formatDate(r.updatedAt || r.createdAt))}</td>
              </tr>`).join('')}</tbody>
          </table>
        </div>
      </div>`).join('');
  }

  function formatDate(value) {
    if (!value) return '—';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value).slice(0, 16);
    return date.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  async function load() {
    const target = new URLSearchParams(location.search).get('studentId');
    const path = '/api/account/academic' + (target ? `?studentId=${encodeURIComponent(target)}` : '');
    const data = await get(path);
    state.data = data;
    state.selectedStudentId = data.student.id;
    state.records = Array.isArray(data.records) ? data.records : [];

    $('studentName').textContent = data.student.name || 'Student';
    $('studentClass').textContent = data.student.className || 'Class not assigned';
    $('studentMeta').innerHTML = `
      <div><small>ACCOUNT ID</small><strong>${esc(data.student.id)}</strong></div>
      <div><small>DEPARTMENT</small><strong>${esc(data.student.department || '—')}</strong></div>
      <div><small>YEAR</small><strong>${esc(data.student.year || '—')}</strong></div>
      <div><small>RECORDS</small><strong>${state.records.length}</strong></div>`;

    if ($('recordStudentId')) $('recordStudentId').value = data.student.id;
    populateSummary(state.records);
    buildTermFilter(state.records);
    renderRecords();
  }

  async function site() {
    try {
      const config = await get('/api/site-config');
      const year = config.site?.academicYear || '—';
      $('academicYear').textContent = year;
      $('academicYearInline').textContent = year;
      $('formYear').value = config.site?.academicYear || '';
    } catch {
      $('academicYear').textContent = '—';
      $('academicYearInline').textContent = '—';
    }
  }

  async function transcriptLink() {
    try {
      const j = await get('/api/site-content');
      const url = j.content?.transcriptUrl || '';
      const link = $('transcriptLink');
      if (url && url !== '..........................') {
        link.href = url;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.removeAttribute('aria-disabled');
      } else {
        link.href = '#';
        link.setAttribute('aria-disabled', 'true');
      }
    } catch {}
  }

  $('refresh').addEventListener('click', async () => {
    $('recordArea').innerHTML = '<p class="muted">Refreshing academic records…</p>';
    try { await load(); } catch (error) { $('recordArea').innerHTML = `<p class="error">${esc(error.message)}</p>`; }
  });

  $('subjectFilter').addEventListener('input', renderRecords);
  $('termFilter').addEventListener('change', renderRecords);
  $('printPage').addEventListener('click', () => window.print());

  $('loadTranscript').addEventListener('click', async () => {
    const button = $('loadTranscript');
    button.disabled = true;
    button.textContent = 'Loading…';
    try {
      const target = new URLSearchParams(location.search).get('studentId');
      const j = await get('/api/account/transcript' + (target ? `?studentId=${encodeURIComponent(target)}` : ''));
      const t = j.transcript;
      $('transcriptArea').innerHTML = `
        <div class="transcript-summary">
          <div class="transcript-summary-top"><span class="transcript-icon">▤</span><div><strong>${esc(t.school)}</strong><p>${esc(t.motto)}</p></div></div>
          <div class="transcript-meta-grid">
            <div><small>STUDENT</small><strong>${esc(t.student.name)}</strong></div>
            <div><small>ACCOUNT ID</small><strong>${esc(t.student.id)}</strong></div>
            <div><small>CLASS</small><strong>${esc(t.student.className || '—')}</strong></div>
            <div><small>DEPARTMENT</small><strong>${esc(t.student.department || '—')}</strong></div>
            <div><small>RECORDED SUBJECTS</small><strong>${t.records.length}</strong></div>
            <div><small>GENERATED</small><strong>${esc(formatDate(t.generatedAt))}</strong></div>
          </div>
          <p class="transcript-notice">${esc(t.notice)}</p>
          <button class="btn secondary" id="printTranscript" type="button">Print / Save Transcript as PDF</button>
        </div>`;
      $('printTranscript').addEventListener('click', () => window.print());
    } catch (error) {
      $('transcriptArea').innerHTML = `<p class="error">${esc(error.message)}</p>`;
    } finally {
      button.disabled = false;
      button.textContent = 'Open transcript summary';
    }
  });

  if (user.role === 'teacher' || user.role === 'admin' || user.role === 'super_admin') {
    $('entryCard').hidden = false;
    const sid = new URLSearchParams(location.search).get('studentId');
    if (sid) $('recordStudentId').value = sid;
  }

  $('recordForm').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector('button[type="submit"]');
    const fd = new FormData(form);
    const body = Object.fromEntries(fd.entries());
    if (body.score === '') body.score = null;
    button.disabled = true;
    $('formMessage').textContent = 'Saving…';
    try {
      const response = await fetch('/api/admin/academic/records', {
        method: 'POST', credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(body)
      });
      const json = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(json.error || 'Could not save the academic record.');
      $('formMessage').textContent = 'Academic record saved successfully.';
      form.reset();
      await site();
      await load();
    } catch (error) {
      $('formMessage').textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });

  try {
    await Promise.all([load(), site(), transcriptLink()]);
  } catch (error) {
    $('recordArea').innerHTML = `<div class="academic-empty"><span>!</span><div><strong>Academic centre could not load</strong><p class="muted">${esc(error.message)}</p><button class="btn" type="button" id="retryAcademic">Try again</button></div></div>`;
    $('retryAcademic')?.addEventListener('click', () => location.reload());
  }
})();
