const form=document.getElementById('searchForm');
const input=document.getElementById('searchInput');
const results=document.getElementById('results');
const count=document.getElementById('resultCount');
const facets=document.getElementById('facets');
const recent=document.getElementById('recentSearches');
const suggestions=document.getElementById('suggestions');
const typeSelect=document.getElementById('searchType');
const status=document.getElementById('searchStatus');
const webToggle=document.getElementById('webSearch');
let lastQuery='';

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
async function getJson(url){const r=await fetch(url,{credentials:'include'});const d=await r.json();if(!r.ok)throw Error(d.error||'Request failed');return d}

function renderFacets(f){
  facets.innerHTML='';
  Object.entries(f||{}).sort((a,b)=>b[1]-a[1]).forEach(([k,v])=>{
    const b=document.createElement('button'); b.type='button'; b.textContent=`${k} · ${v}`;
    b.onclick=()=>{ if(typeSelect.querySelector(`option[value="${CSS.escape(k)}"]`)){typeSelect.value=k;runSearch(lastQuery,1)} };
    facets.appendChild(b);
  });
}

function resultCard(x){
  const url=x.url?`<p><a href="${esc(x.url)}" ${String(x.url).startsWith('http')?'target="_blank" rel="noopener noreferrer"':''}>Open result →</a></p>`:'';
  return `<article class="search-result"><span class="result-kind">${esc(x.kind)}</span><div><strong>${esc(x.title)}</strong><small>${esc(x.subtitle||'')} · ${esc(x.collection||'')}</small>${url}</div></article>`;
}

function renderResults(d){
  count.textContent=`${d.total} result${d.total===1?'':'s'}`;
  status.textContent=d.webSearched?`Page ${d.page} of ${d.pages} · Web search enabled`:(d.total?`Page ${d.page} of ${d.pages}`:'No matches');
  renderFacets(d.facets);
  results.innerHTML=d.results?.length?d.results.map(resultCard).join(''):'<div class="empty-state">No matching results. Try another phrase or enable Search Internet.</div>';
  const pager=document.getElementById('pager');
  pager.innerHTML=d.pages>1?`<button ${d.page<=1?'disabled':''} id="prev">← Previous</button><span>${d.page}/${d.pages}</span><button ${d.page>=d.pages?'disabled':''} id="next">Next →</button>`:'';
  pager.querySelector('#prev')?.addEventListener('click',()=>runSearch(lastQuery,d.page-1));
  pager.querySelector('#next')?.addEventListener('click',()=>runSearch(lastQuery,d.page+1));
}

async function runSearch(q,p=1){
  q=q.trim();
  if(!q){results.innerHTML='<div class="empty-state">Type something to search.</div>';count.textContent='0 results';facets.innerHTML='';status.textContent='';return}
  lastQuery=q; results.innerHTML='<div class="empty-state">Searching St. Mary’s…</div>'; status.textContent=webToggle?.checked?'Searching school + internet…':'Searching school…';
  try{
    const d=await getJson(`/api/search?q=${encodeURIComponent(q)}&type=${encodeURIComponent(typeSelect.value)}&page=${p}&limit=20&web=${webToggle?.checked?'1':'0'}`);
    renderResults(d); loadRecent();
  }catch(e){results.innerHTML=`<div class="empty-state">Search unavailable: ${esc(e.message)}</div>`;status.textContent='Search error'}
}

form.addEventListener('submit',e=>{e.preventDefault();runSearch(input.value,1)});
typeSelect?.addEventListener('change',()=>lastQuery&&runSearch(lastQuery,1));
webToggle?.addEventListener('change',()=>lastQuery&&runSearch(lastQuery,1));

async function loadRecent(){
  try{
    const d=await getJson('/api/search/recent');
    recent.innerHTML=d.recent?.length?d.recent.map(x=>`<button type="button" data-q="${esc(x.q)}">${esc(x.q)}</button>`).join(''):'<span class="muted">No recent searches.</span>';
    recent.querySelectorAll('button').forEach(b=>b.onclick=()=>{input.value=b.dataset.q;runSearch(b.dataset.q,1)});
  }catch{recent.innerHTML=''}
}

let suggestionTimer;
input.addEventListener('input',()=>{
  clearTimeout(suggestionTimer);
  const q=input.value.trim();
  if(!q){suggestions.innerHTML='';return}
  suggestionTimer=setTimeout(async()=>{
    try{const d=await getJson('/api/search/suggestions?q='+encodeURIComponent(q));suggestions.innerHTML=(d.suggestions||[]).map(x=>`<option value="${esc(x.text)}">`).join('')}
    catch{suggestions.innerHTML=''}
  },120);
});

loadRecent();

const initialQuery=new URLSearchParams(location.search).get('q');if(initialQuery){input.value=initialQuery;runSearch(initialQuery,1)}
