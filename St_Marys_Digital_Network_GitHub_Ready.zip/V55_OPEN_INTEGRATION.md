# V55 — Open Integration & Testing

V55 connects the Content Studio person-creation flow to a development-only test identity switch. After Create Person, the new test account is selected and the browser opens `home.html` without requiring a password or sign-in.

## Open testing
- Authentication and role gates remain bypassed only in non-production testing mode.
- The login page automatically returns to the homepage in open testing.
- New Content Studio people can receive a test account without entering an initial password.
- The selected test identity is carried by a development-only cookie so account/profile/class flows can be tested as that person.
- Explicit role checks are bypassed only in open testing where needed for complete workflow testing.

## Safety boundary
This mode must not be exposed to real student data or used for production. Production startup continues to reject open access. A new production authentication/authorization system should be implemented after the pilot.
