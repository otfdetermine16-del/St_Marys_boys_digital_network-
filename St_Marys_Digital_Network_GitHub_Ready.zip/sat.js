/* V74 SAT Centre — original SAT-style practice engine. Not official College Board material. */
(() => {
  const bank = [
    {id:'m1',section:'Math',skill:'Linear equations',q:'A school club buys 8 notebooks at the same price each and pays GH₵96 in total. What is the price of one notebook?',options:['GH₵10','GH₵12','GH₵14','GH₵16'],answer:1,why:'Divide the total cost by 8: 96 ÷ 8 = 12.'},
    {id:'m2',section:'Math',skill:'Percent',q:'A test has 40 questions. A student answers 34 correctly. What percent of the questions were correct?',options:['75%','80%','85%','90%'],answer:2,why:'34/40 = 0.85, which is 85%.'},
    {id:'m3',section:'Math',skill:'Quadratics',q:'If x² − 9 = 0 and x is positive, what is x?',options:['−3','0','3','9'],answer:2,why:'x² = 9, so x = ±3. The positive solution is 3.'},
    {id:'m4',section:'Math',skill:'Systems',q:'If a+b=14 and a−b=4, what is a?',options:['5','7','9','10'],answer:2,why:'Adding the equations gives 2a=18, so a=9.'},
    {id:'m5',section:'Math',skill:'Functions',q:'For f(x)=3x−5, what is f(4)?',options:['7','9','12','17'],answer:0,why:'f(4)=3(4)−5=12−5=7.'},
    {id:'m6',section:'Math',skill:'Geometry',q:'A rectangle has length 12 cm and width 5 cm. What is its area?',options:['17 cm²','34 cm²','60 cm²','120 cm²'],answer:2,why:'Area = length × width = 12 × 5 = 60 cm².'},
    {id:'m7',section:'Math',skill:'Ratios',q:'The ratio of science books to history books is 3:2. If there are 25 books altogether, how many are science books?',options:['10','12','15','18'],answer:2,why:'There are 5 ratio parts. 25 ÷ 5 = 5, and 3 parts = 15.'},
    {id:'m8',section:'Math',skill:'Data',q:'The values 4, 7, 9, 10 and 15 have what median?',options:['7','8','9','10'],answer:2,why:'The middle value of the ordered list is 9.'},
    {id:'m9',section:'Math',skill:'Exponents',q:'What is 2³ × 2²?',options:['16','24','32','64'],answer:2,why:'Same base: add exponents, 2^(3+2)=2⁵=32.'},
    {id:'m10',section:'Math',skill:'Probability',q:'A bag contains 3 blue, 2 white and 5 black cards. One card is chosen at random. What is the probability of choosing a white card?',options:['1/10','1/5','2/5','1/2'],answer:1,why:'There are 10 cards total and 2 are white, so 2/10=1/5.'},
    {id:'r1',section:'Reading & Writing',skill:'Grammar',q:'Choose the option that correctly completes the sentence: The collection of science journals ___ on the top shelf.',options:['are','were','is','have been'],answer:2,why:'The subject is singular: collection. Therefore the verb is “is.”'},
    {id:'r2',section:'Reading & Writing',skill:'Transitions',q:'Mina wanted to join the debate team. ___, she practised speaking clearly every evening.',options:['However','Therefore','For example','Meanwhile'],answer:1,why:'The second sentence is a result of wanting to join the team, so “Therefore” fits.'},
    {id:'r3',section:'Reading & Writing',skill:'Punctuation',q:'Which sentence is punctuated correctly?',options:['After the meeting, the students returned to class.','After the meeting the students, returned to class.','After, the meeting the students returned to class.','After the meeting the students returned, to class.'],answer:0,why:'The introductory phrase “After the meeting” is correctly followed by a comma.'},
    {id:'r4',section:'Reading & Writing',skill:'Vocabulary',q:'In the sentence “The researcher was meticulous, checking each measurement twice,” meticulous most nearly means:',options:['careless','thorough','uncertain','impatient'],answer:1,why:'Meticulous means very careful and thorough.'},
    {id:'r5',section:'Reading & Writing',skill:'Main idea',q:'A passage explains that school gardens give students practical experience with plants while also supporting lessons in biology. Which choice best states the main idea?',options:['School gardens replace biology lessons.','School gardens can connect practical work with classroom learning.','Students should only study plants outdoors.','Biology is easier than other subjects.'],answer:1,why:'The statement captures both practical gardening and its connection to biology lessons.'},
    {id:'r6',section:'Reading & Writing',skill:'Agreement',q:'Neither the teacher nor the students ___ available after 4 p.m.',options:['is','was','are','has'],answer:2,why:'With “neither…nor,” the verb agrees with the nearer subject, students: “are.”'},
    {id:'r7',section:'Reading & Writing',skill:'Transitions',q:'The first experiment produced unexpected results. ___, the researchers repeated it using a larger sample.',options:['As a result','In contrast','For instance','Likewise'],answer:0,why:'Repeating the experiment followed from the unexpected result, so “As a result” fits.'},
    {id:'r8',section:'Reading & Writing',skill:'Precision',q:'Which word most precisely describes a plan that can realistically be carried out?',options:['feasible','decorative','temporary','random'],answer:0,why:'Feasible means possible and practical to carry out.'},
    {id:'r9',section:'Reading & Writing',skill:'Sentence boundaries',q:'Which choice correctly joins the two ideas? The library was crowded. Many students were preparing for exams.',options:['The library was crowded, many students were preparing for exams.','The library was crowded; many students were preparing for exams.','The library was crowded many students; were preparing for exams.','The library was crowded: and many students were preparing for exams.'],answer:1,why:'A semicolon correctly joins two closely related independent clauses.'},
    {id:'r10',section:'Reading & Writing',skill:'Evidence',q:'A writer claims that regular revision improves long-term recall. Which evidence would best support the claim?',options:['Students say revision feels boring.','A study finds students who revise regularly remember more after several weeks.','Some students prefer group work.','Revision notebooks can have colourful covers.'],answer:1,why:'The evidence directly measures revision frequency and later recall.'}
  ];

  const $ = id => document.getElementById(id);
  const state = {authorized:false, started:false, section:'Math', questions:bank.filter(q=>q.section==='Math'), index:0, answers:{}, submitted:false, seconds:15*60, timer:null};
  const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  function show(id,on=true){$(id)?.classList.toggle('sat-hidden',!on)}
  function setText(id,v){if($(id))$(id).textContent=v}
  function formatTime(s){const m=Math.floor(s/60),sec=s%60;return `${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`}
  function score(){return state.questions.reduce((n,q,i)=>n+(state.answers[q.id]===q.answer?1:0),0)}

  async function checkAccess(){
    try{
      const r=await fetch('/api/sat/access',{credentials:'same-origin'}),d=await r.json();
      state.authorized=!!d.authorized;
      show('sat-lock',!state.authorized); show('sat-workspace',state.authorized);
      setText('sat-access-state',state.authorized?'Access active':'Access required');
      if(state.authorized) initWorkspace();
    }catch{show('sat-lock',true);show('sat-workspace',false);setText('sat-lock-msg','The SAT access service is temporarily unavailable.')}
  }

  function start(section=state.section){
    state.section=section; state.questions=bank.filter(q=>q.section===section); state.index=0; state.answers={}; state.started=true; state.submitted=false; state.seconds=15*60;
    $('sat-workspace')?.scrollIntoView({behavior:'smooth',block:'start'}); render(); startTimer();
  }
  function startTimer(){clearInterval(state.timer);state.timer=setInterval(()=>{if(!state.started||state.submitted)return;state.seconds--;setText('sat-timer',formatTime(Math.max(0,state.seconds)));if(state.seconds<=0){state.submitted=true;clearInterval(state.timer);renderResult()}},1000)}
  function render(){
    const q=state.questions[state.index]; if(!q)return;
    setText('sat-section-title',q.section);setText('sat-skill',q.skill);setText('sat-number',`${state.index+1} / ${state.questions.length}`);setText('sat-timer',formatTime(state.seconds));
    $('sat-progress-bar').style.width=`${((state.index+1)/state.questions.length)*100}%`;
    $('sat-prompt').textContent=q.q;
    $('sat-options').innerHTML=q.options.map((o,i)=>`<button class="sat-option ${state.answers[q.id]===i?'selected':''}" data-choice="${i}"><span class="sat-letter">${String.fromCharCode(65+i)}</span><span>${esc(o)}</span></button>`).join('');
    $('sat-options').querySelectorAll('[data-choice]').forEach(b=>b.onclick=()=>{if(state.submitted)return;state.answers[q.id]=Number(b.dataset.choice);render()});
    const exp=$('sat-explanation');if(state.submitted){exp.innerHTML=`<strong>${state.answers[q.id]===q.answer?'Correct.':'Review this one.'}</strong> ${esc(q.why)}`;show('sat-explanation',true)}else show('sat-explanation',false);
    $('sat-prev').disabled=state.index===0;$('sat-next').textContent=state.index===state.questions.length-1?'Finish':'Next';
    $('sat-review').innerHTML=state.questions.map((x,i)=>`<button class="${state.answers[x.id]!==undefined?'answered':''} ${i===state.index?'current':''}" data-i="${i}">${i+1}</button>`).join('');$('sat-review').querySelectorAll('button').forEach(b=>b.onclick=()=>{state.index=Number(b.dataset.i);render()});
    setText('sat-answered',Object.keys(state.answers).length);setText('sat-total',state.questions.length);
    show('sat-result',false);show('sat-question-card',true);
  }
  function renderResult(){
    state.submitted=true;clearInterval(state.timer);const s=score(),total=state.questions.length,pct=Math.round(s/total*100);setText('sat-result-score',`${s}/${total}`);setText('sat-result-percent',`${pct}%`);setText('sat-result-time',formatTime(15*60-state.seconds));show('sat-result',true);show('sat-question-card',false);setText('sat-result-note',pct>=80?'Strong practice result. Review the missed questions and try a timed set again.':pct>=60?'Good progress. Focus on the skills behind the questions you missed.':'Keep practising. Use the explanations, then retake the section without rushing.');}
  function initWorkspace(){
    if($('sat-start-math'))$('sat-start-math').onclick=()=>start('Math');
    if($('sat-start-rw'))$('sat-start-rw').onclick=()=>start('Reading & Writing');
    $('sat-prev').onclick=()=>{if(state.index>0){state.index--;render()}};
    $('sat-next').onclick=()=>{if(state.index<state.questions.length-1){state.index++;render()}else renderResult()};
    $('sat-submit').onclick=()=>renderResult();$('sat-retry').onclick=()=>start(state.section);
    $('sat-change').onclick=()=>{state.started=false;show('sat-question-card',false);show('sat-result',false);show('sat-start-panel',true)};
    $('sat-start-panel').querySelectorAll('[data-section]').forEach(b=>b.onclick=()=>start(b.dataset.section));
    loadPdfs();
  }
  async function unlock(){
    const code=$('sat-code').value.trim();if(!code)return setText('sat-lock-msg','Enter the access code first.');setText('sat-lock-msg','Checking…');
    try{const r=await fetch('/api/sat/unlock',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({code})}),d=await r.json();if(!r.ok||!d.authorized)throw Error(d.error||'Access denied.');checkAccess()}catch(e){setText('sat-lock-msg',e.message||'Access denied.')}
  }
  async function loadPdfs(){
    try{const r=await fetch('/api/sat/pdfs',{credentials:'same-origin'}),d=await r.json();if(!r.ok||!d.ok)return;const box=$('sat-pdf-library');box.innerHTML=(d.pdfs||[]).map(x=>`<article><h3>${esc(x.title)}</h3><p class="sat-small">Protected school practice PDF</p><a href="${esc(x.url)}" target="_blank" rel="noopener">Open PDF ↗</a></article>`).join('')||'<p class="sat-small">No administrator-uploaded PDFs yet.</p>'}catch{}}

  $('sat-unlock')?.addEventListener('click',unlock);$('sat-code')?.addEventListener('keydown',e=>{if(e.key==='Enter')unlock()});
  checkAccess();
})();
