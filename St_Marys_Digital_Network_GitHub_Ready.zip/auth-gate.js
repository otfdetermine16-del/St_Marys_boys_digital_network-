/* Attach to protected pages when production routing is added. */
document.addEventListener('DOMContentLoaded',()=>{if(window.SMAuth){const s=SMAuth.getSession();const slot=document.querySelector('[data-auth-user]');if(slot)slot.textContent=s?s.name:'Guest';}});
