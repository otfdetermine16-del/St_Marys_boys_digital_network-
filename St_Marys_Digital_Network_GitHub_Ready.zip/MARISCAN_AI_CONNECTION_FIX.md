# MARISCAN AI Connection Fix

This release fixes the broken MARISCAN AI browser integration.

## What was wrong
- `ai.html` had JavaScript placed inside a `<script type="module" src="...">` tag. When a `src` is supplied, that inline body is not executed.
- The browser client only knew the Firebase API and therefore did not work correctly when the main Node server was being run locally.
- The image editing controls referenced elements that were not actually present in the page.

## What is fixed
- Firebase Auth loads before the MARISCAN client.
- MARISCAN automatically uses Firebase Cloud Functions when hosted on Firebase.
- MARISCAN falls back to the existing Network Node `/api/ai/query` backend during local testing.
- Web ON/OFF is sent to the correct backend.
- YouTube, PDF, image generation and image editing controls are wired to the Firebase backend.
- The status indicator reports backend availability.

## Internet requirement
The Firebase Cloud Function can use OpenAI's web-search tool, but the Firebase function must actually be deployed and the `OPENAI_API_KEY` secret must be configured. Code alone cannot publish a cloud backend.

## Deployment
From the project root:

    firebase login
    firebase use st-marys-digital-network
    cd functions
    npm install
    cd ..
    firebase functions:secrets:set OPENAI_API_KEY
    firebase functions:secrets:set YOUTUBE_API_KEY
    firebase deploy --only functions,hosting

Never place these secrets in HTML or browser JavaScript.
