# St. Mary's Digital Network V74.2 — Connected Backend Architecture

V74.2 now separates the browser frontend from the full Node backend correctly.

## Production request flow

Browser → Firebase Hosting →
- `/api/chat`, `/api/youtube`, `/api/image`, `/api/pdf` → Firebase Cloud Function `api` (MARISCAN AI)
- all other `/api/**` → Cloud Run service `st-marys-digital-network-api` (full school backend)
- `/media/**` and `/document/**` → Cloud Run service

The Cloud Run service runs `server.js`, so it provides the full school backend: accounts, Firebase identity bridge, classes, academics, Connect, clubs, houses, alumni, media, PTA, suggestions, notifications, search, admin APIs and related routes.

## Important production requirements

1. PostgreSQL must be configured with `ST_MARYS_DB_PROVIDER=postgres` and `DATABASE_URL`.
2. `NODE_ENV=production`.
3. `ST_MARYS_DEV_OPEN_ACCESS=false`.
4. `SESSION_SECRET` must be at least 32 characters.
5. `ST_MARYS_ADMIN_API_TOKEN` must be configured.
6. Firebase Admin token verification is enabled in `/api/auth/firebase-sync`.
7. MARISCAN AI requires Firebase Function secrets `OPENAI_API_KEY` and, for YouTube search, `YOUTUBE_API_KEY`.

## Deploy the full backend

From this project root in Google Cloud Shell:

```bash
gcloud config set project st-marys-digital-network
gcloud run deploy st-marys-digital-network-api \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars NODE_ENV=production,ST_MARYS_DEV_OPEN_ACCESS=false,ST_MARYS_DB_PROVIDER=postgres \
  --set-env-vars ST_MARYS_ADMIN_API_TOKEN=REPLACE_WITH_A_LONG_RANDOM_TOKEN \
  --set-env-vars SESSION_SECRET=REPLACE_WITH_A_LONG_RANDOM_SECRET \
  --set-env-vars DATABASE_URL=REPLACE_WITH_YOUR_POSTGRES_CONNECTION_STRING
```

For production, store sensitive values in Secret Manager instead of putting them directly in the command line. The Cloud Run service must be publicly invokable because Firebase Hosting performs the API rewrite, while the application itself enforces authentication and authorization.

## Deploy Firebase Hosting + MARISCAN AI

```bash
firebase use st-marys-digital-network
firebase functions:secrets:set OPENAI_API_KEY
firebase functions:secrets:set YOUTUBE_API_KEY
firebase deploy --only functions,hosting
```

## Verify

```bash
curl -i https://YOUR_FIREBASE_HOST/api/health
```

Then sign in through the website and verify that `/api/me` returns the authenticated school account. MARISCAN AI should then use the Firebase Function path, while school features use the Cloud Run backend.

## Media note

The current school-media implementation stores uploaded files on the backend filesystem. Cloud Run filesystems are ephemeral. For long-term production media persistence, the next backend hardening step should move uploaded media/documents to Cloud Storage or Firebase Storage.
