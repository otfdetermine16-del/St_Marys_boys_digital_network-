# V31 — Public Configuration, Branding & Access Hardening

V31 builds on V30. It adds a public `/api/site-config` endpoint, makes branding work without administrator authentication, allows explicitly-public media to be served to guests while protecting school/private media, uses the official crest in the retractable navigation, and enables Secure cookies automatically in production.

This remains a development prototype. Production deployment still requires a real database, durable object storage, HTTPS, CSRF protection, rate limiting, MFA, secret management, monitoring, backups, migrations and security testing.

# St. Mary's Boys Digital Legacy — V2 Prototype

This version adds the foundation for three controlled experiences: Student Hub, Teacher Centre and Administration.

## Important
This is still a static prototype. Do not place real student records, passwords, phone numbers, grades or confidential school data in it.

## Next engineering stage
Connect a secure backend/database with authentication, role-based access control, audit logs, backups, content management, media moderation and a formal school-admin handover process.

## V3 additions
- Added a dedicated Leadership & Houses section.
- Current School Prefect: Philip Zato.
- Current Assistant School Prefect: Micheal Ewuenzi.
- Added the eight prefect-role groups with editable name slots.
- Added eight editable house-name slots; names intentionally remain blank/pending confirmation.
- Added an Admin Command Centre editor for prefect and house-name drafts.
- Prototype drafts use browser localStorage only. Production must replace this with secure server-side authentication, database persistence, permissions, audit logs and backups.

## V4 additions — School Network & Role Workspaces
- Added `network.html` with three publishing channels: Student Information Board, Official School News, and Prefect Information Board.
- Added `prefect-centre.html` for the private prefect command centre.
- Expanded Student Hub with personal publishing areas.
- Expanded Teacher Centre with official publishing and private department workspace concepts.
- Added prototype local student-post submission flow in `network.js`.
- Production requirement: authentication, authorization, moderation, audit logs, database storage and privacy controls must be server-side.

## V5 — Social Foundation + Club Community
- Added a school-feed prototype with likes, comments and share action.
- Added a dedicated Young Aviators Club community page.
- Added membership-request flow with leader-approval architecture.
- Added founder/leadership legacy architecture so founders remain historical records when leadership changes.
- The school crest remains the platform identity and is used for the social avatar in this prototype.
- IMPORTANT: browser localStorage is demonstration-only. Production requires real authentication, database storage, server-side authorization, moderation, audit logs, notifications and secure file storage.


## V7 — Student Hub + Enhancement Pass
Added:
- dedicated `student-hub.html`
- student identity/academic profile overview
- assignments/tasks with working demo completion buttons
- notifications with working mark-as-read buttons
- club membership display
- links to class, school network, club and Digital Legacy areas
- responsive, moderate sizing across desktop/mobile
- accessible button/status behavior
- client-side demo state in `localStorage` only

Enhancement principles:
- no oversized dashboard elements
- no tiny text/buttons
- visual hierarchy: hero > core cards > secondary actions
- every V7 interactive button has a defined demo behavior
- production must replace localStorage with secure server-side authentication, authorization, database and audit logging

## V8 enhancements: Help & Settings, IT Control Centre, aviation navigation and annual review workflow.

## V9 — School Entry, Identity & Creator Story
- Added `index.html` as the designated first-entry welcome page.
- Added `home.html` as the main public school homepage.
- Added `creator-story.html` as the designated Creator's Story page.
- Added `assets/campus-entrance.jpg` (cropped from the supplied campus image) and `assets/crest-lively.jpg` (cropped from the supplied crest image) for cleaner presentation.
- Settings is now a top-right control; Help, About, Creator's Story and annual review information are accessed through Settings rather than displayed as permanent floating prompts.
- Reduced explicit aviation wording while retaining a subtle precision/navigation-inspired interface.
- Removed the floating Young Aviators shortcut from the public homepage to reduce visual crowding.
- Creator biography is intentionally an editable narrative draft with a placeholder name/photo so no personal facts are invented; final identity details can be entered later by an authorized administrator.
- Production reminder: authentication, database, server-side permissions, moderation, secure storage and monitoring are still required before real school deployment.

## V9.5 — Interface & Navigation Foundation

This refinement pass is intentionally focused on reducing visual clutter before deeper platform development.

- Official platform name is now **St. Mary's Digital Network**.
- `index.html` is the dedicated first-entry screen with a full-screen St. Mary's campus/entrance image, centered official crest, dark-blue platform title and entry button.
- A global loading transition now appears before pages are shown: a small plane orbits a circular indicator while the page prepares, then the interface fades in rather than sliding upward.
- The previous persistent bottom navigation dock has been removed to create a cleaner, more familiar information hierarchy.
- The public homepage navigation is simplified into primary destinations plus a small More menu.
- Settings remains top-right and contains Help, About, Creator's Story, annual review information and restricted IT access. These supporting panels are not displayed until Settings is opened.
- Student Hub was redesigned around a clear welcome area, quick access, student overview, tasks, notifications, profile and clubs.
- The Student Hub no longer places Settings or unrelated controls below the main student content.
- Aviation is now a subtle interaction/design influence rather than a visible theme.

The platform is still a prototype. Secure authentication, server-side authorization, database storage, audit logs, monitoring, backups and real file handling remain part of the engineering volumes.

## V10.1 — Navigation & Interaction Reliability
- Replaced page-transition movement with a centered plane loader followed by an in-place opacity appearance.
- Home navigation is a real page navigation rather than an in-page `#home` scroll.
- Added interface reliability feedback for prototype controls so unfinished features respond honestly instead of appearing dead.
- Added consistent hover, focus and active states across links and buttons.
- Class-space placeholder controls now respond with clear explanations rather than being disabled/dead.
- Young Aviators Club homepage link now opens the club page.
- Added an interface transition layer without pretending prototype-only backend features are production-ready.


## V11 — Unified Design & Navigation
- Renamed the community layer from “Maryan Space” to **St. Mary's Connect**.
- Added `connect.html` as the clear community entry point.
- Kept `network.html` as the underlying publishing/community workspace prototype.
- Standardized user-facing references to avoid the Maryan label.
- Prototype remains local/demo only; production requires secure backend, authentication, permissions, database, moderation and audit logging.

## V12 — Data Architecture
- Added `data-schema.js` defining the core entities and relationships for the production platform.
- Added `data-store.js` as a clearly labelled local prototype store for architecture testing; it is not secure production storage.
- Added `data-architecture.html` as the engineering/data map for the Network.
- Added privacy-by-design visibility levels: Public, School-only, Class-only and Private.
- Added the architecture entry point to Content Studio.
- The model separates people from accounts and roles, separates academic years from classes, preserves club founder history, and gives content records stable relationships.
- V13 can now implement real authentication and authorization against this model.


## V13 — Authentication & Backend Foundation
V13 introduces the first backend-capable architecture.
- `server.js` is a dependency-free Node.js development server.
- `server-data.json` is created on first server start and stores demo users/audit events.
- `/api/login`, `/api/me`, `/api/logout`, `/api/users` and `/api/health` provide the initial API surface.
- `login.html` is the sign-in entry point.
- Protected prototype pages now have role gates.
- Demo accounts are synthetic test identities only; do not use them as real school accounts.

### Run locally
1. Install Node.js.
2. From this folder run `node server.js`.
3. Open `http://localhost:3000/login.html`.

### Production warning
This is a foundation, not production authentication. A real deployment must use HTTPS, secure password hashing such as Argon2/bcrypt through a maintained auth system, a real database, secure secrets, CSRF/session protections, rate limiting, account recovery, MFA where appropriate, server-side authorization and audited backups. Never place real student credentials in the static prototype.

## V14 — Management Engine
V14 begins the server-side management layer. Run `node server.js`, then open `http://localhost:3000/`. The Admin Studio now uses authenticated API routes for people, classes, clubs, summary data and audit logs. The development database is `server-data.json` and is not production-ready.

Development accounts are included for testing only. Do not enter real student passwords or private school records into this build.

## V16 — Search + Notifications
- Permission-aware unified `/api/search` endpoint.
- Authenticated notifications list/read state.
- Teacher/admin/prefect notification creation endpoint.
- Search and Notifications interfaces.
- Development demo notifications only; production requires school-managed data.
- Sensitive/private and unauthorized class records are excluded from search results.

## V17 — Clubs, Houses & Achievements
Fixed the V16 native-Node route integration: V16 API routes are now implemented inside the native `http.createServer` handler rather than using undefined Express `app` routes.
Added authenticated clubs, membership requests/approval, houses, achievements, and community interface.

## V18 — Digital Heritage + Alumni & Legacy
V18 fixes the V17 health/version mismatch and adds authenticated heritage and alumni APIs/pages. Heritage records include era/year, category, description, media reference, visibility and source note. Alumni records support public-profile privacy. Administrator endpoints support creating/updating/archiving heritage, alumni, houses and achievements. This remains a development build: production needs a real database, HTTPS, stronger session handling, backups, moderation and formal school governance.


## V19 — Media & Document Infrastructure
V19 adds authenticated media browsing, administrator-managed media uploads, PDF document storage, archive/metadata controls, and dedicated Media Centre / Media Administration pages. Uploads are stored outside the public source tree under `uploads/` and served through permission-aware routes. Development upload limit: 12 MB per asset. Production should use object storage, malware scanning, quotas, processing, signed URLs, backups and a managed database.


## V21 — Unified Account & Branding
- Added `account.html` for authenticated account details, password changes and sign-out.
- Added administrator `branding-admin.html` for replacing the website hero image through the backend.
- Added `/api/account/password` and `/api/admin/branding`.
- Existing role-based login remains the single entry/unlock point.
- Branding uploads are stored under the managed media directory and logged.
- Production still requires HTTPS, CSRF protection, rate limiting, secure session storage, a production database, encrypted backups and a mature identity provider.

## V23 — Unified UX + Retractable Navigation
- Restored the main navigation as a retractable bottom dock.
- Navigation appears on interaction and automatically retracts after 2 seconds of inactivity.
- It can also be manually hidden/reopened.
- The platform remains one website with shared account, backend and role-aware workspaces.


## V24 — Reliability + SAT Practice
The SAT Practice Centre is protected by authenticated accounts and an administrator-controlled access code. The code is stored as a hash; rotating it increments the code version and invalidates every previous grant. For real paid access, add payment/entitlement records, rate limiting, CSRF protection, question-bank management and reporting before launch.


## V26 SAT Practice Library
- Ten original SAT practice PDFs are stored under private/sat-pdfs/.
- PDF listing and delivery require active SAT authorisation.
- Rotating the SAT access code invalidates previous grants.
- Official Khan Academy and College Board practice links are included.


## V28 Master Account
A development-only super-admin account is provisioned server-side with the requested master ID. Its password is stored only as a salted scrypt hash, never in plaintext. The role `super_admin` is accepted by administrator APIs and management surfaces. Change the password before any real deployment and move the credential into a production secret manager.

## V32 — Unified Identity
- Added server-authoritative `/api/account/profile` GET/PATCH for self-service display identity.
- Added `/api/admin/accounts` and `/api/admin/accounts/:id` for administrator account governance.
- Added `identity.html` / `identity.js` identity centre.
- Added Identity tab to Content Studio.
- Master/super-admin account remains protected from ordinary admin role/status changes.
- Official school identifiers and assignments remain administrator-controlled.


## V33 — Real Class Ecosystem
- Provisions the current 63-class structure: Science 6, General Arts 6, Visual Arts 5, Agriculture 2, Business 2 per SHS level.
- Server-backed class membership and access control.
- Class-specific roles: teachers, form master, class captain and students.
- Class join-code issuing/rotation with server-side hashed codes.
- Protected class space for timetable, duty roster, announcements, resources, assignments, documents, achievements, gallery and events.
- Dedicated `class-admin.html` for authorized administrators to assign teachers/captains/form masters and rotate join codes.
- Audit logging for class joins, publishing and management changes.
- Class counts remain editable; the generated 63 classes are a starting structure, not a permanent hard-coded limit.
- Development note: the JSON database remains a prototype store; production deployment still requires a real database, HTTPS, secure secrets, rate limiting, CSRF protection and stronger identity/recovery controls.


## V34 — Academic Records & Transcript Foundation
- Added protected student academic records and transcript-summary APIs.
- Students can view only their own academic history; authorised teachers can access records for students in classes they teach/manage; administrators retain full academic governance.
- Added result entry with validation for academic year, term, subject, score, grade and remarks.
- Duplicate subject/term/year records are rejected to prevent accidental double entry.
- Added administrator subject catalogue foundation.
- Added `academic.html` / `academic.js` for the protected Academic Records centre.
- Added audit logging for academic record creation, updates and deletion.
- Transcript output is explicitly marked as a development view; official school transcripts must be verified and issued by authorised school personnel.
- Production requirement remains: move academic data to a managed database with encryption, backups, fine-grained permissions, audit retention and formal school governance.

## V35 — MARISCAN AI
- Added authenticated, permission-aware MARISCAN AI school knowledge assistant.
- `GET /api/ai/status`, `POST /api/ai/query`, and administrator AI configuration routes.
- Current provider is local/verified knowledge mode; no external AI API key is required.
- Answers are deliberately conservative and refuse credential/private-data disclosure.
- Added `ai.html` and `ai.js` and MARISCAN AI to the school navigation.
- Future production integration can add a real model provider + retrieval/RAG layer behind the same boundary without exposing school data directly to the browser.

## V35.1 Founder Access Shortcut
- Added a small `+` button to the top-right of password/access-code interfaces (`login.html`, `sat.html`, `sat-practice.html`).
- The shortcut opens a Founder Access dialog and accepts the configured founder verification name `SHAIBU.a` (case-insensitive).
- Server endpoint: `POST /api/master-access`.
- The shortcut is explicitly disabled when `NODE_ENV=production`; production should replace it with a real second factor/secret rather than name-only access.
- A successful founder session is treated as `super_admin`; SAT access also recognizes the active master session without requiring the SAT code.

## V36 — PTA & Parent Partnership
- Added authenticated PTA/parent partnership foundation.
- Added moderated PTA posts and administrator moderation endpoints.
- Added scheduled PTA meeting records.
- Added administrator PTA settings and audit logging.
- Added `pta.html` school/parent notice board interface.
- Health/version is V36.
- Production hardening still required: real parent identity verification, consent/privacy controls, notifications, rate limiting, managed DB, CSRF protection and school UAT.

## V37 — Universal Search 2.0
V37 upgrades school search with ranked results, search-type filters/facets, pagination, recent searches, suggestions, class-aware permission filtering, and server-side visibility checks across people, classes, learning content, clubs, events, achievements, heritage, documents and PTA posts. Search history is development data and should move to a managed database in production.


## V38 — Notifications 2.0
- Added permission-aware notification targeting for all users, individual users, roles, departments and authorised classes.
- Added scheduling and expiry metadata; future notifications remain hidden until their scheduled time.
- Added priority levels: low, normal, high and urgent.
- Added unread-count endpoint and mark-all-read workflow.
- Added admin notification listing and audit records for broadcasts/read-all actions.
- Upgraded `notifications.html` with filters and priority indicators.
- Background email/push/SMS delivery remains a future queue/worker responsibility; this release keeps user-facing notification creation synchronous and local.


## V38.1 — Security Recognition Foundation
- Added HTTP Bearer authentication for machine/API administration.
- Added `GET /admin/settings` protected by a Bearer token.
- Production token is supplied through `ST_MARYS_ADMIN_API_TOKEN`; no real token is hard-coded in source.
- Uses constant-time comparison (`crypto.timingSafeEqual`) after equal-length checking.
- Browser session authentication remains separate and unchanged.
- The endpoint returns only non-secret administrative configuration; credentials are never returned.


## V40 — Publishing Engine
- Official publishing workflow: draft → in_review → approved → scheduled/published → archived.
- Audience targeting: public, school, role, class, department.
- Author/reviewer separation and audit events.
- Expiry and scheduling fields.
- Public publishing page and authenticated Publishing Studio.

## V41 — St. Mary's Connect Community Board
- Server-backed Community Board posts replace localStorage social publishing.
- Student submissions enter moderation; administrators can publish/reject.
- Published posts can be taken down only by admin/super_admin.
- Attachments: up to 5 per post, 5 MB each (JPEG/PNG/WEBP/PDF/TXT).
- School crest is used automatically for community post avatars.
- Likes are unique per authenticated account; repeat likes are rejected server-side.
- Comments can be submitted repeatedly by authenticated users.
- Community posts and attachments are permission-aware and audit logged.

## V42 — Clubs, Houses & Activities 2.0
- Unified school-life module for clubs, houses, sports, competitions, service and societies.
- Added server-managed activities and preserved club-leadership records.
- Founder records cannot be overwritten once established.
- Added activities.html and activities.js.
- Added admin endpoints for activity CRUD and advanced club leadership assignment.
- Existing club membership and house governance remain compatible.


## V42.1 — Club adjustment + development-open mode
- Retired Geography Club and Wildlife Club.
- Replaced Cadet & Taekwondo with CADET CORP AND REGIMENTAL BAND.
- Development mode intentionally bypasses authentication/authorization and Bearer/SAT gates for build/testing convenience.
- Production mode keeps the security architecture enabled; set NODE_ENV=production before deployment.
- This open mode is not a production security configuration.


## V42.3 — Development Open Mode

While the platform is being built locally, sign-in and browser role gates are bypassed in development mode and requests resolve to the master development session. This mode is automatically disabled in production (`NODE_ENV=production`) and must never be used for public deployment.

## V44 — Real Database Architecture
- Added a PostgreSQL production database target with migration `database/migrations/001_initial.sql`.
- Added `db.js` adapter with PostgreSQL pooling, health reporting and migration execution.
- JSON storage remains available only as the development fallback.
- Added `/api/admin/database` for authorized database health/migration status.
- Added relational foundations for accounts, classes, memberships, academic records, Connect posts/likes/comments, media and audit events.
- Production should set `ST_MARYS_DB_PROVIDER=postgres` and `DATABASE_URL`, install dependencies, run migrations, and remove development seed data before launch.

## V45 — Infrastructure & Scale
- Infrastructure health/readiness/metrics endpoints.
- Request IDs and basic response metadata.
- In-memory cache and queue adapters for development.
- Production adapter flags for Redis/queue infrastructure.
- Load-balancer, CDN/edge, replication and sharding readiness indicators.
- Graceful SIGTERM/SIGINT shutdown handling.
- Development-open security mode remains active; production security is preserved for deployment.

## V46 — Testing Laboratory

The current build includes an isolated automated testing laboratory. Run `npm test` to validate core APIs, school data structures, Connect moderation/interaction rules, infrastructure endpoints, static references and production-security gating without mutating the normal development data file.

## V49 GitHub readiness
The repository is prepared for connection to GitHub. See `GITHUB_PUSH.md` for the safe first-push procedure. No personal GitHub remote, credential, token, or production secret is embedded in this build.
