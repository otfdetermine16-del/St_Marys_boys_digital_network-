# V52 — Production Internet Launch

V52 is the production launch gate built on V51.

## What changed
- Production environment validation happens before the server starts.
- Production requires PostgreSQL, `DATABASE_URL`, strong `SESSION_SECRET`, and an admin API token.
- Development-open access is rejected in production.
- `/api/ready` performs a live PostgreSQL readiness check.
- `/api/deploy/status` reports the current launch gate without exposing secrets.
- Production security headers/CSP/HSTS are applied centrally.
- Static assets receive safe content-type and caching headers.
- Deployment startup runs migrations and verifies the database before serving traffic.
- Render/Docker deployment remains supported.

## Required production environment
```text
NODE_ENV=production
ST_MARYS_DEV_OPEN_ACCESS=false
ST_MARYS_DB_PROVIDER=postgres
DATABASE_URL=<managed PostgreSQL connection string>
SESSION_SECRET=<32+ random characters>
ST_MARYS_ADMIN_API_TOKEN=<strong random token>
```

## Launch sequence
1. Push the repository to GitHub.
2. Create a managed PostgreSQL database and web service.
3. Configure the production environment variables in the host's secret manager.
4. Run `npm run deploy:preflight`.
5. Start with `npm run start:production`.
6. Verify `/api/health` and `/api/ready`.
7. Verify HTTPS and the public domain.
8. Do **not** add real student data until V53's controlled pilot.

## Important
V52 does not claim that the site is live. A real deployment requires a hosting account, database connection and domain/DNS configuration.
