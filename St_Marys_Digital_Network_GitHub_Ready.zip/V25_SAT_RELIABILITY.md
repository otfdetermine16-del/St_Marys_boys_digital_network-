# V25 — SAT Access Reliability Fix

This checkpoint fixes the SAT access routes that were accidentally written for a different server framework in V24.

## What was fixed
- SAT routes now use the project's native Node.js request handler.
- Authentication uses the existing HttpOnly session system.
- SAT access grants are tied to a code version.
- Rotating the SAT code immediately invalidates every previous grant.
- SAT codes are stored as salted hashes, not plaintext.
- SAT access and unlock actions are audited.
- The backend health endpoint now reports V25.

## Verified locally
1. Server health returns V25.
2. Unauthenticated SAT access is rejected.
3. Admin can rotate a SAT access code.
4. Student starts locked.
5. Student can unlock with the current code.
6. Student remains authorised after unlock.
7. Rotating the code invalidates the student's previous grant.
8. The previous code is rejected.

## Still deliberately not production-ready
- SAT PDFs are not yet generated or exposed through a protected file route.
- The development database is JSON-based.
- Production needs a persistent database, stronger session storage, HTTPS, CSRF protection, rate limiting, monitoring, and secure secret management.
