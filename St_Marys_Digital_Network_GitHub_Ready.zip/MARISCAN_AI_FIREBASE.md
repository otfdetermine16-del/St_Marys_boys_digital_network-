# MARISCAN AI — Firebase Cloud Backend (V60)

MARISCAN AI now has a Firebase Hosting + Cloud Functions backend with server-side secrets.

## Endpoints
- GET `/api/health`
- POST `/api/chat` — authenticated AI chat, optional live web search
- POST `/api/search` — authenticated live web search
- POST `/api/youtube` — authenticated YouTube Data API search
- POST `/api/image` — authenticated image generation/editing
- POST `/api/pdf` — authenticated PDF creation

All API requests require a Firebase ID token in `Authorization: Bearer <token>`.

## Secrets
From the project root:

```bash
firebase functions:secrets:set OPENAI_API_KEY
firebase functions:secrets:set YOUTUBE_API_KEY
```

The keys are never placed in HTML or browser JavaScript. Firebase documents Secret Manager binding for Cloud Functions and supports Node.js 22. citeturn0search0turn0search1

## Deploy

```bash
npm install -g firebase-tools
firebase login
cd functions && npm install && cd ..
firebase deploy --only functions,hosting
```

The Hosting rewrite sends `/api/**` to the `api` Cloud Function in `us-central1`.

## OpenAI web access
MARISCAN uses the OpenAI Responses API's built-in `web_search` tool when Web mode is enabled, rather than exposing a search API key to the browser. OpenAI's current documentation shows web search as a built-in Responses API tool and the official JavaScript SDK is used server-side. citeturn1search0turn1search1

## Important
The code is integrated and deployment-ready, but the backend is **not online until `firebase deploy` is run** and the required secrets are configured. Firebase Cloud Functions deployment and Node.js 22 are supported by Firebase. citeturn0search3turn0search1
