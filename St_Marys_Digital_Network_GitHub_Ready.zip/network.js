(function(){
const key='sm_student_posts_v4';
const form=document.getElementById('studentPostForm'); const feed=document.getElementById('studentPosts');
function posts(){try{return JSON.parse(localStorage.getItem(key)||'[]')}catch(e){return[]}}
function render(){const data=posts(); feed.innerHTML='<h3 style="margin-top:26px">Recent local submissions</h3>'+(data.length?data.map(p=>`<article class="post-item"><div class="post-meta"><span>${p.type}</span><span>Pending review</span></div><h3>${esc(p.title)}</h3><p>${esc(p.body)}</p><small class="muted">Submitted ${new Date(p.createdAt).toLocaleString()}</small></article>`).join(''):'<div class="empty">No student submissions yet. Your first post will appear here as a local prototype submission.</div>')}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
form.addEventListener('submit',e=>{e.preventDefault();const data=posts();data.unshift({type:studentType.value,title:studentTitle.value.trim(),body:studentBody.value.trim(),createdAt:new Date().toISOString()});localStorage.setItem(key,JSON.stringify(data.slice(0,20)));form.reset();render();alert('Prototype submission saved locally. In production it would enter the moderation queue.')});render();
})();
