
/* St. Mary's Digital Network — V7 Student Hub
   Prototype data/UI layer. Production authentication, permissions,
   profile privacy, uploads and notifications must be server-side.
*/
(function () {
  "use strict";

  const STORAGE = "sm_student_hub_v7";

  const defaultState = {
    profile: {
      id: "SMB-DEMO-001",
      name: "Demo Student",
      department: "Science",
      year: "SHS 2",
      className: "Science 2A",
      bio: "Student profile preview",
      clubs: ["St. Mary's Young Aviators Club"],
      achievements: []
    },
    notifications: [
      { id: 1, title: "Welcome to the Student Hub", text: "Your school dashboard is ready.", read: false },
      { id: 2, title: "Class space", text: "Your class resources and announcements appear here.", read: false }
    ],
    tasks: [
      { id: 1, title: "Physics revision", subject: "Physics", due: "Demo deadline", status: "Open" },
      { id: 2, title: "Mathematics practice", subject: "Elective Mathematics", due: "Demo deadline", status: "Open" }
    ]
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function load() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE)) || clone(defaultState);
    } catch (_) {
      return clone(defaultState);
    }
  }

  function save(state) {
    localStorage.setItem(STORAGE, JSON.stringify(state));
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => ({
      "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
    }[ch]));
  }

  function render() {
    const state = load();
    const p = state.profile;

    const set = (id, value) => {
      document.querySelectorAll(`#${id}`).forEach(el => { el.textContent = value; });
    };

    set("hub-name", p.name);
    set("hub-department", p.department);
    set("hub-year", p.year);
    set("hub-class", p.className);
    set("hub-id", p.id);
    set("hub-bio", p.bio);

    const clubs = document.getElementById("hub-clubs");
    if (clubs) clubs.innerHTML = p.clubs.length
      ? p.clubs.map(c => `<span class="v10-club">${escapeHtml(c)}</span>`).join("")
      : `<span class="v10-muted">No approved clubs yet.</span>`;

    const tasks = document.getElementById("hub-tasks");
    if (tasks) tasks.innerHTML = state.tasks.length ? state.tasks.map(t => `
      <article class="v10-task">
        <div><strong>${escapeHtml(t.title)}</strong><small>${escapeHtml(t.subject)} · ${escapeHtml(t.due)}</small></div>
        <button data-task="${t.id}">${escapeHtml(t.status)}</button>
      </article>
    `).join("") : `<p class="v10-muted">No assignments right now.</p>`;

    const notices = document.getElementById("hub-notifications");
    if (notices) notices.innerHTML = state.notifications.length ? state.notifications.map(n => `
      <article class="v10-notice ${n.read ? "is-read" : ""}">
        <div><strong>${escapeHtml(n.title)}</strong><small>${escapeHtml(n.text)}</small></div>
        <button class="v7-small-button" data-notice="${n.id}">${n.read ? "Read" : "Mark read"}</button>
      </article>
    `).join("") : `<p class="v10-muted">You're all caught up.</p>`;

    document.querySelectorAll("[data-task]").forEach(btn => {
      btn.addEventListener("click", () => {
        const item = state.tasks.find(t => String(t.id) === btn.dataset.task);
        if (item) {
          item.status = item.status === "Completed" ? "Open" : "Completed";
          save(state); render();
        }
      });
    });

    document.querySelectorAll("[data-notice]").forEach(btn => {
      btn.addEventListener("click", () => {
        const item = state.notifications.find(n => String(n.id) === btn.dataset.notice);
        if (item) { item.read = true; save(state); render(); }
      });
    });

    const count = state.notifications.filter(n => !n.read).length;
    set("hub-notification-count", count);
    set("hub-notification-count-2", count);
    set("hub-task-count", state.tasks.filter(t => t.status !== "Completed").length);
    set("hub-year-stat", p.year);
    set("hub-class-stat", p.className);
    set("hub-class-2", p.className);
    set("hub-year-2", p.year);
  }

  window.StudentHubV7 = { load, save, render };
  document.addEventListener("DOMContentLoaded", render);
})();
