/* V74.3: synchronize only safe browser assets into Firebase Hosting's public tree. */
const fs=require('fs'),path=require('path');
const root=__dirname, publicDir=path.join(root,'public');
const ignoredDirs=new Set(['public','node_modules','.git','.firebase','private','uploads','functions','tests','database','scripts']);
const ignoredFiles=new Set(['server.js','backend-core.js','db.js','package.json','firebase.json','server-data.json','server-data.example.json','render.yaml','Dockerfile','.dockerignore','.firebaserc','build-public.js']);
const allowed=/\.(html|js|css|json|svg|jpg|jpeg|png|webp|ico|webmanifest)$/i;
function walk(dir,rel=''){
  for(const name of fs.readdirSync(dir,{withFileTypes:true})){
    if(ignoredDirs.has(name.name)||ignoredFiles.has(name.name)||name.name.startsWith('.'))continue;
    const abs=path.join(dir,name.name),r=path.join(rel,name.name);
    if(name.isDirectory())walk(abs,r);
    else if(allowed.test(name.name)){
      const out=path.join(publicDir,r);fs.mkdirSync(path.dirname(out),{recursive:true});fs.copyFileSync(abs,out);
    }
  }
}
fs.rmSync(publicDir,{recursive:true,force:true});fs.mkdirSync(publicDir,{recursive:true});walk(root);console.log('V74.3 public tree synchronized without backend/secrets.');
