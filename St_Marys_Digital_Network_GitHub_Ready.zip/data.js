window.SM_DATA={
 school:{name:"St. Mary's Boys' Senior High School",motto:"Disce Ut Doceas",location:"Apowa, near Takoradi, Western Region, Ghana"},
 departments:["Science","General Arts","Visual Arts","Business","Agriculture"],
 clubs:["St. Mary's Young Aviators Club","DRAMAS, WRITERS & DEBATORS CLUB","Maths & Science Club","CADET CORP AND REGIMENTAL BAND"],
 leadership:{
   schoolPrefect:{role:"School Prefect",name:"Philip Zato"},
   assistantSchoolPrefect:{role:"Assistant School Prefect",name:"Micheal Ewuenzi"},
   otherRoles:[
     {role:"SRC Prefect",count:1},
     {role:"Protocol Prefect",count:2},
     {role:"Compound Prefect",count:3},
     {role:"Studies Prefect",count:2},
     {role:"Agric Prefect",count:2},
     {role:"Science Lab Prefect",count:2},
     {role:"ICT Lab Prefect",count:2},
     {role:"Infirmary Prefect",count:2}
   ]
 },
 houses:Array.from({length:8},(_,i)=>({id:i+1,name:"House "+(i+1),status:"active",description:"House information is maintained by the Master Administrator.",motto:"Administrator to set",captain:"",viceCaptain:"",colour:"",history:"",achievements:[]})),
 demoStudents:[{id:'SMB-DEMO-001',name:'Demo Student',level:'SHS 2',department:'Science',clubs:["St. Mary's Young Aviators Club","Maths & Science Club"],achievements:['Academic profile ready','Club participation record']}]
};
