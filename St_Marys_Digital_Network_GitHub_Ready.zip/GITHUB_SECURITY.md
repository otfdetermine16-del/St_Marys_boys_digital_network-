# GitHub Security Checklist

## Never commit

- `.env` files
- Session secrets
- API/admin tokens
- PostgreSQL credentials or connection strings
- Real student/staff passwords
- Student academic records
- Private documents or photos without authorization
- Production uploads
- Backup/database dumps

## Development data

The current development build contains synthetic demo identities for testing. They must never be converted into real school accounts, and development-open mode must never be used on the public internet.

## If a secret is accidentally committed

Treat it as compromised immediately: revoke/rotate it, remove it from the repository history where appropriate, and inspect access logs. Simply deleting the file in a later commit is not enough.
