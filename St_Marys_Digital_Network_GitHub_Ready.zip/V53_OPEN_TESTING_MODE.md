# V53 — Open Testing Mode

V53 is the controlled testing build of St. Mary's Digital Network.

## What changed
- Removed the public school-access-code gate from website pages.
- The legacy `access.html` now redirects directly to the homepage.
- Development/test mode continues to provide a simulated signed-in master context so platform workflows can be tested without repeated login.
- Admin and account workflows remain callable in test mode so the platform can be exercised end-to-end.
- Production is deliberately blocked from using V53 open mode. A new production security layer must be implemented before real student data or public deployment.

## Important
This build is for local/isolated testing only. Do not expose the V53 test server to the public internet or use it with real student records. The next security volume should replace the test bypass with proper authentication, authorization, session controls, rate limits, audit logging, and school access controls.
