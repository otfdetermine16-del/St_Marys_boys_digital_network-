# V67 — Explore & Heritage Update

- Removed all HTML references that mounted the former V23 retractable navigation.
- The V67 global Explore Your School drawer is now the single explorer.
- Added Home as the first explorer option.
- Upgraded Heritage into an archive/exhibition visual treatment with Ghanaian-inspired geometric/adinkra-style decoration and crest seal.
- Added a copyright-safe School Anthem heritage panel; the full anthem text is not reproduced in this package.
