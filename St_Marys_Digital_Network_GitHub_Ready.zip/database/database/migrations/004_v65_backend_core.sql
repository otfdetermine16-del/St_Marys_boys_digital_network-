-- V65 Backend Core: operational metadata, stronger indexes and durable request/audit support.
CREATE TABLE IF NOT EXISTS backend_events (
  id TEXT PRIMARY KEY,
  request_id TEXT,
  actor_account_id TEXT REFERENCES accounts(id),
  event_type TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_backend_events_type_time ON backend_events(event_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_backend_events_actor_time ON backend_events(actor_account_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_media_visibility_created ON media_assets(visibility, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_accounts_role_status ON accounts(role, status);
CREATE INDEX IF NOT EXISTS idx_classes_department_year ON classes(department, year, status);
CREATE INDEX IF NOT EXISTS idx_membership_account ON class_memberships(account_id, class_id);
CREATE INDEX IF NOT EXISTS idx_connect_comments_post_time ON connect_post_comments(post_id, created_at);
CREATE INDEX IF NOT EXISTS idx_connect_likes_account ON connect_post_likes(account_id, created_at DESC);
