-- V58: Firebase identity bridge field.
-- The application_state JSONB remains the production source of truth during the
-- current architecture, while this column prepares the relational accounts table
-- for the eventual fully decomposed Firebase-backed identity model.
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS firebase_uid TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS accounts_firebase_uid_unique
  ON accounts(firebase_uid) WHERE firebase_uid IS NOT NULL;
