-- St. Mary's Digital Network V44 PostgreSQL foundation
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  department TEXT,
  class_name TEXT,
  class_id TEXT,
  house TEXT,
  profile_photo TEXT,
  password_hash TEXT,
  password_salt TEXT,
  password_scheme TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS classes (
  id TEXT PRIMARY KEY,
  department TEXT NOT NULL,
  year TEXT NOT NULL,
  name TEXT NOT NULL UNIQUE,
  code TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'active',
  teacher_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
  captain_id TEXT,
  form_master_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS class_memberships (
  id TEXT PRIMARY KEY,
  class_id TEXT NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  membership_role TEXT NOT NULL DEFAULT 'student',
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(class_id, account_id)
);
CREATE TABLE IF NOT EXISTS academic_records (
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL REFERENCES accounts(id),
  class_id TEXT REFERENCES classes(id),
  subject TEXT NOT NULL,
  academic_year TEXT NOT NULL,
  term TEXT NOT NULL,
  score NUMERIC(5,2) NOT NULL CHECK (score >= 0 AND score <= 100),
  grade TEXT,
  remark TEXT,
  entered_by TEXT REFERENCES accounts(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(student_id, subject, academic_year, term)
);
CREATE TABLE IF NOT EXISTS connect_posts (
  id TEXT PRIMARY KEY,
  author_id TEXT NOT NULL REFERENCES accounts(id),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  visibility TEXT NOT NULL DEFAULT 'school',
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS connect_post_likes (
  post_id TEXT NOT NULL REFERENCES connect_posts(id) ON DELETE CASCADE,
  account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(post_id, account_id)
);
CREATE TABLE IF NOT EXISTS connect_post_comments (
  id TEXT PRIMARY KEY,
  post_id TEXT NOT NULL REFERENCES connect_posts(id) ON DELETE CASCADE,
  account_id TEXT NOT NULL REFERENCES accounts(id),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS media_assets (
  id TEXT PRIMARY KEY,
  filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size_bytes BIGINT NOT NULL DEFAULT 0,
  visibility TEXT NOT NULL DEFAULT 'private',
  owner_id TEXT REFERENCES accounts(id),
  storage_key TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS audit_events (
  id TEXT PRIMARY KEY,
  actor_account_id TEXT REFERENCES accounts(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS schema_migrations (
  version TEXT PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_academic_student ON academic_records(student_id, academic_year, term);
CREATE INDEX IF NOT EXISTS idx_posts_status_published ON connect_posts(status, published_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_actor_time ON audit_events(actor_account_id, created_at DESC);
