-- V51: complete application-state persistence boundary.
-- The application keeps its domain model in one versioned JSON document while
-- PostgreSQL becomes the durable production source of truth. Relational tables
-- from V44 remain available for future domain-level decomposition.
CREATE TABLE IF NOT EXISTS application_state (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  state JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
